/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

//JANGAN LUPA UNCOMMENT BUAT GABUNG UI SQL
import Controller.ControllerLogin;
import Database.Applet;

import Model.Main;
//
//
//import Database.koneksi;

import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.Int;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.ByteBuffer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import javax.smartcardio.CardException;
import javax.smartcardio.CardTerminal;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.util.List;
import javax.smartcardio.CardException;
import javax.smartcardio.CardTerminal;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
/**
 *
 * @author ILM
 */
public class AdminForm_Dinamis extends javax.swing.JFrame {

//--INDEKS DATA
    //DATA DIRI
    String indeksNoSC = "0000";
    String indeksKategoriPasien = "0001";
    String indeksNoAsuransi = "0002";
    String indeksTanggalDaftar = "0003";
    String indeksNamaPasien = "0004";
    String indeksNamaKK = "0005";
    String indeksHubKeluarga = "0006";
    String indeksAlamat = "0007";
    String indeksRT = "0008";
    String indeksRW = "0009";
    String indeksKelurahanPasien = "000A";
    String indeksKecamatanPasien = "000B";
    String indeksKotaPasien = "000C";
    String indeksPropinsiPasien = "000D";
    String indeksKodePos = "000E";
    String indeksWilayahKerja = "000F";
    String indeksTempatLahir = "0010";
    String indeksTanggalLahir = "0011";
    String indeksTeleponPasien = "0012";
    String indeksHPPasien = "0013";
    String indeksKTPPasien = "0014";
    String indeksJenisKelaminPasien = "0015";
    String indeksAgamaPasien = "0016";
    String indeksPendidikanPasien = "0017";
    String indeksPekerjaanPasien = "0018";
    String indeksKelasPerawatan = "0019";
    String indeksEmailPasien = "001A";
    String indeksStatusPerkawinanPasien = "001B";
    String indeksKewarganegaraanPasien = "001C";
    String indeksNamaKeluarga = "001D";
    String indeksHubungan = "001E";
    String indeksAlamatKeluarga = "001F";
    String indeksKelurahanKeluarga = "0020";
    String indeksKecamatanKeluarga = "0021";
    String indeksKotaKeluarga = "0022";
    String indeksPropinsiKeluarga = "0023";
    String indeksKodePosKeluarga = "0024";
    String indeksTeleponKeluarga = "0025";
    String indeksHPKeluarga = "0026";
    String indeksNamaKantor = "0027";
    String indeksAlamatKantor = "0028";
    String indeksKotaKantor = "0029";
    String indeksTeleponKantor1 = "002A";
    String indeksHPKantor1 = "002B";
    String indeksTeleponKantor2 = "002C";
    String indeksHPKantor2 = "002D";

    //STATIS
    String indeksAlergi = "0100";
    String indeksGolongandarah = "0101";
    String indeksRiwayatOperasi = "0102";
    String indeksRawatRS = "0103";
    String indeksPenyakitKronis = "0104";
    String indeksPenyakitBawaan = "0105";
    String indeksFaktorResiko = "0106";

    //DINAMIS
    String indeksStack = "0200";
    String indeksTanggalPeriksa = "0201";
    String indeksKeluhanutama = "0202";
    String indeksAnamnesa = "0203";
    String indeksPenyakitDahulu = "0204";
    String indeksPenyakitKeluarga = "0205";
    String indeksPemeriksaanFisik = "0206";
    String indeksTinggi = "0207";
    String indeksBeratbadan = "0208";
    String indeksSystole = "0209";
    String indeksDiastole = "020A";
    String indeksNadi = "020B";
    String indeksKesadaran = "020C";
    String indeksSuhu = "020D";
    String indeksRespirasi = "020E";
    String indeksLain = "020F";
    String indeksLabExecuteFlag = "0210";
    String indeksExpertiseLab = "0211";
    String indeksCatatanLab = "0212";
    String indeksTerapi = "0213";
    String indeksResep = "0214";
    String indeksCatatanresep = "0215";
    String indeksEksekusiResep = "0216";
    String indeksRepetisiresep = "0217";
    String indeksPrognosa = "0218";
    String indeksICD1 = "0219";
    String indeksICD2 = "021A";
    String indeksICD3 = "021B";
    String indeksICD4 = "021C";
    String indeksICD5 = "021D";
    String indeksICD6 = "021E";
    String indeksICD7 = "021F";
    String indeksICD8 = "0220";
    String indeksICD9 = "0221";
    String indeksICD10 = "0222";
    String indeksICDDiagnosa1 = "0223";
    String indeksICDDiagnosa2 = "0224";
    String indeksICDDiagnosa3 = "0225";
    String indeksICDDiagnosa4 = "0226";
    String indeksICDDiagnosa5 = "0227";
    String indeksICDDiagnosa6 = "0228";
    String indeksICDDiagnosa7 = "0229";
    String indeksICDDiagnosa8 = "022A";
    String indeksICDDiagnosa9 = "022B";
    String indeksICDDiagnosa10 = "022C";
    String indeksPoliTujuan = "022D";
    String indeksRujukan = "022E";
    String indeksIDPuskesmas = "022F";
//--END OF INDEKS

//--DATA
    //DATA DIRI
    // NoSC
    String data_StringNoSC;
    // KategoriPasien
    String data_StringKategoriPasien;
    // NoAsuransi
    String data_StringNoAsuransi;
    // TanggalDaftar
    String data_StringTanggalDaftar;
    // NamaPasien
    String data_StringNamaPasien;
    // NamaKK
    String data_StringNamaKK;
    // HubKeluarga
    String data_StringHubKeluarga;
    // Alamat
    String data_StringAlamat;
    // RT
    String data_StringRT;
    // RW
    String data_StringRW;
    // KelurahanPasien
    String data_StringKelurahanPasien;
    // KecamatanPasien
    String data_StringKecamatanPasien;
    // KotaPasien
    String data_StringKotaPasien;
    // PropinsiPasien
    String data_StringPropinsiPasien;
    // Kodepos
    String data_StringKodepos;
    // WilayahKerja
    String data_StringWilayahKerja;
    // TempatLahir
    String data_StringTempatLahir;
    // TanggalLahir
    String data_StringTanggalLahir;
    // TeleponPasien
    String data_StringTeleponPasien;
    // HPPasien
    String data_StringHPPasien;
    // KTPPasien
    String data_StringKTPPasien;
    // JenisKelaminPasien
    String data_StringJenisKelaminPasien;
    // AgamaPasien
    String data_StringAgamaPasien;
    // PendidikanPasien
    String data_StringPendidikanPasien;
    // PekerjaanPasien
    String data_StringPekerjaanPasien;
    // KelasPerawatan
    String data_StringKelasPerawatan;
    // EmailPasien
    String data_StringEmailPasien;
    // StatusPerkawinanPasien
    String data_StringStatusPerkawinanPasien;
    // KewarganegaraanPasien
    String data_StringKewarganegaraanPasien;
    // NamaKeluarga
    String data_StringNamaKeluarga;
    // Hubungan
    String data_StringHubungan;
    // AlamatKeluarga
    String data_StringAlamatKeluarga;
    // KelurahanKeluarga
    String data_StringKelurahanKeluarga;
    // KecamatanKeluarga
    String data_StringKecamatanKeluarga;
    // KotaKeluarga
    String data_StringKotaKeluarga;
    // PropinsiKeluarga
    String data_StringPropinsiKeluarga;
    // KodePosKeluarga
    String data_StringKodePosKeluarga;
    // TeleponKeluarga
    String data_StringTeleponKeluarga;
    // HPKeluarga
    String data_StringHPKeluarga;
    // NamaKantor
    String data_StringNamaKantor;
    // AlamatKantor
    String data_StringAlamatKantor;
    // KotaKantor
    String data_StringKotaKantor;
    // TeleponKantor1
    String data_StringTeleponKantor1;
    // HPKantor1
    String data_StringHPKantor1;
    // TeleponKantor2
    String data_StringTeleponKantor2;
    // HPKantor2
    String data_StringHPKantor2;

    //STATIS
    // Alergi
    String data_StringAlergi;
    // Golongandarah
    String data_StringGolongandarah;
    // RiwayatOperasi
    String data_StringRiwayatOperasi;
    // RawatRS
    String data_StringRawatRS;
    // PenyakitKronis
    String data_StringPenyakitKronis;
    // PenyakitBawaan
    String data_StringPenyakitBawaan;
    // FaktorResiko
    String data_StringFaktorResiko;

    //DINAMIS
    // Stack
    String data_StringStack;
    // TanggalPeriksa
    String data_StringTanggalPeriksa;
    // Keluhanutama
    String data_StringKeluhanutama;
    // Anamnesa
    String data_StringAnamnesa;
    // PenyakitDahulu
    String data_StringPenyakitDahulu;
    // PenyakitKeluarga
    String data_StringPenyakitKeluarga;
    // PemeriksaanFisik
    String data_StringPemeriksaanFisik;
    // Tinggi
    String data_StringTinggi;
    // Beratbadan
    String data_StringBeratbadan;
    // Systole
    String data_StringSystole;
    // Diastole
    String data_StringDiastole;
    // Nadi
    String data_StringNadi;
    // Kesadaran
    String data_StringKesadaran;
    // Suhu
    String data_StringSuhu;
    // Respirasi
    String data_StringRespirasi;
    // Lain-lain
    String data_StringLain;
    // LabExecuteFlag
    String data_StringLabExecuteFlag;
    // ExpertiseLab
    String data_StringExpertiseLab;
    // CatatanLab
    String data_StringCatatanLab;
    // Terapi
    String data_StringTerapi;
    // Resep
    String data_StringResep;
    // Catatanresep
    String data_StringCatatanresep;
    // EksekusiResep
    String data_StringEksekusiResep;
    // Repetisiresep
    String data_StringRepetisiresep;
    // Prognosa
    String data_StringPrognosa;
    // ICD1
    String data_StringICD1;
    // ICD2
    String data_StringICD2;
    // ICD3
    String data_StringICD3;
    // ICD4
    String data_StringICD4;
    // ICD5
    String data_StringICD5;
    // ICD6
    String data_StringICD6;
    // ICD7
    String data_StringICD7;
    // ICD8
    String data_StringICD8;
    // ICD9
    String data_StringICD9;
    // ICD10
    String data_StringICD10;
    // ICD1Diagnosa
    String data_StringICDDiagnosa1;
    // ICD2Diagnosa
    String data_StringICDDiagnosa2;
    // ICD3Diagnosa
    String data_StringICDDiagnosa3;
    // ICD4Diagnosa
    String data_StringICDDiagnosa4;
    // ICD5Diagnosa
    String data_StringICDDiagnosa5;
    // ICD6Diagnosa
    String data_StringICDDiagnosa6;
    // ICD7Diagnosa
    String data_StringICDDiagnosa7;
    // ICD8Diagnosa
    String data_StringICDDiagnosa8;
    // ICD9Diagnosa
    String data_StringICDDiagnosa9;
    // ICD10Diagnosa
    String data_StringICDDiagnosa10;
    // PoliTujuan
    String data_StringPoliTujuan;
    // Rujukan
    String data_StringRujukan;
    // IDPuskesmas
    String data_StringIDPuskesmas;

//--END OF DATA

//--SYMBOL
    //DATA DIRI
    // HubKeluarga
    String[] symbolHubKeluarga = new String[7];
    // RT
    String[] symbolRT = new String[30];
    // RW
    String[] symbolRW = new String[30];
    // KelurahanPasien
    String[] symbolKelurahanPasien = new String[30];
    // KecamatanPasien
    String[] symbolKecamatanPasien = new String[30];
    // KotaPasien
    String[] symbolKotaPasien = new String[30];
    // PropinsiPasien
    String[] symbolPropinsiPasien = new String[34];
    // WilayahKerja
    String[] symbolWilayahKerja = new String[2];
    // JenisKelaminPasien
    String[] symbolJenisKelaminPasien = new String[2];
    // AgamaPasien
    String[] symbolAgamaPasien = new String[6];
    // PendidikanPasien
    String[] symbolPendidikanPasien = new String[7];
    // PekerjaanPasien
    String[] symbolPekerjaanPasien = new String[13];
    // StatusPerkawinanPasien
    String[] symbolStatusPerkawinanPasien = new String[3];
    // KewarganegaraanPasien
    String[] symbolKewarganegaraanPasien = new String[2];
    // Hubungan
    String[] symbolHubungan = new String[7];
    // KelurahanKeluarga
    String[] symbolKelurahanKeluarga = new String[30];
    // KecamatanKeluarga
    String[] symbolKecamatanKeluarga = new String[30];
    // KotaKeluarga
    String[] symbolKotaKeluarga = new String[30];
    // PropinsiKeluarga
    String[] symbolPropinsiKeluarga = new String[34];
    // KotaKantor
    String[] symbolKotaKantor = new String[30];

    //STATIS
    // Golongandarah
    String[] symbolGolongandarah = new String[8];

    //DINAMIS
    // Kesadaran
    String[] symbolKesadaran = new String[6];
    // LabExecuteFlag
    String[] symbolLabExecuteFlag = new String[3];
    // EksekusiResep
    String[] symbolEksekusiResep = new String[5];
    // Repetisiresep
    String[] symbolRepetisiresep = new String[5];
    // Prognosa
    String[] symbolPrognosa = new String[8];
//--END OF SYMBOL        

    private Main model;
    JavaSmartcard javaCard ;
    Applet applet;
    ControllerLogin login;
     
    String appletID;
    String CLAText = "80";
    String CLANum ="90";
    String status = "";
    
    boolean isConnected;
    
    boolean symEx;
    String[] symbol;
    
    boolean floatData;
    
    final static int NUM = 0;
    final static int TEXT = 1;
    
    public AdminForm_Dinamis() {
        initComponents();
        //getCurrentStack();
        //setLabel();
        InisiasiData();
        javaCard = new JavaSmartcard();
        applet = new Applet();
        appletID = applet.getAppletID();
        getCurrentStack();
        
        System.out.println("Admin-Dinamis ID:"+appletID);
        //System.out.println("Admin-Dinamis con:"+isConnected);
        this.getContentPane().setBackground(Color.white);
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        gender = new javax.swing.ButtonGroup();
        panelOperationTitle = new javax.swing.JPanel();
        btnLogOut = new javax.swing.JButton();
        administrator = new javax.swing.JLabel();
        btnVerifikasiPin = new javax.swing.JButton();
        btnLogout = new javax.swing.JButton();
        btnHome = new javax.swing.JButton();
        administrator1 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        PanelReaderCard = new javax.swing.JPanel();
        status_Label_AdminForm = new javax.swing.JLabel();
        jTabbedAll = new javax.swing.JTabbedPane();
        RekamMedisStatis = new javax.swing.JPanel();
        panelAllCRUD_STATIS = new javax.swing.JPanel();
        getAllSTATIS = new javax.swing.JButton();
        deleteAllSTATIS = new javax.swing.JButton();
        inputAllSTATIS = new javax.swing.JButton();
        jScrollPane_STATIS = new javax.swing.JScrollPane();
        panelItemSTATIS = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        dataFaktorResiko = new javax.swing.JLabel();
        dataPenyakitBawaan = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        dataPenyakitKronis = new javax.swing.JLabel();
        dataRawatRS = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        dataRiwayatOperasi = new javax.swing.JLabel();
        dataGolongandarah = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        dataAlergi = new javax.swing.JLabel();
        fieldFaktorResiko = new javax.swing.JTextField();
        fieldPenyakitBawaan = new javax.swing.JTextField();
        fieldPenyakitKronis = new javax.swing.JTextField();
        fieldRawatRS = new javax.swing.JTextField();
        fieldRiwayatOperasi = new javax.swing.JTextField();
        ComboBoxGolongandarah = new javax.swing.JComboBox<>();
        fieldAlergi = new javax.swing.JTextField();
        inputAlergi = new javax.swing.JButton();
        deleteAlergi = new javax.swing.JButton();
        deleteGolongandarah = new javax.swing.JButton();
        inputGolongandarah = new javax.swing.JButton();
        inputRiwayatOperasi = new javax.swing.JButton();
        deleteRiwayatOperasi = new javax.swing.JButton();
        inputRawatRS = new javax.swing.JButton();
        deleteRawatRS = new javax.swing.JButton();
        inputPenyakitKronis = new javax.swing.JButton();
        deletePenyakitKronis = new javax.swing.JButton();
        inputPenyakitBawaan = new javax.swing.JButton();
        deletePenyakitBawaan = new javax.swing.JButton();
        inputFaktorResiko = new javax.swing.JButton();
        deleteFaktorResiko = new javax.swing.JButton();
        RekamMedisDinamis = new javax.swing.JPanel();
        jScrollPane_DINAMIS = new javax.swing.JScrollPane();
        panelItemDATA1 = new javax.swing.JPanel();
        labelStack = new javax.swing.JLabel();
        dataStack = new javax.swing.JLabel();
        labelTanggalPeriksa = new javax.swing.JLabel();
        dataTanggalPeriksa = new javax.swing.JLabel();
        fieldTanggalPeriksa = new javax.swing.JTextField();
        inputTanggalPeriksa = new javax.swing.JButton();
        deleteTanggalPeriksa = new javax.swing.JButton();
        labelKeluhanutama = new javax.swing.JLabel();
        dataKeluhanutama = new javax.swing.JLabel();
        fieldKeluhanutama = new javax.swing.JTextField();
        inputKeluhanutama = new javax.swing.JButton();
        deleteKeluhanutama = new javax.swing.JButton();
        labelAnamnesa = new javax.swing.JLabel();
        dataAnamnesa = new javax.swing.JLabel();
        fieldAnamnesa = new javax.swing.JTextField();
        inputAnamnesa = new javax.swing.JButton();
        deleteAnamnesa = new javax.swing.JButton();
        labelPenyakitDahulu = new javax.swing.JLabel();
        dataPenyakitDahulu = new javax.swing.JLabel();
        fieldPenyakitDahulu = new javax.swing.JTextField();
        inputPenyakitDahulu = new javax.swing.JButton();
        deletePenyakitDahulu = new javax.swing.JButton();
        labelPenyakitKeluarga = new javax.swing.JLabel();
        dataPenyakitKeluarga = new javax.swing.JLabel();
        fieldPenyakitKeluarga = new javax.swing.JTextField();
        inputPenyakitKeluarga = new javax.swing.JButton();
        deletePenyakitKeluarga = new javax.swing.JButton();
        labelPemeriksaanFisik = new javax.swing.JLabel();
        dataPemeriksaanFisik = new javax.swing.JLabel();
        fieldPemeriksaanFisik = new javax.swing.JTextField();
        inputPemeriksaanFisik = new javax.swing.JButton();
        deletePemeriksaanFisik = new javax.swing.JButton();
        labelTinggi = new javax.swing.JLabel();
        dataTinggi = new javax.swing.JLabel();
        fieldTinggi = new javax.swing.JTextField();
        inputTinggi = new javax.swing.JButton();
        deleteTinggi = new javax.swing.JButton();
        labelBeratbadan = new javax.swing.JLabel();
        dataBeratbadan = new javax.swing.JLabel();
        fieldBeratbadan = new javax.swing.JTextField();
        inputBeratbadan = new javax.swing.JButton();
        deleteBeratbadan = new javax.swing.JButton();
        labelSystole = new javax.swing.JLabel();
        dataSystole = new javax.swing.JLabel();
        fieldSystole = new javax.swing.JTextField();
        inputSystole = new javax.swing.JButton();
        deleteSystole = new javax.swing.JButton();
        labelDiastole = new javax.swing.JLabel();
        dataDiastole = new javax.swing.JLabel();
        fieldDiastole = new javax.swing.JTextField();
        inputDiastole = new javax.swing.JButton();
        deleteDiastole = new javax.swing.JButton();
        labelNadi = new javax.swing.JLabel();
        dataNadi = new javax.swing.JLabel();
        fieldNadi = new javax.swing.JTextField();
        inputNadi = new javax.swing.JButton();
        deleteNadi = new javax.swing.JButton();
        labelKesadaran = new javax.swing.JLabel();
        dataKesadaran = new javax.swing.JLabel();
        ComboBox_Kesadaran = new javax.swing.JComboBox<>();
        inputKesadaran = new javax.swing.JButton();
        deleteKesadaran = new javax.swing.JButton();
        labelSuhu = new javax.swing.JLabel();
        dataSuhu = new javax.swing.JLabel();
        fieldSuhu = new javax.swing.JTextField();
        inputSuhu = new javax.swing.JButton();
        deleteSuhu = new javax.swing.JButton();
        labelRespirasi = new javax.swing.JLabel();
        dataRespirasi = new javax.swing.JLabel();
        fieldRespirasi = new javax.swing.JTextField();
        inputRespirasi = new javax.swing.JButton();
        deleteRespirasi = new javax.swing.JButton();
        labelLain = new javax.swing.JLabel();
        dataLain = new javax.swing.JLabel();
        fieldLain = new javax.swing.JTextField();
        inputLain = new javax.swing.JButton();
        deleteLain = new javax.swing.JButton();
        labelLabExecuteFlag = new javax.swing.JLabel();
        dataLabExecuteFlag = new javax.swing.JLabel();
        inputLabExecuteFlag = new javax.swing.JButton();
        deleteLabExecuteFlag = new javax.swing.JButton();
        labelExpertiseLab = new javax.swing.JLabel();
        dataExpertiseLab = new javax.swing.JLabel();
        fieldExpertiseLab = new javax.swing.JTextField();
        inputExpertiseLab = new javax.swing.JButton();
        deleteExpertiseLab = new javax.swing.JButton();
        labelCatatanLab = new javax.swing.JLabel();
        dataCatatanLab = new javax.swing.JLabel();
        fieldCatatanLab = new javax.swing.JTextField();
        inputCatatanLab = new javax.swing.JButton();
        deleteCatatanLab = new javax.swing.JButton();
        labelTerapi = new javax.swing.JLabel();
        dataTerapi = new javax.swing.JLabel();
        fieldTerapi = new javax.swing.JTextField();
        inputTerapi = new javax.swing.JButton();
        deleteTerapi = new javax.swing.JButton();
        labelResep = new javax.swing.JLabel();
        dataResep = new javax.swing.JLabel();
        fieldResep = new javax.swing.JTextField();
        inputResep = new javax.swing.JButton();
        deleteResep = new javax.swing.JButton();
        labelCatatanresep = new javax.swing.JLabel();
        dataCatatanresep = new javax.swing.JLabel();
        fieldCatatanresep = new javax.swing.JTextField();
        inputCatatanresep = new javax.swing.JButton();
        deleteCatatanresep = new javax.swing.JButton();
        labelEksekusiResep = new javax.swing.JLabel();
        dataEksekusiResep = new javax.swing.JLabel();
        inputEksekusiResep = new javax.swing.JButton();
        deleteEksekusiResep = new javax.swing.JButton();
        labelRepetisiresep = new javax.swing.JLabel();
        dataRepetisiresep = new javax.swing.JLabel();
        inputRepetisiresep = new javax.swing.JButton();
        deleteRepetisiresep = new javax.swing.JButton();
        labelPrognosa = new javax.swing.JLabel();
        dataPrognosa = new javax.swing.JLabel();
        inputPrognosa = new javax.swing.JButton();
        deletePrognosa = new javax.swing.JButton();
        labelICD1 = new javax.swing.JLabel();
        dataICD1 = new javax.swing.JLabel();
        fieldICD1 = new javax.swing.JTextField();
        inputICD1 = new javax.swing.JButton();
        deleteICD1 = new javax.swing.JButton();
        labelICD2 = new javax.swing.JLabel();
        dataICD2 = new javax.swing.JLabel();
        fieldICD2 = new javax.swing.JTextField();
        inputICD2 = new javax.swing.JButton();
        deleteICD2 = new javax.swing.JButton();
        labelICD3 = new javax.swing.JLabel();
        dataICD3 = new javax.swing.JLabel();
        fieldICD3 = new javax.swing.JTextField();
        inputICD3 = new javax.swing.JButton();
        deleteICD3 = new javax.swing.JButton();
        labelICD4 = new javax.swing.JLabel();
        dataICD4 = new javax.swing.JLabel();
        fieldICD4 = new javax.swing.JTextField();
        inputICD4 = new javax.swing.JButton();
        deleteICD4 = new javax.swing.JButton();
        labelICD5 = new javax.swing.JLabel();
        dataICD5 = new javax.swing.JLabel();
        fieldICD5 = new javax.swing.JTextField();
        inputICD5 = new javax.swing.JButton();
        deleteICD5 = new javax.swing.JButton();
        labelICD6 = new javax.swing.JLabel();
        dataICD6 = new javax.swing.JLabel();
        fieldICD6 = new javax.swing.JTextField();
        inputICD6 = new javax.swing.JButton();
        deleteICD6 = new javax.swing.JButton();
        labelICD7 = new javax.swing.JLabel();
        dataICD7 = new javax.swing.JLabel();
        fieldICD7 = new javax.swing.JTextField();
        inputICD7 = new javax.swing.JButton();
        deleteICD7 = new javax.swing.JButton();
        labelICD8 = new javax.swing.JLabel();
        dataICD8 = new javax.swing.JLabel();
        fieldICD8 = new javax.swing.JTextField();
        inputICD8 = new javax.swing.JButton();
        deleteICD8 = new javax.swing.JButton();
        labelICD9 = new javax.swing.JLabel();
        dataICD9 = new javax.swing.JLabel();
        fieldICD9 = new javax.swing.JTextField();
        inputICD9 = new javax.swing.JButton();
        deleteICD9 = new javax.swing.JButton();
        labelICD10 = new javax.swing.JLabel();
        dataICD10 = new javax.swing.JLabel();
        fieldICD10 = new javax.swing.JTextField();
        inputICD10 = new javax.swing.JButton();
        deleteICD10 = new javax.swing.JButton();
        labelICDDiagnosa1 = new javax.swing.JLabel();
        dataICDDiagnosa1 = new javax.swing.JLabel();
        fieldICDDiagnosa1 = new javax.swing.JTextField();
        inputICDDiagnosa1 = new javax.swing.JButton();
        deleteICDDiagnosa1 = new javax.swing.JButton();
        labelICDDiagnosa2 = new javax.swing.JLabel();
        dataICDDiagnosa2 = new javax.swing.JLabel();
        fieldICDDiagnosa2 = new javax.swing.JTextField();
        inputICDDiagnosa2 = new javax.swing.JButton();
        deleteICDDiagnosa2 = new javax.swing.JButton();
        labelICDDiagnosa3 = new javax.swing.JLabel();
        dataICDDiagnosa3 = new javax.swing.JLabel();
        fieldICDDiagnosa3 = new javax.swing.JTextField();
        inputICDDiagnosa3 = new javax.swing.JButton();
        deleteICDDiagnosa3 = new javax.swing.JButton();
        labelICDDiagnosa4 = new javax.swing.JLabel();
        dataICDDiagnosa4 = new javax.swing.JLabel();
        fieldICDDiagnosa4 = new javax.swing.JTextField();
        inputICDDiagnosa4 = new javax.swing.JButton();
        deleteICDDiagnosa4 = new javax.swing.JButton();
        labelICDDiagnosa5 = new javax.swing.JLabel();
        dataICDDiagnosa5 = new javax.swing.JLabel();
        fieldICDDiagnosa5 = new javax.swing.JTextField();
        inputICDDiagnosa5 = new javax.swing.JButton();
        deleteICDDiagnosa5 = new javax.swing.JButton();
        labelICDDiagnosa6 = new javax.swing.JLabel();
        dataICDDiagnosa6 = new javax.swing.JLabel();
        fieldICDDiagnosa6 = new javax.swing.JTextField();
        inputICDDiagnosa6 = new javax.swing.JButton();
        deleteICDDiagnosa6 = new javax.swing.JButton();
        labelICDDiagnosa7 = new javax.swing.JLabel();
        dataICDDiagnosa7 = new javax.swing.JLabel();
        fieldICDDiagnosa7 = new javax.swing.JTextField();
        inputICDDiagnosa7 = new javax.swing.JButton();
        deleteICDDiagnosa7 = new javax.swing.JButton();
        labelICDDiagnosa8 = new javax.swing.JLabel();
        dataICDDiagnosa8 = new javax.swing.JLabel();
        fieldICDDiagnosa8 = new javax.swing.JTextField();
        inputICDDiagnosa8 = new javax.swing.JButton();
        deleteICDDiagnosa8 = new javax.swing.JButton();
        labelICDDiagnosa9 = new javax.swing.JLabel();
        dataICDDiagnosa9 = new javax.swing.JLabel();
        fieldICDDiagnosa9 = new javax.swing.JTextField();
        inputICDDiagnosa9 = new javax.swing.JButton();
        deleteICDDiagnosa9 = new javax.swing.JButton();
        labelICDDiagnosa10 = new javax.swing.JLabel();
        dataICDDiagnosa10 = new javax.swing.JLabel();
        fieldICDDiagnosa10 = new javax.swing.JTextField();
        inputICDDiagnosa10 = new javax.swing.JButton();
        deleteICDDiagnosa10 = new javax.swing.JButton();
        labelPoliTujuan = new javax.swing.JLabel();
        dataPoliTujuan = new javax.swing.JLabel();
        fieldPoliTujuan = new javax.swing.JTextField();
        inputPoliTujuan = new javax.swing.JButton();
        deletePoliTujuan = new javax.swing.JButton();
        labelRujukan = new javax.swing.JLabel();
        dataRujukan = new javax.swing.JLabel();
        fieldRujukan = new javax.swing.JTextField();
        inputRujukan = new javax.swing.JButton();
        deleteRujukan = new javax.swing.JButton();
        labelIDPuskesmas = new javax.swing.JLabel();
        dataIDPuskesmas = new javax.swing.JLabel();
        fieldIDPuskesmas = new javax.swing.JTextField();
        inputIDPuskesmas = new javax.swing.JButton();
        deleteIDPuskesmas = new javax.swing.JButton();
        ComboBox_LabExecuteFlag = new javax.swing.JComboBox<>();
        ComboBox_EksekusiResep = new javax.swing.JComboBox<>();
        ComboBox_Repetisiresep = new javax.swing.JComboBox<>();
        ComboBox_Prognosa = new javax.swing.JComboBox<>();
        panelAllCRUD_STATIS2 = new javax.swing.JPanel();
        updateAllDINAMIS = new javax.swing.JButton();
        deleteAllDINAMIS = new javax.swing.JButton();
        registerlDINAMIS = new javax.swing.JButton();
        labelCurrentStack = new javax.swing.JLabel();
        fieldCurrentStack = new javax.swing.JLabel();
        GetStackDinamis = new javax.swing.JButton();
        getAllDinamis_current = new javax.swing.JButton();
        RekamMedisDinamis1 = new javax.swing.JPanel();
        jScrollPane_ViewDinamis = new javax.swing.JScrollPane();
        panelViewDinamis = new javax.swing.JPanel();
        labelStack1 = new javax.swing.JLabel();
        dataStack1 = new javax.swing.JLabel();
        labelTanggalPeriksa1 = new javax.swing.JLabel();
        dataTanggalPeriksa1 = new javax.swing.JLabel();
        labelKeluhanutama1 = new javax.swing.JLabel();
        dataKeluhanutama1 = new javax.swing.JLabel();
        labelAnamnesa1 = new javax.swing.JLabel();
        dataAnamnesa1 = new javax.swing.JLabel();
        labelPenyakitDahulu1 = new javax.swing.JLabel();
        dataPenyakitDahulu1 = new javax.swing.JLabel();
        labelPenyakitKeluarga1 = new javax.swing.JLabel();
        dataPenyakitKeluarga1 = new javax.swing.JLabel();
        labelPemeriksaanFisik1 = new javax.swing.JLabel();
        dataPemeriksaanFisik1 = new javax.swing.JLabel();
        labelTinggi1 = new javax.swing.JLabel();
        dataTinggi1 = new javax.swing.JLabel();
        labelBeratbadan1 = new javax.swing.JLabel();
        dataBeratbadan1 = new javax.swing.JLabel();
        labelSystole1 = new javax.swing.JLabel();
        dataSystole1 = new javax.swing.JLabel();
        labelDiastole1 = new javax.swing.JLabel();
        dataDiastole1 = new javax.swing.JLabel();
        labelNadi1 = new javax.swing.JLabel();
        dataNadi1 = new javax.swing.JLabel();
        labelKesadaran1 = new javax.swing.JLabel();
        dataKesadaran1 = new javax.swing.JLabel();
        labelSuhu1 = new javax.swing.JLabel();
        dataSuhu1 = new javax.swing.JLabel();
        labelRespirasi1 = new javax.swing.JLabel();
        dataRespirasi1 = new javax.swing.JLabel();
        labelLain1 = new javax.swing.JLabel();
        dataLain1 = new javax.swing.JLabel();
        labelLabExecuteFlag1 = new javax.swing.JLabel();
        dataLabExecuteFlag1 = new javax.swing.JLabel();
        labelExpertiseLab1 = new javax.swing.JLabel();
        dataExpertiseLab1 = new javax.swing.JLabel();
        labelCatatanLab1 = new javax.swing.JLabel();
        dataCatatanLab1 = new javax.swing.JLabel();
        labelTerapi1 = new javax.swing.JLabel();
        dataTerapi1 = new javax.swing.JLabel();
        labelResep1 = new javax.swing.JLabel();
        dataResep1 = new javax.swing.JLabel();
        labelCatatanresep1 = new javax.swing.JLabel();
        dataCatatanresep1 = new javax.swing.JLabel();
        labelEksekusiResep1 = new javax.swing.JLabel();
        dataEksekusiResep1 = new javax.swing.JLabel();
        labelRepetisiresep1 = new javax.swing.JLabel();
        dataRepetisiresep1 = new javax.swing.JLabel();
        labelPrognosa1 = new javax.swing.JLabel();
        dataPrognosa1 = new javax.swing.JLabel();
        labelICD11 = new javax.swing.JLabel();
        dataICD11 = new javax.swing.JLabel();
        labelICD12 = new javax.swing.JLabel();
        dataICD12 = new javax.swing.JLabel();
        labelICD13 = new javax.swing.JLabel();
        dataICD13 = new javax.swing.JLabel();
        labelICD14 = new javax.swing.JLabel();
        dataICD14 = new javax.swing.JLabel();
        labelICD15 = new javax.swing.JLabel();
        dataICD15 = new javax.swing.JLabel();
        labelICD16 = new javax.swing.JLabel();
        dataICD16 = new javax.swing.JLabel();
        labelICD17 = new javax.swing.JLabel();
        dataICD17 = new javax.swing.JLabel();
        labelICD18 = new javax.swing.JLabel();
        dataICD18 = new javax.swing.JLabel();
        labelICD19 = new javax.swing.JLabel();
        dataICD19 = new javax.swing.JLabel();
        labelICD20 = new javax.swing.JLabel();
        dataICD20 = new javax.swing.JLabel();
        labelICDDiagnosa11 = new javax.swing.JLabel();
        dataICDDiagnosa11 = new javax.swing.JLabel();
        labelICDDiagnosa12 = new javax.swing.JLabel();
        dataICDDiagnosa12 = new javax.swing.JLabel();
        labelICDDiagnosa13 = new javax.swing.JLabel();
        dataICDDiagnosa13 = new javax.swing.JLabel();
        labelICDDiagnosa14 = new javax.swing.JLabel();
        dataICDDiagnosa14 = new javax.swing.JLabel();
        labelICDDiagnosa15 = new javax.swing.JLabel();
        dataICDDiagnosa15 = new javax.swing.JLabel();
        labelICDDiagnosa16 = new javax.swing.JLabel();
        dataICDDiagnosa16 = new javax.swing.JLabel();
        labelICDDiagnosa17 = new javax.swing.JLabel();
        dataICDDiagnosa17 = new javax.swing.JLabel();
        labelICDDiagnosa18 = new javax.swing.JLabel();
        dataICDDiagnosa18 = new javax.swing.JLabel();
        labelICDDiagnosa19 = new javax.swing.JLabel();
        dataICDDiagnosa19 = new javax.swing.JLabel();
        labelICDDiagnosa20 = new javax.swing.JLabel();
        dataICDDiagnosa20 = new javax.swing.JLabel();
        labelPoliTujuan1 = new javax.swing.JLabel();
        dataPoliTujuan1 = new javax.swing.JLabel();
        labelRujukan1 = new javax.swing.JLabel();
        dataRujukan1 = new javax.swing.JLabel();
        labelIDPuskesmas1 = new javax.swing.JLabel();
        dataIDPuskesmas1 = new javax.swing.JLabel();
        panelMenuViewDinamis = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        ComboBoxStackView = new javax.swing.JComboBox<>();
        getAllDinamis_View = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        panelOperationTitle.setBackground(new java.awt.Color(40, 48, 90));
        panelOperationTitle.setPreferredSize(new java.awt.Dimension(1300, 100));

        btnLogOut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/close.png"))); // NOI18N
        btnLogOut.setBorder(null);
        btnLogOut.setBorderPainted(false);
        btnLogOut.setContentAreaFilled(false);
        btnLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogOutActionPerformed(evt);
            }
        });

        administrator.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        administrator.setForeground(new java.awt.Color(255, 255, 255));
        administrator.setText("REKAM MEDIS");

        btnVerifikasiPin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/logout.png"))); // NOI18N
        btnVerifikasiPin.setBorder(null);
        btnVerifikasiPin.setContentAreaFilled(false);
        btnVerifikasiPin.setFocusPainted(false);
        btnVerifikasiPin.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnVerifikasiPin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerifikasiPinActionPerformed(evt);
            }
        });

        btnLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/home.png"))); // NOI18N
        btnLogout.setBorder(null);
        btnLogout.setContentAreaFilled(false);
        btnLogout.setFocusPainted(false);
        btnLogout.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        btnHome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/back2.png"))); // NOI18N
        btnHome.setBorder(null);
        btnHome.setContentAreaFilled(false);
        btnHome.setFocusPainted(false);
        btnHome.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHomeActionPerformed(evt);
            }
        });

        administrator1.setFont(new java.awt.Font("Segoe UI Light", 0, 36)); // NOI18N
        administrator1.setForeground(new java.awt.Color(255, 255, 255));
        administrator1.setText("ADMINISTRATOR");

        javax.swing.GroupLayout panelOperationTitleLayout = new javax.swing.GroupLayout(panelOperationTitle);
        panelOperationTitle.setLayout(panelOperationTitleLayout);
        panelOperationTitleLayout.setHorizontalGroup(
            panelOperationTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelOperationTitleLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnHome, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panelOperationTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelOperationTitleLayout.createSequentialGroup()
                        .addComponent(administrator1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnVerifikasiPin)
                        .addGap(1, 1, 1)
                        .addComponent(btnLogout)
                        .addGap(1, 1, 1)
                        .addComponent(btnLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelOperationTitleLayout.createSequentialGroup()
                        .addComponent(administrator)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(5, 5, 5))
        );
        panelOperationTitleLayout.setVerticalGroup(
            panelOperationTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelOperationTitleLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelOperationTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnHome, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelOperationTitleLayout.createSequentialGroup()
                        .addComponent(administrator1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(administrator, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(panelOperationTitleLayout.createSequentialGroup()
                .addGroup(panelOperationTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnVerifikasiPin, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setFocusable(false);

        PanelReaderCard.setBackground(new java.awt.Color(40, 48, 90));
        PanelReaderCard.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        status_Label_AdminForm.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
        status_Label_AdminForm.setForeground(new java.awt.Color(255, 255, 255));
        status_Label_AdminForm.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        status_Label_AdminForm.setText("---Status--");
        status_Label_AdminForm.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout PanelReaderCardLayout = new javax.swing.GroupLayout(PanelReaderCard);
        PanelReaderCard.setLayout(PanelReaderCardLayout);
        PanelReaderCardLayout.setHorizontalGroup(
            PanelReaderCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelReaderCardLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(status_Label_AdminForm, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelReaderCardLayout.setVerticalGroup(
            PanelReaderCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelReaderCardLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(status_Label_AdminForm, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        status_Label_AdminForm.getAccessibleContext().setAccessibleName("");

        jTabbedAll.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedAll.setForeground(new java.awt.Color(70, 130, 180));
        jTabbedAll.setFocusable(false);
        jTabbedAll.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jTabbedAll.setPreferredSize(new java.awt.Dimension(1100, 381));

        RekamMedisStatis.setBackground(new java.awt.Color(255, 255, 255));

        getAllSTATIS.setBackground(new java.awt.Color(255, 255, 255));
        getAllSTATIS.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        getAllSTATIS.setForeground(java.awt.SystemColor.activeCaption);
        getAllSTATIS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/retrieve.png"))); // NOI18N
        getAllSTATIS.setText("Get All Item MedRec Statis");
        getAllSTATIS.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.SystemColor.activeCaption, new java.awt.Color(255, 255, 255), java.awt.SystemColor.controlHighlight, java.awt.SystemColor.activeCaption));
        getAllSTATIS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getAllSTATISActionPerformed(evt);
            }
        });

        deleteAllSTATIS.setBackground(new java.awt.Color(255, 255, 255));
        deleteAllSTATIS.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        deleteAllSTATIS.setForeground(java.awt.SystemColor.activeCaption);
        deleteAllSTATIS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/delete.png"))); // NOI18N
        deleteAllSTATIS.setText("Delete All Item MedRec Statis");
        deleteAllSTATIS.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.SystemColor.activeCaption, new java.awt.Color(255, 255, 255), java.awt.SystemColor.controlHighlight, java.awt.SystemColor.activeCaption));
        deleteAllSTATIS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteAllSTATISActionPerformed(evt);
            }
        });

        inputAllSTATIS.setBackground(new java.awt.Color(255, 255, 255));
        inputAllSTATIS.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        inputAllSTATIS.setForeground(java.awt.SystemColor.activeCaption);
        inputAllSTATIS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/save.png"))); // NOI18N
        inputAllSTATIS.setText("Input All Item MedRec Statis");
        inputAllSTATIS.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.SystemColor.activeCaption, new java.awt.Color(255, 255, 255), java.awt.SystemColor.controlHighlight, java.awt.SystemColor.activeCaption));
        inputAllSTATIS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputAllSTATISActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelAllCRUD_STATISLayout = new javax.swing.GroupLayout(panelAllCRUD_STATIS);
        panelAllCRUD_STATIS.setLayout(panelAllCRUD_STATISLayout);
        panelAllCRUD_STATISLayout.setHorizontalGroup(
            panelAllCRUD_STATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAllCRUD_STATISLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(getAllSTATIS, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(deleteAllSTATIS, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(inputAllSTATIS, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(470, Short.MAX_VALUE))
        );
        panelAllCRUD_STATISLayout.setVerticalGroup(
            panelAllCRUD_STATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelAllCRUD_STATISLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelAllCRUD_STATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(getAllSTATIS)
                    .addComponent(deleteAllSTATIS)
                    .addComponent(inputAllSTATIS))
                .addContainerGap())
        );

        jScrollPane_STATIS.setBorder(null);
        jScrollPane_STATIS.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        panelItemSTATIS.setBackground(new java.awt.Color(255, 255, 255));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel13.setText("Faktor Resiko                  :");

        dataFaktorResiko.setText("-");

        dataPenyakitBawaan.setText("-");

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel10.setText("Riwayat Penyakit Bawaan :");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel11.setText("Riwayat Penyakit Kronis    :");

        dataPenyakitKronis.setText("-");

        dataRawatRS.setText("-");

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel12.setText("Riwayat Rawat RS           :");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel6.setText("Riwayat Operasi              :");

        dataRiwayatOperasi.setText("-");

        dataGolongandarah.setText("-");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel5.setText("Golongan Darah              :");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Alergi                            :");

        dataAlergi.setText("-");

        fieldFaktorResiko.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldFaktorResiko.setText("--input--");
        fieldFaktorResiko.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldFaktorResikoActionPerformed(evt);
            }
        });

        fieldPenyakitBawaan.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldPenyakitBawaan.setText("--input--");
        fieldPenyakitBawaan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldPenyakitBawaanActionPerformed(evt);
            }
        });

        fieldPenyakitKronis.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldPenyakitKronis.setText("--input--");
        fieldPenyakitKronis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldPenyakitKronisActionPerformed(evt);
            }
        });

        fieldRawatRS.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldRawatRS.setText("--input--");
        fieldRawatRS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldRawatRSActionPerformed(evt);
            }
        });

        fieldRiwayatOperasi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldRiwayatOperasi.setText("--input--");
        fieldRiwayatOperasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldRiwayatOperasiActionPerformed(evt);
            }
        });

        ComboBoxGolongandarah.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. A+", "2. A-", "3. B+", "4. B-", "5. AB+", "6. AB-", "7. O+", "8. O-" }));
        ComboBoxGolongandarah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxGolongandarahActionPerformed(evt);
            }
        });

        fieldAlergi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldAlergi.setText("--input--");
        fieldAlergi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldAlergiActionPerformed(evt);
            }
        });

        inputAlergi.setText("Input");
        inputAlergi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputAlergi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputAlergiActionPerformed(evt);
            }
        });

        deleteAlergi.setText("Delete");
        deleteAlergi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteAlergi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteAlergiActionPerformed(evt);
            }
        });

        deleteGolongandarah.setText("Delete");
        deleteGolongandarah.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteGolongandarah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteGolongandarahActionPerformed(evt);
            }
        });

        inputGolongandarah.setText("Input");
        inputGolongandarah.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputGolongandarah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputGolongandarahActionPerformed(evt);
            }
        });

        inputRiwayatOperasi.setText("Input");
        inputRiwayatOperasi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputRiwayatOperasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputRiwayatOperasiActionPerformed(evt);
            }
        });

        deleteRiwayatOperasi.setText("Delete");
        deleteRiwayatOperasi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteRiwayatOperasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteRiwayatOperasiActionPerformed(evt);
            }
        });

        inputRawatRS.setText("Input");
        inputRawatRS.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputRawatRS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputRawatRSActionPerformed(evt);
            }
        });

        deleteRawatRS.setText("Delete");
        deleteRawatRS.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteRawatRS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteRawatRSActionPerformed(evt);
            }
        });

        inputPenyakitKronis.setText("Input");
        inputPenyakitKronis.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputPenyakitKronis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputPenyakitKronisActionPerformed(evt);
            }
        });

        deletePenyakitKronis.setText("Delete");
        deletePenyakitKronis.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletePenyakitKronis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePenyakitKronisActionPerformed(evt);
            }
        });

        inputPenyakitBawaan.setText("Input");
        inputPenyakitBawaan.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputPenyakitBawaan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputPenyakitBawaanActionPerformed(evt);
            }
        });

        deletePenyakitBawaan.setText("Delete");
        deletePenyakitBawaan.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletePenyakitBawaan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePenyakitBawaanActionPerformed(evt);
            }
        });

        inputFaktorResiko.setText("Input");
        inputFaktorResiko.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputFaktorResiko.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputFaktorResikoActionPerformed(evt);
            }
        });

        deleteFaktorResiko.setText("Delete");
        deleteFaktorResiko.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteFaktorResiko.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteFaktorResikoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelItemSTATISLayout = new javax.swing.GroupLayout(panelItemSTATIS);
        panelItemSTATIS.setLayout(panelItemSTATISLayout);
        panelItemSTATISLayout.setHorizontalGroup(
            panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelItemSTATISLayout.createSequentialGroup()
                .addContainerGap(921, Short.MAX_VALUE)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(inputFaktorResiko, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(inputPenyakitBawaan, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(inputPenyakitKronis, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(inputRawatRS, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(inputAlergi, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(inputRiwayatOperasi, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(inputGolongandarah, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(deletePenyakitBawaan, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(deletePenyakitKronis, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(deleteRawatRS, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(deleteRiwayatOperasi, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(deleteGolongandarah, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(deleteAlergi, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(deleteFaktorResiko, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE))
                .addGap(50, 50, 50))
            .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelItemSTATISLayout.createSequentialGroup()
                    .addGap(2, 2, 2)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(dataGolongandarah, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
                        .addComponent(dataRiwayatOperasi, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dataRawatRS, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dataPenyakitKronis, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dataPenyakitBawaan, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dataFaktorResiko, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dataAlergi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(fieldPenyakitBawaan, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(fieldPenyakitKronis, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(fieldRawatRS, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(fieldRiwayatOperasi, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(ComboBoxGolongandarah, javax.swing.GroupLayout.Alignment.LEADING, 0, 350, Short.MAX_VALUE)
                        .addComponent(fieldAlergi, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(fieldFaktorResiko))
                    .addContainerGap(166, Short.MAX_VALUE)))
        );
        panelItemSTATISLayout.setVerticalGroup(
            panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelItemSTATISLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputAlergi)
                    .addComponent(deleteAlergi))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputGolongandarah)
                    .addComponent(deleteGolongandarah))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputRiwayatOperasi)
                    .addComponent(deleteRiwayatOperasi))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputRawatRS)
                    .addComponent(deleteRawatRS))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputPenyakitKronis)
                    .addComponent(deletePenyakitKronis))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputPenyakitBawaan)
                    .addComponent(deletePenyakitBawaan))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputFaktorResiko)
                    .addComponent(deleteFaktorResiko))
                .addContainerGap(247, Short.MAX_VALUE))
            .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelItemSTATISLayout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(fieldAlergi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dataAlergi)))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5)
                        .addComponent(dataGolongandarah)
                        .addComponent(ComboBoxGolongandarah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel6)
                        .addComponent(dataRiwayatOperasi)
                        .addComponent(fieldRiwayatOperasi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(dataRawatRS)
                        .addComponent(fieldRawatRS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel11)
                        .addComponent(dataPenyakitKronis)
                        .addComponent(fieldPenyakitKronis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel10)
                        .addComponent(dataPenyakitBawaan)
                        .addComponent(fieldPenyakitBawaan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel13)
                        .addComponent(dataFaktorResiko)
                        .addComponent(fieldFaktorResiko, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        jScrollPane_STATIS.setViewportView(panelItemSTATIS);

        javax.swing.GroupLayout RekamMedisStatisLayout = new javax.swing.GroupLayout(RekamMedisStatis);
        RekamMedisStatis.setLayout(RekamMedisStatisLayout);
        RekamMedisStatisLayout.setHorizontalGroup(
            RekamMedisStatisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RekamMedisStatisLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(RekamMedisStatisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(RekamMedisStatisLayout.createSequentialGroup()
                        .addComponent(panelAllCRUD_STATIS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane_STATIS, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
        );
        RekamMedisStatisLayout.setVerticalGroup(
            RekamMedisStatisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RekamMedisStatisLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane_STATIS, javax.swing.GroupLayout.DEFAULT_SIZE, 259, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelAllCRUD_STATIS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedAll.addTab("Rekam Medis Statis", new javax.swing.ImageIcon(getClass().getResource("/Icon/list.png")), RekamMedisStatis); // NOI18N

        RekamMedisDinamis.setBackground(new java.awt.Color(255, 255, 255));

        jScrollPane_DINAMIS.setBorder(null);
        jScrollPane_DINAMIS.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane_DINAMIS.setPreferredSize(new java.awt.Dimension(1077, 285));

        panelItemDATA1.setBackground(new java.awt.Color(255, 255, 255));

        labelStack.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        labelStack.setForeground(java.awt.SystemColor.textHighlight);
        labelStack.setText("No. Reccord                :");
        labelStack.setPreferredSize(new java.awt.Dimension(130, 15));

        dataStack.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        dataStack.setForeground(java.awt.SystemColor.textHighlight);
        dataStack.setText("-");

        labelTanggalPeriksa.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelTanggalPeriksa.setText("Tanggal Pemeriksaan      :");
        labelTanggalPeriksa.setPreferredSize(new java.awt.Dimension(130, 15));

        dataTanggalPeriksa.setText("-");

        fieldTanggalPeriksa.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldTanggalPeriksa.setText("ddmmyy");
        fieldTanggalPeriksa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldTanggalPeriksaActionPerformed(evt);
            }
        });

        inputTanggalPeriksa.setText("Input");
        inputTanggalPeriksa.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputTanggalPeriksa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputTanggalPeriksaActionPerformed(evt);
            }
        });

        deleteTanggalPeriksa.setText("Delete");
        deleteTanggalPeriksa.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteTanggalPeriksa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteTanggalPeriksaActionPerformed(evt);
            }
        });

        labelKeluhanutama.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKeluhanutama.setText("Keluhan Utama              :");
        labelKeluhanutama.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKeluhanutama.setText("-");

        fieldKeluhanutama.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldKeluhanutama.setText("--input--");
        fieldKeluhanutama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldKeluhanutamaActionPerformed(evt);
            }
        });

        inputKeluhanutama.setText("Input");
        inputKeluhanutama.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKeluhanutama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKeluhanutamaActionPerformed(evt);
            }
        });

        deleteKeluhanutama.setText("Delete");
        deleteKeluhanutama.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKeluhanutama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKeluhanutamaActionPerformed(evt);
            }
        });

        labelAnamnesa.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelAnamnesa.setText("Anamnesa                     :");
        labelAnamnesa.setPreferredSize(new java.awt.Dimension(130, 15));

        dataAnamnesa.setText("-");

        fieldAnamnesa.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldAnamnesa.setText("ttmmyy");
        fieldAnamnesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldAnamnesaActionPerformed(evt);
            }
        });

        inputAnamnesa.setText("Input");
        inputAnamnesa.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputAnamnesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputAnamnesaActionPerformed(evt);
            }
        });

        deleteAnamnesa.setText("Delete");
        deleteAnamnesa.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteAnamnesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteAnamnesaActionPerformed(evt);
            }
        });

        labelPenyakitDahulu.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelPenyakitDahulu.setText("Riwayat Penyakit Dahulu  :");
        labelPenyakitDahulu.setPreferredSize(new java.awt.Dimension(130, 15));

        dataPenyakitDahulu.setText("-");

        fieldPenyakitDahulu.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldPenyakitDahulu.setText("--input--");
        fieldPenyakitDahulu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldPenyakitDahuluActionPerformed(evt);
            }
        });

        inputPenyakitDahulu.setText("Input");
        inputPenyakitDahulu.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputPenyakitDahulu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputPenyakitDahuluActionPerformed(evt);
            }
        });

        deletePenyakitDahulu.setText("Delete");
        deletePenyakitDahulu.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletePenyakitDahulu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePenyakitDahuluActionPerformed(evt);
            }
        });

        labelPenyakitKeluarga.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelPenyakitKeluarga.setText("Riwayat Penyakit Klrg.     :");
        labelPenyakitKeluarga.setPreferredSize(new java.awt.Dimension(130, 15));

        dataPenyakitKeluarga.setText("-");

        fieldPenyakitKeluarga.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldPenyakitKeluarga.setText("--input--");
        fieldPenyakitKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldPenyakitKeluargaActionPerformed(evt);
            }
        });

        inputPenyakitKeluarga.setText("Input");
        inputPenyakitKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputPenyakitKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputPenyakitKeluargaActionPerformed(evt);
            }
        });

        deletePenyakitKeluarga.setText("Delete");
        deletePenyakitKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletePenyakitKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePenyakitKeluargaActionPerformed(evt);
            }
        });

        labelPemeriksaanFisik.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelPemeriksaanFisik.setText("Pemeriksaan Fisik            :");
        labelPemeriksaanFisik.setPreferredSize(new java.awt.Dimension(130, 15));

        dataPemeriksaanFisik.setText("-");

        fieldPemeriksaanFisik.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldPemeriksaanFisik.setText("--input--");
        fieldPemeriksaanFisik.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldPemeriksaanFisikActionPerformed(evt);
            }
        });

        inputPemeriksaanFisik.setText("Input");
        inputPemeriksaanFisik.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputPemeriksaanFisik.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputPemeriksaanFisikActionPerformed(evt);
            }
        });

        deletePemeriksaanFisik.setText("Delete");
        deletePemeriksaanFisik.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletePemeriksaanFisik.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePemeriksaanFisikActionPerformed(evt);
            }
        });

        labelTinggi.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelTinggi.setText("Tinggi Badan (cm)          :");
        labelTinggi.setPreferredSize(new java.awt.Dimension(130, 15));

        dataTinggi.setText("-");

        fieldTinggi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldTinggi.setText("160");
        fieldTinggi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldTinggiActionPerformed(evt);
            }
        });

        inputTinggi.setText("Input");
        inputTinggi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputTinggi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputTinggiActionPerformed(evt);
            }
        });

        deleteTinggi.setText("Delete");
        deleteTinggi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteTinggi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteTinggiActionPerformed(evt);
            }
        });

        labelBeratbadan.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelBeratbadan.setText("Berat Badan (Kg)           :");
        labelBeratbadan.setPreferredSize(new java.awt.Dimension(130, 15));

        dataBeratbadan.setText("-");

        fieldBeratbadan.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldBeratbadan.setText("60");
        fieldBeratbadan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldBeratbadanActionPerformed(evt);
            }
        });

        inputBeratbadan.setText("Input");
        inputBeratbadan.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputBeratbadan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputBeratbadanActionPerformed(evt);
            }
        });

        deleteBeratbadan.setText("Delete");
        deleteBeratbadan.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteBeratbadan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBeratbadanActionPerformed(evt);
            }
        });

        labelSystole.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelSystole.setText("Systole                         :");
        labelSystole.setPreferredSize(new java.awt.Dimension(130, 15));

        dataSystole.setText("-");

        fieldSystole.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldSystole.setText("110");
        fieldSystole.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldSystoleActionPerformed(evt);
            }
        });

        inputSystole.setText("Input");
        inputSystole.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputSystole.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputSystoleActionPerformed(evt);
            }
        });

        deleteSystole.setText("Delete");
        deleteSystole.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteSystole.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteSystoleActionPerformed(evt);
            }
        });

        labelDiastole.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelDiastole.setText("Diastole                        :");
        labelDiastole.setPreferredSize(new java.awt.Dimension(130, 15));

        dataDiastole.setText("-");

        fieldDiastole.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldDiastole.setText("70");
        fieldDiastole.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldDiastoleActionPerformed(evt);
            }
        });

        inputDiastole.setText("Input");
        inputDiastole.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputDiastole.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputDiastoleActionPerformed(evt);
            }
        });

        deleteDiastole.setText("Delete");
        deleteDiastole.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteDiastole.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteDiastoleActionPerformed(evt);
            }
        });

        labelNadi.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelNadi.setText("Nadi (BPM)                    :");
        labelNadi.setPreferredSize(new java.awt.Dimension(130, 15));

        dataNadi.setText("-");

        fieldNadi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldNadi.setText("60");
        fieldNadi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldNadiActionPerformed(evt);
            }
        });

        inputNadi.setText("Input");
        inputNadi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputNadi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputNadiActionPerformed(evt);
            }
        });

        deleteNadi.setText("Delete");
        deleteNadi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteNadi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteNadiActionPerformed(evt);
            }
        });

        labelKesadaran.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKesadaran.setText("Kesadaran                     :");
        labelKesadaran.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKesadaran.setText("-");

        ComboBox_Kesadaran.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. sama sekali tidak ada respons terhadap rangsang nyeri.", "2. seluruh tubuh pasien kaku, sehingga respons yang diberikan terhadap rangsang nyeri hampir tidak ada.", "3. tubuh pasien menekuk dengan kaku, sehingga hanya bergerak sedikit saat memperoleh rangsang nyeri.", "4. pasien bisa bergerak secara refleks menjauhi sumber rangsang nyeri.", "5. pasien bisa bergerak secara terkontrol apabila memperoleh rangsang nyeri.", "6. pasien dapat melakukan gerakan sesuai arahan." }));

        inputKesadaran.setText("Input");
        inputKesadaran.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKesadaran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKesadaranActionPerformed(evt);
            }
        });

        deleteKesadaran.setText("Delete");
        deleteKesadaran.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKesadaran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKesadaranActionPerformed(evt);
            }
        });

        labelSuhu.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelSuhu.setText("Suhu (Celsius)                :");
        labelSuhu.setPreferredSize(new java.awt.Dimension(130, 15));

        dataSuhu.setText("-");

        fieldSuhu.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldSuhu.setText("25.00");
        fieldSuhu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldSuhuActionPerformed(evt);
            }
        });

        inputSuhu.setText("Input");
        inputSuhu.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputSuhu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputSuhuActionPerformed(evt);
            }
        });

        deleteSuhu.setText("Delete");
        deleteSuhu.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteSuhu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteSuhuActionPerformed(evt);
            }
        });

        labelRespirasi.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelRespirasi.setText("Respirasi                       :");
        labelRespirasi.setPreferredSize(new java.awt.Dimension(130, 15));

        dataRespirasi.setText("-");

        fieldRespirasi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldRespirasi.setText("20");
        fieldRespirasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldRespirasiActionPerformed(evt);
            }
        });

        inputRespirasi.setText("Input");
        inputRespirasi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputRespirasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputRespirasiActionPerformed(evt);
            }
        });

        deleteRespirasi.setText("Delete");
        deleteRespirasi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteRespirasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteRespirasiActionPerformed(evt);
            }
        });

        labelLain.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelLain.setText("Lain-lain                        :");
        labelLain.setPreferredSize(new java.awt.Dimension(130, 15));

        dataLain.setText("-");

        fieldLain.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldLain.setText("--input--");
        fieldLain.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldLainActionPerformed(evt);
            }
        });

        inputLain.setText("Input");
        inputLain.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputLain.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputLainActionPerformed(evt);
            }
        });

        deleteLain.setText("Delete");
        deleteLain.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteLain.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteLainActionPerformed(evt);
            }
        });

        labelLabExecuteFlag.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelLabExecuteFlag.setText("Lab Execute Flag           :");
        labelLabExecuteFlag.setPreferredSize(new java.awt.Dimension(130, 15));

        dataLabExecuteFlag.setText("-");

        inputLabExecuteFlag.setText("Input");
        inputLabExecuteFlag.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputLabExecuteFlag.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputLabExecuteFlagActionPerformed(evt);
            }
        });

        deleteLabExecuteFlag.setText("Delete");
        deleteLabExecuteFlag.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteLabExecuteFlag.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteLabExecuteFlagActionPerformed(evt);
            }
        });

        labelExpertiseLab.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelExpertiseLab.setText("Expertise Lab                :");
        labelExpertiseLab.setPreferredSize(new java.awt.Dimension(130, 15));

        dataExpertiseLab.setText("-");

        fieldExpertiseLab.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldExpertiseLab.setText("--input--");
        fieldExpertiseLab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldExpertiseLabActionPerformed(evt);
            }
        });

        inputExpertiseLab.setText("Input");
        inputExpertiseLab.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputExpertiseLab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputExpertiseLabActionPerformed(evt);
            }
        });

        deleteExpertiseLab.setText("Delete");
        deleteExpertiseLab.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteExpertiseLab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteExpertiseLabActionPerformed(evt);
            }
        });

        labelCatatanLab.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelCatatanLab.setText("Catatan Lab                  :");
        labelCatatanLab.setPreferredSize(new java.awt.Dimension(130, 15));

        dataCatatanLab.setText("-");

        fieldCatatanLab.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldCatatanLab.setText("--input--");
        fieldCatatanLab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldCatatanLabActionPerformed(evt);
            }
        });

        inputCatatanLab.setText("Input");
        inputCatatanLab.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputCatatanLab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputCatatanLabActionPerformed(evt);
            }
        });

        deleteCatatanLab.setText("Delete");
        deleteCatatanLab.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteCatatanLab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteCatatanLabActionPerformed(evt);
            }
        });

        labelTerapi.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelTerapi.setText("Terapi                          :");
        labelTerapi.setPreferredSize(new java.awt.Dimension(130, 15));

        dataTerapi.setText("-");

        fieldTerapi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldTerapi.setText("--input--");
        fieldTerapi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldTerapiActionPerformed(evt);
            }
        });

        inputTerapi.setText("Input");
        inputTerapi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputTerapi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputTerapiActionPerformed(evt);
            }
        });

        deleteTerapi.setText("Delete");
        deleteTerapi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteTerapi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteTerapiActionPerformed(evt);
            }
        });

        labelResep.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelResep.setText("Resep                          :");
        labelResep.setPreferredSize(new java.awt.Dimension(130, 15));

        dataResep.setText("-");

        fieldResep.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldResep.setText("xxxxxxxxxxxxxxxx");
        fieldResep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldResepActionPerformed(evt);
            }
        });

        inputResep.setText("Input");
        inputResep.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputResep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputResepActionPerformed(evt);
            }
        });

        deleteResep.setText("Delete");
        deleteResep.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteResep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteResepActionPerformed(evt);
            }
        });

        labelCatatanresep.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelCatatanresep.setText("Catatan Resep               :");
        labelCatatanresep.setPreferredSize(new java.awt.Dimension(130, 15));

        dataCatatanresep.setText("-");

        fieldCatatanresep.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldCatatanresep.setText("--input--");
        fieldCatatanresep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldCatatanresepActionPerformed(evt);
            }
        });

        inputCatatanresep.setText("Input");
        inputCatatanresep.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputCatatanresep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputCatatanresepActionPerformed(evt);
            }
        });

        deleteCatatanresep.setText("Delete");
        deleteCatatanresep.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteCatatanresep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteCatatanresepActionPerformed(evt);
            }
        });

        labelEksekusiResep.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelEksekusiResep.setText("Eksekusi Resep              :");
        labelEksekusiResep.setPreferredSize(new java.awt.Dimension(130, 15));

        dataEksekusiResep.setText("-");

        inputEksekusiResep.setText("Input");
        inputEksekusiResep.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputEksekusiResep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputEksekusiResepActionPerformed(evt);
            }
        });

        deleteEksekusiResep.setText("Delete");
        deleteEksekusiResep.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteEksekusiResep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteEksekusiResepActionPerformed(evt);
            }
        });

        labelRepetisiresep.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelRepetisiresep.setText("Repetisi Resep               :");
        labelRepetisiresep.setPreferredSize(new java.awt.Dimension(130, 15));

        dataRepetisiresep.setText("-");

        inputRepetisiresep.setText("Input");
        inputRepetisiresep.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputRepetisiresep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputRepetisiresepActionPerformed(evt);
            }
        });

        deleteRepetisiresep.setText("Delete");
        deleteRepetisiresep.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteRepetisiresep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteRepetisiresepActionPerformed(evt);
            }
        });

        labelPrognosa.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelPrognosa.setText("Prognosa                       :");
        labelPrognosa.setPreferredSize(new java.awt.Dimension(130, 15));

        dataPrognosa.setText("-");

        inputPrognosa.setText("Input");
        inputPrognosa.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputPrognosa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputPrognosaActionPerformed(evt);
            }
        });

        deletePrognosa.setText("Delete");
        deletePrognosa.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletePrognosa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePrognosaActionPerformed(evt);
            }
        });

        labelICD1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD1.setText("Kode ICD 1                    :");
        labelICD1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD1.setText("-");

        fieldICD1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICD1.setText("--input--");

        inputICD1.setText("Input");
        inputICD1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICD1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICD1ActionPerformed(evt);
            }
        });

        deleteICD1.setText("Delete");
        deleteICD1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICD1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICD1ActionPerformed(evt);
            }
        });

        labelICD2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD2.setText("Kode ICD 2                   :");
        labelICD2.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD2.setText("-");

        fieldICD2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICD2.setText("--input--");

        inputICD2.setText("Input");
        inputICD2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICD2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICD2ActionPerformed(evt);
            }
        });

        deleteICD2.setText("Delete");
        deleteICD2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICD2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICD2ActionPerformed(evt);
            }
        });

        labelICD3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD3.setText("Kode ICD 3                    :");
        labelICD3.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD3.setText("-");

        fieldICD3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICD3.setText("--input--");

        inputICD3.setText("Input");
        inputICD3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICD3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICD3ActionPerformed(evt);
            }
        });

        deleteICD3.setText("Delete");
        deleteICD3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICD3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICD3ActionPerformed(evt);
            }
        });

        labelICD4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD4.setText("Kode ICD 4                    :");
        labelICD4.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD4.setText("-");

        fieldICD4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICD4.setText("--input--");

        inputICD4.setText("Input");
        inputICD4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICD4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICD4ActionPerformed(evt);
            }
        });

        deleteICD4.setText("Delete");
        deleteICD4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICD4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICD4ActionPerformed(evt);
            }
        });

        labelICD5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD5.setText("Kode ICD 5                    :");
        labelICD5.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD5.setText("-");

        fieldICD5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICD5.setText("--input--");

        inputICD5.setText("Input");
        inputICD5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICD5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICD5ActionPerformed(evt);
            }
        });

        deleteICD5.setText("Delete");
        deleteICD5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICD5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICD5ActionPerformed(evt);
            }
        });

        labelICD6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD6.setText("Kode ICD 6                    :");
        labelICD6.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD6.setText("-");

        fieldICD6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICD6.setText("--input--");

        inputICD6.setText("Input");
        inputICD6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICD6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICD6ActionPerformed(evt);
            }
        });

        deleteICD6.setText("Delete");
        deleteICD6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICD6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICD6ActionPerformed(evt);
            }
        });

        labelICD7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD7.setText("Kode ICD 7                    :");
        labelICD7.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD7.setText("-");

        fieldICD7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICD7.setText("--input--");

        inputICD7.setText("Input");
        inputICD7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICD7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICD7ActionPerformed(evt);
            }
        });

        deleteICD7.setText("Delete");
        deleteICD7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICD7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICD7ActionPerformed(evt);
            }
        });

        labelICD8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD8.setText("Kode ICD 8                    :");
        labelICD8.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD8.setText("-");

        fieldICD8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICD8.setText("--input--");

        inputICD8.setText("Input");
        inputICD8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICD8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICD8ActionPerformed(evt);
            }
        });

        deleteICD8.setText("Delete");
        deleteICD8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICD8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICD8ActionPerformed(evt);
            }
        });

        labelICD9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD9.setText("Kode ICD 9                    :");
        labelICD9.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD9.setText("-");

        fieldICD9.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICD9.setText("--input--");

        inputICD9.setText("Input");
        inputICD9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICD9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICD9ActionPerformed(evt);
            }
        });

        deleteICD9.setText("Delete");
        deleteICD9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICD9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICD9ActionPerformed(evt);
            }
        });

        labelICD10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD10.setText("Kode ICD 10                  :");
        labelICD10.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD10.setText("-");

        fieldICD10.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICD10.setText("--input--");

        inputICD10.setText("Input");
        inputICD10.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICD10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICD10ActionPerformed(evt);
            }
        });

        deleteICD10.setText("Delete");
        deleteICD10.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICD10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICD10ActionPerformed(evt);
            }
        });

        labelICDDiagnosa1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa1.setText("Kode ICD Diagnosa 1       :");
        labelICDDiagnosa1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa1.setText("-");

        fieldICDDiagnosa1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICDDiagnosa1.setText("1");

        inputICDDiagnosa1.setText("Input");
        inputICDDiagnosa1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICDDiagnosa1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICDDiagnosa1ActionPerformed(evt);
            }
        });

        deleteICDDiagnosa1.setText("Delete");
        deleteICDDiagnosa1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICDDiagnosa1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICDDiagnosa1ActionPerformed(evt);
            }
        });

        labelICDDiagnosa2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa2.setText("Kode ICD Diagnosa 2       :");
        labelICDDiagnosa2.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa2.setText("-");

        fieldICDDiagnosa2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICDDiagnosa2.setText("2");

        inputICDDiagnosa2.setText("Input");
        inputICDDiagnosa2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICDDiagnosa2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICDDiagnosa2ActionPerformed(evt);
            }
        });

        deleteICDDiagnosa2.setText("Delete");
        deleteICDDiagnosa2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICDDiagnosa2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICDDiagnosa2ActionPerformed(evt);
            }
        });

        labelICDDiagnosa3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa3.setText("Kode ICD Diagnosa 3      :");
        labelICDDiagnosa3.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa3.setText("-");

        fieldICDDiagnosa3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICDDiagnosa3.setText("3");

        inputICDDiagnosa3.setText("Input");
        inputICDDiagnosa3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICDDiagnosa3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICDDiagnosa3ActionPerformed(evt);
            }
        });

        deleteICDDiagnosa3.setText("Delete");
        deleteICDDiagnosa3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICDDiagnosa3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICDDiagnosa3ActionPerformed(evt);
            }
        });

        labelICDDiagnosa4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa4.setText("Kode ICD Diagnosa 4       :");
        labelICDDiagnosa4.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa4.setText("-");

        fieldICDDiagnosa4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICDDiagnosa4.setText("4");

        inputICDDiagnosa4.setText("Input");
        inputICDDiagnosa4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICDDiagnosa4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICDDiagnosa4ActionPerformed(evt);
            }
        });

        deleteICDDiagnosa4.setText("Delete");
        deleteICDDiagnosa4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICDDiagnosa4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICDDiagnosa4ActionPerformed(evt);
            }
        });

        labelICDDiagnosa5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa5.setText("Kode ICD Diagnosa 5       :");
        labelICDDiagnosa5.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa5.setText("-");

        fieldICDDiagnosa5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICDDiagnosa5.setText("5");

        inputICDDiagnosa5.setText("Input");
        inputICDDiagnosa5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICDDiagnosa5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICDDiagnosa5ActionPerformed(evt);
            }
        });

        deleteICDDiagnosa5.setText("Delete");
        deleteICDDiagnosa5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICDDiagnosa5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICDDiagnosa5ActionPerformed(evt);
            }
        });

        labelICDDiagnosa6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa6.setText("Kode ICD Diagnosa 6       :");
        labelICDDiagnosa6.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa6.setText("-");

        fieldICDDiagnosa6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICDDiagnosa6.setText("6");
        fieldICDDiagnosa6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldICDDiagnosa6ActionPerformed(evt);
            }
        });

        inputICDDiagnosa6.setText("Input");
        inputICDDiagnosa6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICDDiagnosa6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICDDiagnosa6ActionPerformed(evt);
            }
        });

        deleteICDDiagnosa6.setText("Delete");
        deleteICDDiagnosa6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICDDiagnosa6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICDDiagnosa6ActionPerformed(evt);
            }
        });

        labelICDDiagnosa7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa7.setText("Kode ICD Diagnosa 7       :");
        labelICDDiagnosa7.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa7.setText("-");

        fieldICDDiagnosa7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICDDiagnosa7.setText("7");
        fieldICDDiagnosa7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldICDDiagnosa7ActionPerformed(evt);
            }
        });

        inputICDDiagnosa7.setText("Input");
        inputICDDiagnosa7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICDDiagnosa7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICDDiagnosa7ActionPerformed(evt);
            }
        });

        deleteICDDiagnosa7.setText("Delete");
        deleteICDDiagnosa7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICDDiagnosa7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICDDiagnosa7ActionPerformed(evt);
            }
        });

        labelICDDiagnosa8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa8.setText("Kode ICD Diagnosa 8       :");
        labelICDDiagnosa8.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa8.setText("-");

        fieldICDDiagnosa8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICDDiagnosa8.setText("8");
        fieldICDDiagnosa8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldICDDiagnosa8ActionPerformed(evt);
            }
        });

        inputICDDiagnosa8.setText("Input");
        inputICDDiagnosa8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICDDiagnosa8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICDDiagnosa8ActionPerformed(evt);
            }
        });

        deleteICDDiagnosa8.setText("Delete");
        deleteICDDiagnosa8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICDDiagnosa8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICDDiagnosa8ActionPerformed(evt);
            }
        });

        labelICDDiagnosa9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa9.setText("Kode ICD Diagnosa 9       :");
        labelICDDiagnosa9.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa9.setText("-");

        fieldICDDiagnosa9.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICDDiagnosa9.setText("9");
        fieldICDDiagnosa9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldICDDiagnosa9ActionPerformed(evt);
            }
        });

        inputICDDiagnosa9.setText("Input");
        inputICDDiagnosa9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICDDiagnosa9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICDDiagnosa9ActionPerformed(evt);
            }
        });

        deleteICDDiagnosa9.setText("Delete");
        deleteICDDiagnosa9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICDDiagnosa9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICDDiagnosa9ActionPerformed(evt);
            }
        });

        labelICDDiagnosa10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa10.setText("Kode ICD Diagnosa 10     :");
        labelICDDiagnosa10.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa10.setText("-");

        fieldICDDiagnosa10.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldICDDiagnosa10.setText("--input--");

        inputICDDiagnosa10.setText("Input");
        inputICDDiagnosa10.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputICDDiagnosa10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputICDDiagnosa10ActionPerformed(evt);
            }
        });

        deleteICDDiagnosa10.setText("Delete");
        deleteICDDiagnosa10.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteICDDiagnosa10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteICDDiagnosa10ActionPerformed(evt);
            }
        });

        labelPoliTujuan.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelPoliTujuan.setText("Poli Tujuan                    :");
        labelPoliTujuan.setPreferredSize(new java.awt.Dimension(130, 15));

        dataPoliTujuan.setText("-");

        fieldPoliTujuan.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldPoliTujuan.setText("--input--");

        inputPoliTujuan.setText("Input");
        inputPoliTujuan.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputPoliTujuan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputPoliTujuanActionPerformed(evt);
            }
        });

        deletePoliTujuan.setText("Delete");
        deletePoliTujuan.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletePoliTujuan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePoliTujuanActionPerformed(evt);
            }
        });

        labelRujukan.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelRujukan.setText("Rujukan                        :");
        labelRujukan.setPreferredSize(new java.awt.Dimension(130, 15));

        dataRujukan.setText("-");

        fieldRujukan.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldRujukan.setText("--input--");

        inputRujukan.setText("Input");
        inputRujukan.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputRujukan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputRujukanActionPerformed(evt);
            }
        });

        deleteRujukan.setText("Delete");
        deleteRujukan.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteRujukan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteRujukanActionPerformed(evt);
            }
        });

        labelIDPuskesmas.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelIDPuskesmas.setText("ID Puskesmas                 :");
        labelIDPuskesmas.setPreferredSize(new java.awt.Dimension(130, 15));

        dataIDPuskesmas.setText("-");

        fieldIDPuskesmas.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldIDPuskesmas.setText("--input--");

        inputIDPuskesmas.setText("Input");
        inputIDPuskesmas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputIDPuskesmas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputIDPuskesmasActionPerformed(evt);
            }
        });

        deleteIDPuskesmas.setText("Delete");
        deleteIDPuskesmas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteIDPuskesmas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteIDPuskesmasActionPerformed(evt);
            }
        });

        ComboBox_LabExecuteFlag.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. Dilayani penuh", "2. Tidak Dilayani sama sekali", "3. Dilayani sebagian" }));

        ComboBox_EksekusiResep.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. Dilayani penuh", "2. Tidak Dilayani sama sekali", "3. Dilayani sebagian", "4. Dilayani, ada penggantian;", "5. Dilayani sebagian dan ada penggantian" }));

        ComboBox_Repetisiresep.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. Repetisiresep1", "2. Repetisiresep2", "3. Repetisiresep3", "4. Repetisiresep4", "5. Repetisiresep5" }));

        ComboBox_Prognosa.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. Ad functionam :ad bonam", "2. Ad functionam :dubia ad bonam", "3. Ad functionam :dubia ad malam", "4. Ad functionam :ad malam", "5. Ad vitam :ad bonam", "6. Ad vitam :dubia ad bonam", "7. Ad vitam :dubia ad malam", "8. Ad vitam :ad malam" }));

        javax.swing.GroupLayout panelItemDATA1Layout = new javax.swing.GroupLayout(panelItemDATA1);
        panelItemDATA1.setLayout(panelItemDATA1Layout);
        panelItemDATA1Layout.setHorizontalGroup(
            panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelDiastole, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataDiastole, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldDiastole, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputDiastole, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteDiastole, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelNadi, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataNadi, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldNadi, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputNadi, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteNadi, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(labelKesadaran, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataKesadaran, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ComboBox_Kesadaran, 0, 1, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(labelSuhu, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataSuhu, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldSuhu, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(inputSuhu, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteSuhu, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(inputKesadaran, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteKesadaran, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelLain, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataLain, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldLain, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputLain, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteLain, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(labelLabExecuteFlag, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataLabExecuteFlag, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ComboBox_LabExecuteFlag, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(labelExpertiseLab, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataExpertiseLab, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldExpertiseLab, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(inputExpertiseLab, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteExpertiseLab, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(inputLabExecuteFlag, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteLabExecuteFlag, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICD3, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICD3, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICD3, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICD3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICD3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICD4, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICD4, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICD4, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICD4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICD4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICD5, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICD5, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICD5, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICD5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICD5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICD6, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICD6, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICD6, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICD6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICD6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICD7, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICD7, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICD7, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICD7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICD7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICD8, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICD8, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICD8, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICD8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICD8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICD9, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICD9, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICD9, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICD9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICD9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICD10, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICD10, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICD10, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICD10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICD10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICDDiagnosa1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICDDiagnosa1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICDDiagnosa1, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICDDiagnosa1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICDDiagnosa1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICDDiagnosa2, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICDDiagnosa2, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICDDiagnosa2, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICDDiagnosa2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICDDiagnosa2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICDDiagnosa3, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICDDiagnosa3, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICDDiagnosa3, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICDDiagnosa3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICDDiagnosa3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICDDiagnosa4, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICDDiagnosa4, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICDDiagnosa4, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICDDiagnosa4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICDDiagnosa4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICDDiagnosa5, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICDDiagnosa5, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICDDiagnosa5, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICDDiagnosa5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICDDiagnosa5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICDDiagnosa6, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICDDiagnosa6, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICDDiagnosa6, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICDDiagnosa6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICDDiagnosa6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICDDiagnosa7, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICDDiagnosa7, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICDDiagnosa7, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICDDiagnosa7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICDDiagnosa7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICDDiagnosa8, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICDDiagnosa8, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICDDiagnosa8, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICDDiagnosa8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICDDiagnosa8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICDDiagnosa9, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICDDiagnosa9, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICDDiagnosa9, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICDDiagnosa9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICDDiagnosa9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelICDDiagnosa10, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataICDDiagnosa10, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldICDDiagnosa10, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputICDDiagnosa10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteICDDiagnosa10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelPoliTujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataPoliTujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldPoliTujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputPoliTujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deletePoliTujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelRujukan, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataRujukan, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldRujukan, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputRujukan, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteRujukan, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelIDPuskesmas, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataIDPuskesmas, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldIDPuskesmas, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputIDPuskesmas, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteIDPuskesmas, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelSystole, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataSystole, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldSystole, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputSystole, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteSystole, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelBeratbadan, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataBeratbadan, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldBeratbadan, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputBeratbadan, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteBeratbadan, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelStack, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataStack, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelTanggalPeriksa, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataTanggalPeriksa, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldTanggalPeriksa, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputTanggalPeriksa, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteTanggalPeriksa, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelKeluhanutama, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataKeluhanutama, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldKeluhanutama, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputKeluhanutama, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteKeluhanutama, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelAnamnesa, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataAnamnesa, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldAnamnesa, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputAnamnesa, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteAnamnesa, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelPenyakitDahulu, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataPenyakitDahulu, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldPenyakitDahulu, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputPenyakitDahulu, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deletePenyakitDahulu, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelPenyakitKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataPenyakitKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldPenyakitKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputPenyakitKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deletePenyakitKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(labelPemeriksaanFisik, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataPemeriksaanFisik, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldPemeriksaanFisik, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(labelTinggi, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataTinggi, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldTinggi, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(inputTinggi, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteTinggi, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(inputPemeriksaanFisik, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deletePemeriksaanFisik, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelRespirasi, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataRespirasi, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldRespirasi, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputRespirasi, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteRespirasi, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelCatatanLab, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataCatatanLab, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldCatatanLab, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputCatatanLab, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteCatatanLab, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelTerapi, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataTerapi, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldTerapi, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputTerapi, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteTerapi, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addComponent(labelResep, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataResep, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldResep, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputResep, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteResep, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(labelICD2, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICD2, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldICD2))
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(labelICD1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICD1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldICD1))
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(labelPrognosa, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataPrognosa, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ComboBox_Prognosa, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(labelRepetisiresep, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataRepetisiresep, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ComboBox_Repetisiresep, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(labelEksekusiResep, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataEksekusiResep, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ComboBox_EksekusiResep, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(labelCatatanresep, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataCatatanresep, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldCatatanresep, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(inputICD2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteICD2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(inputCatatanresep, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteCatatanresep, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(inputEksekusiResep, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteEksekusiResep, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(inputRepetisiresep, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteRepetisiresep, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(inputPrognosa, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deletePrognosa, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addComponent(inputICD1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteICD1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        panelItemDATA1Layout.setVerticalGroup(
            panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelStack, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(dataStack, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelTanggalPeriksa, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataTanggalPeriksa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldTanggalPeriksa)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputTanggalPeriksa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteTanggalPeriksa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKeluhanutama, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataKeluhanutama, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldKeluhanutama)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputKeluhanutama, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteKeluhanutama, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelAnamnesa, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataAnamnesa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldAnamnesa)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputAnamnesa, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteAnamnesa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelPenyakitDahulu, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataPenyakitDahulu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldPenyakitDahulu)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputPenyakitDahulu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deletePenyakitDahulu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelPenyakitKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataPenyakitKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldPenyakitKeluarga)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputPenyakitKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deletePenyakitKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelPemeriksaanFisik, javax.swing.GroupLayout.DEFAULT_SIZE, 17, Short.MAX_VALUE))
                    .addComponent(dataPemeriksaanFisik, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputPemeriksaanFisik, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldPemeriksaanFisik)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deletePemeriksaanFisik, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelTinggi, javax.swing.GroupLayout.DEFAULT_SIZE, 18, Short.MAX_VALUE))
                    .addComponent(dataTinggi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldTinggi)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputTinggi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteTinggi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelBeratbadan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataBeratbadan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(inputBeratbadan, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(deleteBeratbadan, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldBeratbadan, javax.swing.GroupLayout.DEFAULT_SIZE, 21, Short.MAX_VALUE))))
                .addGap(7, 7, 7)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(dataSystole, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(labelSystole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fieldSystole, javax.swing.GroupLayout.DEFAULT_SIZE, 21, Short.MAX_VALUE)
                    .addComponent(inputSystole, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(deleteSystole))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelDiastole, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataDiastole, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputDiastole, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldDiastole)
                            .addComponent(deleteDiastole, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelNadi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataNadi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputNadi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldNadi)
                            .addComponent(deleteNadi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKesadaran, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKesadaran, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputKesadaran, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_Kesadaran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteKesadaran, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelSuhu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataSuhu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputSuhu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldSuhu)
                            .addComponent(deleteSuhu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelRespirasi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataRespirasi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldRespirasi)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputRespirasi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteRespirasi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelLain, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataLain, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputLain, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldLain)
                            .addComponent(deleteLain, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(labelLabExecuteFlag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(dataLabExecuteFlag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(labelExpertiseLab, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(dataExpertiseLab, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(panelItemDATA1Layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(inputExpertiseLab, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(fieldExpertiseLab)
                                    .addComponent(deleteExpertiseLab, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ComboBox_LabExecuteFlag, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(inputLabExecuteFlag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(deleteLabExecuteFlag, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelCatatanLab, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataCatatanLab, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldCatatanLab)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputCatatanLab, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteCatatanLab, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelTerapi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataTerapi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldTerapi)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputTerapi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteTerapi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelResep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataResep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldResep)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputResep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteResep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelCatatanresep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataCatatanresep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputCatatanresep)
                            .addComponent(fieldCatatanresep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteCatatanresep))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelEksekusiResep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataEksekusiResep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputEksekusiResep)
                            .addComponent(ComboBox_EksekusiResep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteEksekusiResep))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelRepetisiresep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataRepetisiresep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputRepetisiresep)
                            .addComponent(ComboBox_Repetisiresep, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteRepetisiresep))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelPrognosa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataPrognosa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputPrognosa)
                            .addComponent(ComboBox_Prognosa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deletePrognosa))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICD1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICD1)
                            .addComponent(fieldICD1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteICD1))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICD2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICD2)
                            .addComponent(fieldICD2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteICD2))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICD3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICD3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICD3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICD3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICD4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICD4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICD4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICD4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICD5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICD5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICD5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICD5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICD6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICD6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICD6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICD6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICD7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICD7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICD7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICD7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICD8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICD8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICD8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICD8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICD9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICD9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICD9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICD9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICD10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICD10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICD10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICD10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICDDiagnosa1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICDDiagnosa1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICDDiagnosa1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICDDiagnosa2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICDDiagnosa2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICDDiagnosa2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICDDiagnosa3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICDDiagnosa3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICDDiagnosa3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICDDiagnosa4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICDDiagnosa4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICDDiagnosa4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICDDiagnosa5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICDDiagnosa5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICDDiagnosa5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICDDiagnosa6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICDDiagnosa6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICDDiagnosa6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICDDiagnosa7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICDDiagnosa7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICDDiagnosa7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICDDiagnosa8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICDDiagnosa8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICDDiagnosa8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICDDiagnosa9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICDDiagnosa9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICDDiagnosa9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputICDDiagnosa10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldICDDiagnosa10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteICDDiagnosa10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelPoliTujuan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataPoliTujuan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputPoliTujuan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldPoliTujuan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deletePoliTujuan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelRujukan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataRujukan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputRujukan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldRujukan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteRujukan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelIDPuskesmas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataIDPuskesmas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATA1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputIDPuskesmas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldIDPuskesmas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATA1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteIDPuskesmas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jScrollPane_DINAMIS.setViewportView(panelItemDATA1);

        updateAllDINAMIS.setBackground(new java.awt.Color(255, 255, 255));
        updateAllDINAMIS.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        updateAllDINAMIS.setForeground(java.awt.SystemColor.activeCaption);
        updateAllDINAMIS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/update.png"))); // NOI18N
        updateAllDINAMIS.setText("Input All Item Data DInamis");
        updateAllDINAMIS.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.SystemColor.activeCaption, new java.awt.Color(255, 255, 255), java.awt.SystemColor.controlHighlight, java.awt.SystemColor.activeCaption));
        updateAllDINAMIS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateAllDINAMISgetAllSTATIS1ActionPerformed(evt);
            }
        });

        deleteAllDINAMIS.setBackground(new java.awt.Color(255, 255, 255));
        deleteAllDINAMIS.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        deleteAllDINAMIS.setForeground(java.awt.SystemColor.activeCaption);
        deleteAllDINAMIS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/delete.png"))); // NOI18N
        deleteAllDINAMIS.setText("Delete All Item Data Dinamis");
        deleteAllDINAMIS.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.SystemColor.activeCaption, new java.awt.Color(255, 255, 255), java.awt.SystemColor.controlHighlight, java.awt.SystemColor.activeCaption));
        deleteAllDINAMIS.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        deleteAllDINAMIS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteAllDINAMISdeleteAllSTATIS1ActionPerformed(evt);
            }
        });

        registerlDINAMIS.setBackground(new java.awt.Color(153, 153, 153));
        registerlDINAMIS.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        registerlDINAMIS.setForeground(java.awt.SystemColor.activeCaption);
        registerlDINAMIS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/save.png"))); // NOI18N
        registerlDINAMIS.setText("Register Record");
        registerlDINAMIS.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.SystemColor.activeCaption, new java.awt.Color(255, 255, 255), java.awt.SystemColor.controlHighlight, java.awt.SystemColor.activeCaption));
        registerlDINAMIS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerlDINAMISinputAllSTATIS1ActionPerformed(evt);
            }
        });

        labelCurrentStack.setText("No. Record Dinamis Tersimpan (Stack) :");

        fieldCurrentStack.setFont(new java.awt.Font("Tahoma", 2, 12)); // NOI18N
        fieldCurrentStack.setText("--stack--");

        GetStackDinamis.setBackground(java.awt.SystemColor.activeCaption);
        GetStackDinamis.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        GetStackDinamis.setText("Get Current Stack");
        GetStackDinamis.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        GetStackDinamis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GetStackDinamisActionPerformed(evt);
            }
        });

        getAllDinamis_current.setBackground(new java.awt.Color(153, 153, 153));
        getAllDinamis_current.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        getAllDinamis_current.setForeground(java.awt.SystemColor.activeCaption);
        getAllDinamis_current.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/retrieve.png"))); // NOI18N
        getAllDinamis_current.setText("Get All Item Data Dinamis");
        getAllDinamis_current.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.SystemColor.activeCaption, new java.awt.Color(255, 255, 255), java.awt.SystemColor.controlHighlight, java.awt.SystemColor.activeCaption));
        getAllDinamis_current.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getAllDinamis_currentinputAllSTATIS1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelAllCRUD_STATIS2Layout = new javax.swing.GroupLayout(panelAllCRUD_STATIS2);
        panelAllCRUD_STATIS2.setLayout(panelAllCRUD_STATIS2Layout);
        panelAllCRUD_STATIS2Layout.setHorizontalGroup(
            panelAllCRUD_STATIS2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAllCRUD_STATIS2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(updateAllDINAMIS)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(deleteAllDINAMIS)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(getAllDinamis_current)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(registerlDINAMIS)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelAllCRUD_STATIS2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelAllCRUD_STATIS2Layout.createSequentialGroup()
                        .addComponent(labelCurrentStack)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldCurrentStack))
                    .addComponent(GetStackDinamis, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        panelAllCRUD_STATIS2Layout.setVerticalGroup(
            panelAllCRUD_STATIS2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAllCRUD_STATIS2Layout.createSequentialGroup()
                .addGroup(panelAllCRUD_STATIS2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelAllCRUD_STATIS2Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addGroup(panelAllCRUD_STATIS2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(labelCurrentStack)
                            .addComponent(fieldCurrentStack))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(GetStackDinamis, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelAllCRUD_STATIS2Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(panelAllCRUD_STATIS2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelAllCRUD_STATIS2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(deleteAllDINAMIS)
                                .addComponent(registerlDINAMIS)
                                .addComponent(getAllDinamis_current))
                            .addComponent(updateAllDINAMIS))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout RekamMedisDinamisLayout = new javax.swing.GroupLayout(RekamMedisDinamis);
        RekamMedisDinamis.setLayout(RekamMedisDinamisLayout);
        RekamMedisDinamisLayout.setHorizontalGroup(
            RekamMedisDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RekamMedisDinamisLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(RekamMedisDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane_DINAMIS, javax.swing.GroupLayout.DEFAULT_SIZE, 1066, Short.MAX_VALUE)
                    .addComponent(panelAllCRUD_STATIS2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        RekamMedisDinamisLayout.setVerticalGroup(
            RekamMedisDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RekamMedisDinamisLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane_DINAMIS, javax.swing.GroupLayout.DEFAULT_SIZE, 259, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelAllCRUD_STATIS2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedAll.addTab("Rekam Medis Dinamis", new javax.swing.ImageIcon(getClass().getResource("/Icon/list3.png")), RekamMedisDinamis); // NOI18N

        RekamMedisDinamis1.setBackground(new java.awt.Color(255, 255, 255));

        jScrollPane_ViewDinamis.setBorder(null);
        jScrollPane_ViewDinamis.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane_ViewDinamis.setPreferredSize(new java.awt.Dimension(1077, 285));

        panelViewDinamis.setBackground(new java.awt.Color(255, 255, 255));

        labelStack1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        labelStack1.setForeground(java.awt.SystemColor.textHighlight);
        labelStack1.setText("No. Reccord                  :");
        labelStack1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataStack1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        dataStack1.setForeground(java.awt.SystemColor.textHighlight);
        dataStack1.setText("-");

        labelTanggalPeriksa1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelTanggalPeriksa1.setText("Tanggal Pemeriksaan      :");
        labelTanggalPeriksa1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataTanggalPeriksa1.setText("-");

        labelKeluhanutama1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKeluhanutama1.setText("Keluhan Utama              :");
        labelKeluhanutama1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKeluhanutama1.setText("-");

        labelAnamnesa1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelAnamnesa1.setText("Anamnesa                     :");
        labelAnamnesa1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataAnamnesa1.setText("-");

        labelPenyakitDahulu1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelPenyakitDahulu1.setText("Riwayat Penyakit Dahulu  :");
        labelPenyakitDahulu1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataPenyakitDahulu1.setText("-");

        labelPenyakitKeluarga1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelPenyakitKeluarga1.setText("Riwayat Penyakit Klrg.     :");
        labelPenyakitKeluarga1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataPenyakitKeluarga1.setText("-");

        labelPemeriksaanFisik1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelPemeriksaanFisik1.setText("Pemeriksaan Fisik            :");
        labelPemeriksaanFisik1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataPemeriksaanFisik1.setText("-");

        labelTinggi1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelTinggi1.setText("Tinggi Badan (cm)          :");
        labelTinggi1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataTinggi1.setText("-");

        labelBeratbadan1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelBeratbadan1.setText("Berat Badan (Kg)           :");
        labelBeratbadan1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataBeratbadan1.setText("-");

        labelSystole1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelSystole1.setText("Systole                         :");
        labelSystole1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataSystole1.setText("-");

        labelDiastole1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelDiastole1.setText("Diastole                        :");
        labelDiastole1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataDiastole1.setText("-");

        labelNadi1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelNadi1.setText("Nadi (BPM)                    :");
        labelNadi1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataNadi1.setText("-");

        labelKesadaran1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKesadaran1.setText("Kesadaran                     :");
        labelKesadaran1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKesadaran1.setText("-");

        labelSuhu1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelSuhu1.setText("Suhu (Celsius)                :");
        labelSuhu1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataSuhu1.setText("-");

        labelRespirasi1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelRespirasi1.setText("Respirasi                       :");
        labelRespirasi1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataRespirasi1.setText("-");

        labelLain1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelLain1.setText("Lain-lain                        :");
        labelLain1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataLain1.setText("-");

        labelLabExecuteFlag1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelLabExecuteFlag1.setText("Lab Execute Flag           :");
        labelLabExecuteFlag1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataLabExecuteFlag1.setText("-");

        labelExpertiseLab1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelExpertiseLab1.setText("Expertise Lab                :");
        labelExpertiseLab1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataExpertiseLab1.setText("-");

        labelCatatanLab1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelCatatanLab1.setText("Catatan Lab                  :");
        labelCatatanLab1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataCatatanLab1.setText("-");

        labelTerapi1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelTerapi1.setText("Terapi                          :");
        labelTerapi1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataTerapi1.setText("-");

        labelResep1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelResep1.setText("Resep                          :");
        labelResep1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataResep1.setText("-");

        labelCatatanresep1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelCatatanresep1.setText("Catatan Resep               :");
        labelCatatanresep1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataCatatanresep1.setText("-");

        labelEksekusiResep1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelEksekusiResep1.setText("Eksekusi Resep              :");
        labelEksekusiResep1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataEksekusiResep1.setText("-");

        labelRepetisiresep1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelRepetisiresep1.setText("Repetisi Resep               :");
        labelRepetisiresep1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataRepetisiresep1.setText("-");

        labelPrognosa1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelPrognosa1.setText("Prognosa                       :");
        labelPrognosa1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataPrognosa1.setText("-");

        labelICD11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD11.setText("Kode ICD 1                    :");
        labelICD11.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD11.setText("-");

        labelICD12.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD12.setText("Kode ICD 2                   :");
        labelICD12.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD12.setText("-");

        labelICD13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD13.setText("Kode ICD 3                    :");
        labelICD13.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD13.setText("-");

        labelICD14.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD14.setText("Kode ICD 4                    :");
        labelICD14.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD14.setText("-");

        labelICD15.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD15.setText("Kode ICD 5                    :");
        labelICD15.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD15.setText("-");

        labelICD16.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD16.setText("Kode ICD 6                    :");
        labelICD16.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD16.setText("-");

        labelICD17.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD17.setText("Kode ICD 7                    :");
        labelICD17.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD17.setText("-");

        labelICD18.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD18.setText("Kode ICD 8                    :");
        labelICD18.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD18.setText("-");

        labelICD19.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD19.setText("Kode ICD 9                    :");
        labelICD19.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD19.setText("-");

        labelICD20.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICD20.setText("Kode ICD 10                  :");
        labelICD20.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICD20.setText("-");

        labelICDDiagnosa11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa11.setText("Kode ICD Diagnosa 1       :");
        labelICDDiagnosa11.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa11.setText("-");

        labelICDDiagnosa12.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa12.setText("Kode ICD Diagnosa 2       :");
        labelICDDiagnosa12.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa12.setText("-");

        labelICDDiagnosa13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa13.setText("Kode ICD Diagnosa 3      :");
        labelICDDiagnosa13.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa13.setText("-");

        labelICDDiagnosa14.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa14.setText("Kode ICD Diagnosa 4       :");
        labelICDDiagnosa14.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa14.setText("-");

        labelICDDiagnosa15.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa15.setText("Kode ICD Diagnosa 5       :");
        labelICDDiagnosa15.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa15.setText("-");

        labelICDDiagnosa16.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa16.setText("Kode ICD Diagnosa 6       :");
        labelICDDiagnosa16.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa16.setText("-");

        labelICDDiagnosa17.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa17.setText("Kode ICD Diagnosa 7       :");
        labelICDDiagnosa17.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa17.setText("-");

        labelICDDiagnosa18.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa18.setText("Kode ICD Diagnosa 8       :");
        labelICDDiagnosa18.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa18.setText("-");

        labelICDDiagnosa19.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa19.setText("Kode ICD Diagnosa 9       :");
        labelICDDiagnosa19.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa19.setText("-");

        labelICDDiagnosa20.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelICDDiagnosa20.setText("Kode ICD Diagnosa 10     :");
        labelICDDiagnosa20.setPreferredSize(new java.awt.Dimension(130, 15));

        dataICDDiagnosa20.setText("-");

        labelPoliTujuan1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelPoliTujuan1.setText("Poli Tujuan                    :");
        labelPoliTujuan1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataPoliTujuan1.setText("-");

        labelRujukan1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelRujukan1.setText("Rujukan                        :");
        labelRujukan1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataRujukan1.setText("-");

        labelIDPuskesmas1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelIDPuskesmas1.setText("ID Puskesmas                 :");
        labelIDPuskesmas1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataIDPuskesmas1.setText("-");

        javax.swing.GroupLayout panelViewDinamisLayout = new javax.swing.GroupLayout(panelViewDinamis);
        panelViewDinamis.setLayout(panelViewDinamisLayout);
        panelViewDinamisLayout.setHorizontalGroup(
            panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelExpertiseLab1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataExpertiseLab1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelTinggi1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataTinggi1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelPemeriksaanFisik1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataPemeriksaanFisik1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelLabExecuteFlag1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataLabExecuteFlag1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelLain1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataLain1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelSuhu1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataSuhu1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelKesadaran1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataKesadaran1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelNadi1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataNadi1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelDiastole1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataDiastole1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelSystole1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataSystole1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelBeratbadan1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataBeratbadan1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelStack1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataStack1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelTanggalPeriksa1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataTanggalPeriksa1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelKeluhanutama1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataKeluhanutama1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelAnamnesa1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataAnamnesa1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelPenyakitDahulu1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataPenyakitDahulu1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelPenyakitKeluarga1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataPenyakitKeluarga1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelRespirasi1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataRespirasi1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelCatatanLab1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataCatatanLab1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelTerapi1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataTerapi1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelResep1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataResep1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelIDPuskesmas1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataIDPuskesmas1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICD13, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICD13, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICD14, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICD14, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICDDiagnosa14, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICDDiagnosa14, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICDDiagnosa15, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICDDiagnosa15, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelRujukan1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataRujukan1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelPoliTujuan1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataPoliTujuan1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICDDiagnosa20, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICDDiagnosa20, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICDDiagnosa19, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICDDiagnosa19, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICDDiagnosa16, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICDDiagnosa16, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICDDiagnosa17, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICDDiagnosa17, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICDDiagnosa18, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICDDiagnosa18, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(487, Short.MAX_VALUE))
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICD11, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICD11, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICD12, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICD12, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelPrognosa1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataPrognosa1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelCatatanresep1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataCatatanresep1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelEksekusiResep1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataEksekusiResep1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelRepetisiresep1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataRepetisiresep1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICDDiagnosa11, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICDDiagnosa11, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICDDiagnosa13, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICDDiagnosa13, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICDDiagnosa12, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICDDiagnosa12, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICD19, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICD19, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICD20, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICD20, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICD18, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICD18, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICD15, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICD15, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICD16, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICD16, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                                .addComponent(labelICD17, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataICD17, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        panelViewDinamisLayout.setVerticalGroup(
            panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelViewDinamisLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelStack1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataStack1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelTanggalPeriksa1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataTanggalPeriksa1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKeluhanutama1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKeluhanutama1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelAnamnesa1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataAnamnesa1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelPenyakitDahulu1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataPenyakitDahulu1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelPenyakitKeluarga1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataPenyakitKeluarga1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelPemeriksaanFisik1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataPemeriksaanFisik1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelTinggi1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataTinggi1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelBeratbadan1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataBeratbadan1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelSystole1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataSystole1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelDiastole1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataDiastole1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelNadi1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataNadi1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKesadaran1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataKesadaran1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelSuhu1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataSuhu1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelRespirasi1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataRespirasi1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelLain1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataLain1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelLabExecuteFlag1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataLabExecuteFlag1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelExpertiseLab1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataExpertiseLab1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelCatatanLab1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataCatatanLab1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelTerapi1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataTerapi1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelResep1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataResep1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelCatatanresep1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataCatatanresep1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelEksekusiResep1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataEksekusiResep1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelRepetisiresep1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataRepetisiresep1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelPrognosa1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataPrognosa1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD11, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICD11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD12, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICD12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD13, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICD13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD14, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICD14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD15, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICD15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD16, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICD16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD17, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICD17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD18, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICD18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD19, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICD19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICD20, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICD20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa11, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa12, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa13, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa14, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa15, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa16, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa17, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa18, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa19, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelICDDiagnosa20, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataICDDiagnosa20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelPoliTujuan1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataPoliTujuan1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelRujukan1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataRujukan1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelViewDinamisLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelIDPuskesmas1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE))
                    .addComponent(dataIDPuskesmas1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jScrollPane_ViewDinamis.setViewportView(panelViewDinamis);

        jLabel3.setText("No. Record Dinamis yang Ditampilkan (Stack) :");

        ComboBoxStackView.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", " " }));

        getAllDinamis_View.setBackground(new java.awt.Color(153, 153, 153));
        getAllDinamis_View.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        getAllDinamis_View.setForeground(java.awt.SystemColor.activeCaption);
        getAllDinamis_View.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/search.png"))); // NOI18N
        getAllDinamis_View.setText("Read Record");
        getAllDinamis_View.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.SystemColor.activeCaption, new java.awt.Color(255, 255, 255), java.awt.SystemColor.controlHighlight, java.awt.SystemColor.activeCaption));
        getAllDinamis_View.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getAllDinamis_ViewActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelMenuViewDinamisLayout = new javax.swing.GroupLayout(panelMenuViewDinamis);
        panelMenuViewDinamis.setLayout(panelMenuViewDinamisLayout);
        panelMenuViewDinamisLayout.setHorizontalGroup(
            panelMenuViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMenuViewDinamisLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ComboBoxStackView, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(getAllDinamis_View, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panelMenuViewDinamisLayout.setVerticalGroup(
            panelMenuViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMenuViewDinamisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                .addComponent(getAllDinamis_View)
                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
                .addComponent(ComboBoxStackView, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout RekamMedisDinamis1Layout = new javax.swing.GroupLayout(RekamMedisDinamis1);
        RekamMedisDinamis1.setLayout(RekamMedisDinamis1Layout);
        RekamMedisDinamis1Layout.setHorizontalGroup(
            RekamMedisDinamis1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RekamMedisDinamis1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(RekamMedisDinamis1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane_ViewDinamis, javax.swing.GroupLayout.DEFAULT_SIZE, 1066, Short.MAX_VALUE)
                    .addComponent(panelMenuViewDinamis, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        RekamMedisDinamis1Layout.setVerticalGroup(
            RekamMedisDinamis1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RekamMedisDinamis1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane_ViewDinamis, javax.swing.GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelMenuViewDinamis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedAll.addTab("Riwayat Rekam Medis Dinamis", new javax.swing.ImageIcon(getClass().getResource("/Icon/nama.png")), RekamMedisDinamis1); // NOI18N

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelReaderCard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedAll, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jTabbedAll, javax.swing.GroupLayout.PREFERRED_SIZE, 378, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PanelReaderCard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panelOperationTitle, javax.swing.GroupLayout.DEFAULT_SIZE, 1113, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelOperationTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(1113, 569));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
//--INISIASI DATA
    public void InisiasiData(){
   
    //--STATIS
        //Golongan Darah
        symbolGolongandarah[0] = "1. A+";
        symbolGolongandarah[1] = "2. A-";
        symbolGolongandarah[2] = "3. B+";
        symbolGolongandarah[3] = "4. B-";
        symbolGolongandarah[4] = "5. AB+";
        symbolGolongandarah[5] = "6. AB-";
        symbolGolongandarah[6] = "7. O+";
        symbolGolongandarah[7] = "8. O-";
    //--DINAMIS
    // Kesadaran
	symbolKesadaran[0] = "1. sama sekali tidak ada respons terhadap rangsang nyeri.";
	symbolKesadaran[1] = "2. seluruh tubuh pasien kaku, sehingga respons yang diberikan terhadap rangsang nyeri hampir tidak ada.";
	symbolKesadaran[2] = "3. tubuh pasien menekuk dengan kaku, sehingga hanya bergerak sedikit saat memperoleh rangsang nyeri.";
	symbolKesadaran[3] = "4. pasien bisa bergerak secara refleks menjauhi sumber rangsang nyeri.";
	symbolKesadaran[4] = "5. pasien bisa bergerak secara terkontrol apabila memperoleh rangsang nyeri.";
	symbolKesadaran[5] = "6. pasien dapat melakukan gerakan sesuai arahan.";
	
	// LabExecuteFlag
	symbolLabExecuteFlag[0] = "1. Dilayani penuh";
	symbolLabExecuteFlag[1] = "2. Tidak Dilayani sama sekali";
	symbolLabExecuteFlag[2] = "3. Dilayani sebagian";
	// EksekusiResep
	symbolEksekusiResep[0] = "1. Dilayani penuh";
	symbolEksekusiResep[1] = "2. Tidak Dilayani sama sekali";
	symbolEksekusiResep[2] = "3. Dilayani sebagian";
	symbolEksekusiResep[3] = "4. Dilayani, ada penggantian";
	symbolEksekusiResep[4] = "5. Dilayani sebagian dan ada penggantian";
	// Repetisiresep
	symbolRepetisiresep[0] = "1. Repetisiresep1";
	symbolRepetisiresep[1] = "2. Repetisiresep2";
	symbolRepetisiresep[2] = "3. Repetisiresep3";
	symbolRepetisiresep[3] = "4. Repetisiresep4";
	symbolRepetisiresep[4] = "5. Repetisiresep5";
	// Prognosa
	symbolPrognosa[0] = "1. Ad functionam :ad bonam";
	symbolPrognosa[1] = "2. Ad functionam :dubia ad bonam";
	symbolPrognosa[2] = "3. Ad functionam :dubia ad malam";
	symbolPrognosa[3] = "4. Ad functionam :ad malam";
	symbolPrognosa[4] = "5. Ad vitam :ad bonam";
	symbolPrognosa[5] = "6. Ad vitam :dubia ad bonam";
	symbolPrognosa[6] = "7. Ad vitam :dubia ad malam";
	symbolPrognosa[7] = "8. Ad vitam :ad malam";
    }
   
    private void btnLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogOutActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_btnLogOutActionPerformed


    private void updateAllDINAMISgetAllSTATIS1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateAllDINAMISgetAllSTATIS1ActionPerformed
        inputAllDinamis();// TODO add your handling code here:
    }//GEN-LAST:event_updateAllDINAMISgetAllSTATIS1ActionPerformed

    private void deleteAllDINAMISdeleteAllSTATIS1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteAllDINAMISdeleteAllSTATIS1ActionPerformed
        deleteAllDinamis();     // TODO add your handling code here:
    }//GEN-LAST:event_deleteAllDINAMISdeleteAllSTATIS1ActionPerformed

    private void registerlDINAMISinputAllSTATIS1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerlDINAMISinputAllSTATIS1ActionPerformed
        registerRecordDinamis();       // TODO add your handling code here:
    }//GEN-LAST:event_registerlDINAMISinputAllSTATIS1ActionPerformed

    private void GetStackDinamisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GetStackDinamisActionPerformed
        getCurrentStack();
    }//GEN-LAST:event_GetStackDinamisActionPerformed

    private void deleteIDPuskesmasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteIDPuskesmasActionPerformed

	deleteText( indeksIDPuskesmas, dataIDPuskesmas, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteIDPuskesmasActionPerformed

    private void inputIDPuskesmasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputIDPuskesmasActionPerformed
	data_StringIDPuskesmas = this.fieldIDPuskesmas.getText();
	inputDATA( data_StringIDPuskesmas, TEXT, indeksIDPuskesmas, CLAText);
	getDataDinamis( indeksIDPuskesmas, false, null, dataIDPuskesmas, CLAText, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputIDPuskesmasActionPerformed

    private void deleteRujukanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteRujukanActionPerformed
	deleteText( indeksRujukan, dataRujukan, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteRujukanActionPerformed

    private void inputRujukanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputRujukanActionPerformed
	data_StringRujukan = this.fieldRujukan.getText();
	inputDATA( data_StringRujukan, TEXT, indeksRujukan, CLAText);
	getDataDinamis( indeksRujukan, false, null, dataRujukan, CLAText, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputRujukanActionPerformed

    private void deletePoliTujuanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePoliTujuanActionPerformed

	deleteText( indeksPoliTujuan, dataPoliTujuan, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deletePoliTujuanActionPerformed

    private void inputPoliTujuanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputPoliTujuanActionPerformed
	data_StringPoliTujuan = this.fieldPoliTujuan.getText();
	inputDATA( data_StringPoliTujuan, TEXT, indeksPoliTujuan, CLAText);
	getDataDinamis( indeksPoliTujuan, false, null, dataPoliTujuan, CLAText, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputPoliTujuanActionPerformed

    private void deleteICDDiagnosa10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICDDiagnosa10ActionPerformed

	deleteText( indeksICDDiagnosa10, dataICDDiagnosa10, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICDDiagnosa10ActionPerformed

    private void inputICDDiagnosa10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICDDiagnosa10ActionPerformed
	String dataNUM_StringICDDiagnosa10 = this.fieldICDDiagnosa10.getText();
	inputDATA( dataNUM_StringICDDiagnosa10, NUM, indeksICDDiagnosa10, CLANum);
	getDataDinamis( indeksICDDiagnosa10, false, null, dataICDDiagnosa10, CLANum, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICDDiagnosa10ActionPerformed

    private void deleteICDDiagnosa9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICDDiagnosa9ActionPerformed
	deleteText( indeksICDDiagnosa9, dataICDDiagnosa9, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICDDiagnosa9ActionPerformed

    private void inputICDDiagnosa9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICDDiagnosa9ActionPerformed
	String dataNUM_StringICDDiagnosa9 = this.fieldICDDiagnosa9.getText();
	inputDATA( dataNUM_StringICDDiagnosa9, NUM, indeksICDDiagnosa9, CLANum);
	getDataDinamis( indeksICDDiagnosa9, false, null, dataICDDiagnosa9, CLANum, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICDDiagnosa9ActionPerformed

    private void deleteICDDiagnosa8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICDDiagnosa8ActionPerformed

	deleteText( indeksICDDiagnosa8, dataICDDiagnosa8, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICDDiagnosa8ActionPerformed

    private void inputICDDiagnosa8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICDDiagnosa8ActionPerformed
	String dataNUM_StringICDDiagnosa8 = this.fieldICDDiagnosa8.getText();
	inputDATA( dataNUM_StringICDDiagnosa8, NUM, indeksICDDiagnosa8, CLANum);
	getDataDinamis( indeksICDDiagnosa8, false, null, dataICDDiagnosa8, CLANum, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICDDiagnosa8ActionPerformed

    private void deleteICDDiagnosa7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICDDiagnosa7ActionPerformed
	deleteText( indeksICDDiagnosa7, dataICDDiagnosa7, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICDDiagnosa7ActionPerformed

    private void inputICDDiagnosa7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICDDiagnosa7ActionPerformed
	String dataNUM_StringICDDiagnosa7 = this.fieldICDDiagnosa7.getText();
	inputDATA( dataNUM_StringICDDiagnosa7, NUM, indeksICDDiagnosa7, CLANum);
	getDataDinamis( indeksICDDiagnosa7, false, null, dataICDDiagnosa7, CLANum, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICDDiagnosa7ActionPerformed

    private void deleteICDDiagnosa6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICDDiagnosa6ActionPerformed

	deleteText( indeksICDDiagnosa6, dataICDDiagnosa6, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICDDiagnosa6ActionPerformed

    private void inputICDDiagnosa6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICDDiagnosa6ActionPerformed
	String dataNUM_StringICDDiagnosa6 = this.fieldICDDiagnosa6.getText();
	inputDATA( dataNUM_StringICDDiagnosa6, NUM, indeksICDDiagnosa6, CLANum);
	getDataDinamis( indeksICDDiagnosa6, false, null, dataICDDiagnosa6, CLANum, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICDDiagnosa6ActionPerformed

    private void deleteICDDiagnosa5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICDDiagnosa5ActionPerformed
	deleteText( indeksICDDiagnosa5, dataICDDiagnosa5, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICDDiagnosa5ActionPerformed

    private void inputICDDiagnosa5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICDDiagnosa5ActionPerformed
	String dataNUM_StringICDDiagnosa5 = this.fieldICDDiagnosa5.getText();
	inputDATA( dataNUM_StringICDDiagnosa5, NUM, indeksICDDiagnosa5, CLANum);
	getDataDinamis( indeksICDDiagnosa5, false, null, dataICDDiagnosa5, CLANum, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICDDiagnosa5ActionPerformed

    private void deleteICDDiagnosa4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICDDiagnosa4ActionPerformed
	deleteText( indeksICDDiagnosa4, dataICDDiagnosa4, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICDDiagnosa4ActionPerformed

    private void inputICDDiagnosa4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICDDiagnosa4ActionPerformed
	String dataNUM_StringICDDiagnosa4 = this.fieldICDDiagnosa4.getText();
	inputDATA( dataNUM_StringICDDiagnosa4, NUM, indeksICDDiagnosa4, CLANum);
	getDataDinamis( indeksICDDiagnosa4, false, null, dataICDDiagnosa4, CLANum, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICDDiagnosa4ActionPerformed

    private void deleteICDDiagnosa3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICDDiagnosa3ActionPerformed
	deleteText( indeksICDDiagnosa3, dataICDDiagnosa3, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICDDiagnosa3ActionPerformed

    private void inputICDDiagnosa3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICDDiagnosa3ActionPerformed
	String dataNUM_StringICDDiagnosa3 = this.fieldICDDiagnosa3.getText();
	inputDATA( dataNUM_StringICDDiagnosa3, NUM, indeksICDDiagnosa3, CLANum);
	getDataDinamis( indeksICDDiagnosa3, false, null, dataICDDiagnosa3, CLANum, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICDDiagnosa3ActionPerformed

    private void deleteICDDiagnosa2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICDDiagnosa2ActionPerformed


	deleteText( indeksICDDiagnosa2, dataICDDiagnosa2, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICDDiagnosa2ActionPerformed

    private void inputICDDiagnosa2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICDDiagnosa2ActionPerformed
	String dataNUM_StringICDDiagnosa2 = this.fieldICDDiagnosa2.getText();
	inputDATA( dataNUM_StringICDDiagnosa2, NUM, indeksICDDiagnosa2, CLANum);
	getDataDinamis( indeksICDDiagnosa2, false, null, dataICDDiagnosa2, CLANum, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICDDiagnosa2ActionPerformed

    private void deleteICDDiagnosa1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICDDiagnosa1ActionPerformed
	deleteText( indeksICDDiagnosa1, dataICDDiagnosa1, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICDDiagnosa1ActionPerformed

    private void inputICDDiagnosa1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICDDiagnosa1ActionPerformed
	String dataNUM_StringICDDiagnosa1 = this.fieldICDDiagnosa1.getText();
	inputDATA( dataNUM_StringICDDiagnosa1, NUM, indeksICDDiagnosa1, CLANum);
	getDataDinamis( indeksICDDiagnosa1, false, null, dataICDDiagnosa1, CLANum, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICDDiagnosa1ActionPerformed

    private void deleteICD10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICD10ActionPerformed


	deleteText( indeksICD10, dataICD10, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICD10ActionPerformed

    private void inputICD10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICD10ActionPerformed
	data_StringICD10 = this.fieldICD10.getText();
	inputDATA( data_StringICD10, TEXT, indeksICD10, CLAText);
	getDataDinamis( indeksICD10, false, null, dataICD10, CLAText, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICD10ActionPerformed

    private void deleteICD9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICD9ActionPerformed

	deleteText( indeksICD9, dataICD9, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICD9ActionPerformed

    private void inputICD9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICD9ActionPerformed
	data_StringICD9 = this.fieldICD9.getText();
	inputDATA( data_StringICD9, TEXT, indeksICD9, CLAText);
	getDataDinamis( indeksICD9, false, null, dataICD9, CLAText, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICD9ActionPerformed

    private void deleteICD8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICD8ActionPerformed

	deleteText( indeksICD8, dataICD8, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICD8ActionPerformed

    private void inputICD8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICD8ActionPerformed
	data_StringICD8 = this.fieldICD8.getText();
	inputDATA( data_StringICD8, TEXT, indeksICD8, CLAText);
	getDataDinamis( indeksICD8, false, null, dataICD8, CLAText, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICD8ActionPerformed

    private void deleteICD7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICD7ActionPerformed

	deleteText( indeksICD7, dataICD7, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICD7ActionPerformed

    private void inputICD7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICD7ActionPerformed
	data_StringICD7 = this.fieldICD7.getText();
	inputDATA( data_StringICD7, TEXT, indeksICD7, CLAText);
	getDataDinamis( indeksICD7, false, null, dataICD7, CLAText, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICD7ActionPerformed

    private void deleteICD6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICD6ActionPerformed

	deleteText( indeksICD6, dataICD6, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICD6ActionPerformed

    private void inputICD6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICD6ActionPerformed
	data_StringICD6 = this.fieldICD6.getText();
	inputDATA( data_StringICD6, TEXT, indeksICD6, CLAText);
	getDataDinamis( indeksICD6, false, null, dataICD6, CLAText, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICD6ActionPerformed

    private void deleteICD5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICD5ActionPerformed
	deleteText( indeksICD5, dataICD5, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICD5ActionPerformed

    private void inputICD5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICD5ActionPerformed
	data_StringICD5 = this.fieldICD5.getText();
	inputDATA( data_StringICD5, TEXT, indeksICD5, CLAText);
	getDataDinamis( indeksICD5, false, null, dataICD5, CLAText, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICD5ActionPerformed

    private void deleteICD4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICD4ActionPerformed

	deleteText( indeksICD4, dataICD4, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICD4ActionPerformed

    private void inputICD4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICD4ActionPerformed
	data_StringICD4 = this.fieldICD4.getText();
	inputDATA( data_StringICD4, TEXT, indeksICD4, CLAText);
	getDataDinamis( indeksICD4, false, null, dataICD4, CLAText, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICD4ActionPerformed

    private void deleteICD3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICD3ActionPerformed
	deleteText( indeksICD3, dataICD3, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICD3ActionPerformed

    private void inputICD3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICD3ActionPerformed
	data_StringICD3 = this.fieldICD3.getText();
	inputDATA( data_StringICD3, TEXT, indeksICD3, CLAText);
	getDataDinamis( indeksICD3, false, null, dataICD3, CLAText, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICD3ActionPerformed

    private void deleteICD2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICD2ActionPerformed
	deleteText( indeksICD2, dataICD2, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICD2ActionPerformed

    private void inputICD2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICD2ActionPerformed
	data_StringICD2 = this.fieldICD2.getText();
	inputDATA( data_StringICD2, TEXT, indeksICD2, CLAText);
	getDataDinamis( indeksICD2, false, null, dataICD2, CLAText, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICD2ActionPerformed

    private void deleteICD1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteICD1ActionPerformed
	deleteText( indeksICD1, dataICD1, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteICD1ActionPerformed

    private void inputICD1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputICD1ActionPerformed
	data_StringICD1 = this.fieldICD1.getText();
	inputDATA( data_StringICD1, TEXT, indeksICD1, CLAText);
	getDataDinamis( indeksICD1, false, null, dataICD1, CLAText, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputICD1ActionPerformed

    private void deletePrognosaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePrognosaActionPerformed
	deleteText( indeksPrognosa, dataPrognosa, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deletePrognosaActionPerformed

    private void inputPrognosaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputPrognosaActionPerformed
	String dataNUM_StringPrognosa = Integer.toString(ComboBox_Prognosa.getSelectedIndex()+1);
	inputDATA( dataNUM_StringPrognosa, NUM, indeksPrognosa, CLANum);
	getDataDinamis( indeksPrognosa, true, symbolPrognosa, dataPrognosa, CLANum, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputPrognosaActionPerformed

    private void deleteRepetisiresepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteRepetisiresepActionPerformed
	deleteText( indeksRepetisiresep, dataRepetisiresep, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteRepetisiresepActionPerformed

    private void inputRepetisiresepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputRepetisiresepActionPerformed
	String dataNUM_StringRepetisiresep = Integer.toString(ComboBox_Repetisiresep.getSelectedIndex()+1);
	inputDATA( dataNUM_StringRepetisiresep, NUM, indeksRepetisiresep, CLANum);
	getDataDinamis( indeksRepetisiresep, true, symbolRepetisiresep, dataRepetisiresep, CLANum, false, fieldCurrentStack.getText());
    }//GEN-LAST:event_inputRepetisiresepActionPerformed

    private void deleteEksekusiResepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteEksekusiResepActionPerformed
	deleteText( indeksEksekusiResep, dataEksekusiResep, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteEksekusiResepActionPerformed

    private void inputEksekusiResepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputEksekusiResepActionPerformed
	String dataNUM_StringEksekusiResep = Integer.toString(ComboBox_EksekusiResep.getSelectedIndex()+1);
	inputDATA( dataNUM_StringEksekusiResep, NUM, indeksEksekusiResep, CLANum);
	getDataDinamis( indeksEksekusiResep, true, symbolEksekusiResep, dataEksekusiResep, CLANum, false, fieldCurrentStack.getText());
    }//GEN-LAST:event_inputEksekusiResepActionPerformed

    private void deleteCatatanresepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteCatatanresepActionPerformed
	deleteText( indeksCatatanresep, dataCatatanresep, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteCatatanresepActionPerformed

    private void inputCatatanresepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputCatatanresepActionPerformed
	data_StringCatatanresep = this.fieldCatatanresep.getText();
	inputDATA( data_StringCatatanresep, TEXT, indeksCatatanresep, CLAText);
	getDataDinamis( indeksCatatanresep, false, null, dataCatatanresep, CLAText, false, fieldCurrentStack.getText());
    }//GEN-LAST:event_inputCatatanresepActionPerformed

    private void fieldCatatanresepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldCatatanresepActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldCatatanresepActionPerformed

    private void deleteResepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteResepActionPerformed

	deleteText( indeksResep, dataResep, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteResepActionPerformed

    private void inputResepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputResepActionPerformed
	data_StringResep = this.fieldResep.getText();
	inputDATA( data_StringResep, TEXT, indeksResep, CLAText);
	getDataDinamis( indeksResep, false, null, dataResep, CLAText, false, fieldCurrentStack.getText());
    }//GEN-LAST:event_inputResepActionPerformed

    private void fieldResepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldResepActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldResepActionPerformed

    private void deleteTerapiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteTerapiActionPerformed
	deleteText( indeksTerapi, dataTerapi, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteTerapiActionPerformed

    private void inputTerapiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputTerapiActionPerformed
	data_StringTerapi = this.fieldTerapi.getText();
	inputDATA( data_StringTerapi, TEXT, indeksTerapi, CLAText);
	getDataDinamis( indeksTerapi, false, null, dataTerapi, CLAText, false, fieldCurrentStack.getText());
    }//GEN-LAST:event_inputTerapiActionPerformed

    private void fieldTerapiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldTerapiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldTerapiActionPerformed

    private void deleteCatatanLabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteCatatanLabActionPerformed
        deleteText( indeksCatatanLab, dataCatatanLab, CLAText);         // TODO add your handling code here:
    }//GEN-LAST:event_deleteCatatanLabActionPerformed

    private void inputCatatanLabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputCatatanLabActionPerformed
	data_StringCatatanLab = this.fieldCatatanLab.getText();
	inputDATA( data_StringCatatanLab, TEXT, indeksCatatanLab, CLAText);
	getDataDinamis( indeksCatatanLab, false, null, dataCatatanLab, CLAText, false, fieldCurrentStack.getText());
    }//GEN-LAST:event_inputCatatanLabActionPerformed

    private void fieldCatatanLabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldCatatanLabActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldCatatanLabActionPerformed

    private void deleteExpertiseLabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteExpertiseLabActionPerformed
	deleteText( indeksExpertiseLab, dataExpertiseLab, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteExpertiseLabActionPerformed

    private void inputExpertiseLabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputExpertiseLabActionPerformed
	data_StringExpertiseLab = this.fieldExpertiseLab.getText();
	inputDATA( data_StringExpertiseLab, TEXT, indeksExpertiseLab, CLAText);
	getDataDinamis( indeksExpertiseLab, false, null, dataExpertiseLab, CLAText, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputExpertiseLabActionPerformed

    private void fieldExpertiseLabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldExpertiseLabActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldExpertiseLabActionPerformed

    private void deleteLabExecuteFlagActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteLabExecuteFlagActionPerformed

	deleteText( indeksLabExecuteFlag, dataLabExecuteFlag, CLANum);	       // TODO add your handling code here:
    }//GEN-LAST:event_deleteLabExecuteFlagActionPerformed

    private void inputLabExecuteFlagActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputLabExecuteFlagActionPerformed
	String dataNUM_StringLabExecuteFlag = Integer.toString(ComboBox_LabExecuteFlag.getSelectedIndex()+1);
	inputDATA( dataNUM_StringLabExecuteFlag, NUM, indeksLabExecuteFlag, CLANum);
	getDataDinamis( indeksLabExecuteFlag, true, symbolLabExecuteFlag, dataLabExecuteFlag, CLANum, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputLabExecuteFlagActionPerformed

    private void deleteLainActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteLainActionPerformed
	deleteText( indeksLain, dataLain, CLAText);
	        // TODO add your handling code here:
    }//GEN-LAST:event_deleteLainActionPerformed

    private void inputLainActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputLainActionPerformed
	data_StringLain = this.fieldLain.getText();
	inputDATA( data_StringLain, TEXT, indeksLain, CLAText);
	getDataDinamis( indeksLain, false, null, dataLain, CLAText, false, fieldCurrentStack.getText());
	        // TODO add your handling code here:
    }//GEN-LAST:event_inputLainActionPerformed

    private void fieldLainActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldLainActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldLainActionPerformed

    private void deleteRespirasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteRespirasiActionPerformed
        deleteText( indeksRespirasi, dataRespirasi, CLANum);        // TODO add your handling code here:        // TODO add your handling code here:
    }//GEN-LAST:event_deleteRespirasiActionPerformed

    private void inputRespirasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputRespirasiActionPerformed
	String dataNUM_StringRespirasi = this.fieldRespirasi.getText();
	inputDATA( dataNUM_StringRespirasi, NUM, indeksRespirasi, CLANum);
	getDataDinamis( indeksRespirasi, true, null, dataRespirasi, CLANum, false, fieldCurrentStack.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_inputRespirasiActionPerformed

    private void fieldRespirasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldRespirasiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldRespirasiActionPerformed

    private void deleteSuhuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteSuhuActionPerformed
        deleteText( indeksSuhu, dataSuhu, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteSuhuActionPerformed

    private void inputSuhuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputSuhuActionPerformed
        String data_String;
        data_StringSuhu = (String) this.fieldSuhu.getText();
        float dataTEXT_Float = Float.parseFloat(data_StringSuhu);
        dataTEXT_Float = dataTEXT_Float*100;
        String dataNUM_StringSuhu = String.valueOf((int) dataTEXT_Float);
        
	inputDATA( dataNUM_StringSuhu, NUM, indeksSuhu, CLANum);
	getDataDinamis( indeksSuhu, true, null, dataSuhu, CLANum, true, fieldCurrentStack.getText());// TODO add your handling code here:
    }//GEN-LAST:event_inputSuhuActionPerformed

    private void fieldSuhuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldSuhuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldSuhuActionPerformed

    private void deleteKesadaranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKesadaranActionPerformed
	deleteText( indeksKesadaran, dataKesadaran, CLANum);
    }//GEN-LAST:event_deleteKesadaranActionPerformed

    private void inputKesadaranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKesadaranActionPerformed
	String dataNUM_StringKesadaran = Integer.toString(ComboBox_Kesadaran.getSelectedIndex()+1);
	inputDATA( dataNUM_StringKesadaran, NUM, indeksKesadaran, CLANum);
	getDataDinamis( indeksKesadaran, true, symbolKesadaran, dataKesadaran, CLANum, false, fieldCurrentStack.getText());
	        // TODO add your handling code here:
    }//GEN-LAST:event_inputKesadaranActionPerformed

    private void deleteNadiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteNadiActionPerformed
	deleteText( indeksNadi, dataNadi, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteNadiActionPerformed

    private void inputNadiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputNadiActionPerformed
	String dataNUM_StringNadi = this.fieldNadi.getText();
	inputDATA( dataNUM_StringNadi, NUM, indeksNadi, CLANum);
	getDataDinamis( indeksNadi, true, null, dataNadi, CLANum, false, fieldCurrentStack.getText());
	        // TODO add your handling code here:
    }//GEN-LAST:event_inputNadiActionPerformed

    private void fieldNadiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldNadiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldNadiActionPerformed

    private void deleteDiastoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteDiastoleActionPerformed
	deleteText( indeksDiastole, dataDiastole, CLANum);         // TODO add your handling code here:
    }//GEN-LAST:event_deleteDiastoleActionPerformed

    private void inputDiastoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputDiastoleActionPerformed
	String dataNUM_StringDiastole = this.fieldDiastole.getText();
	inputDATA( dataNUM_StringDiastole, NUM, indeksDiastole, CLANum);
	getDataDinamis( indeksDiastole, true, null, dataDiastole, CLANum, false, fieldCurrentStack.getText());
	        // TODO add your handling code here:
    }//GEN-LAST:event_inputDiastoleActionPerformed

    private void fieldDiastoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldDiastoleActionPerformed
	       // TODO add your handling code here:
    }//GEN-LAST:event_fieldDiastoleActionPerformed

    private void deleteSystoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteSystoleActionPerformed
	deleteText( indeksSystole, dataSystole, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteSystoleActionPerformed

    private void inputSystoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputSystoleActionPerformed
	String dataNUM_StringSystole = this.fieldSystole.getText();
	inputDATA( dataNUM_StringSystole, NUM, indeksSystole, CLANum);
	getDataDinamis( indeksSystole, true, null, dataSystole, CLANum, false, fieldCurrentStack.getText());
	        // TODO add your handling code here:
    }//GEN-LAST:event_inputSystoleActionPerformed

    private void fieldSystoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldSystoleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldSystoleActionPerformed

    private void deleteBeratbadanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBeratbadanActionPerformed
	deleteText( indeksBeratbadan, dataBeratbadan, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteBeratbadanActionPerformed

    private void inputBeratbadanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputBeratbadanActionPerformed
	String dataNUM_StringBeratbadan = this.fieldBeratbadan.getText();
	inputDATA( dataNUM_StringBeratbadan, NUM, indeksBeratbadan, CLANum);
	getDataDinamis( indeksBeratbadan, true, null, dataBeratbadan, CLANum, false, fieldCurrentStack.getText());
	        // TODO add your handling code here:
    }//GEN-LAST:event_inputBeratbadanActionPerformed

    private void fieldBeratbadanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldBeratbadanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldBeratbadanActionPerformed

    private void deleteTinggiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteTinggiActionPerformed
	deleteText( indeksTinggi, dataTinggi, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteTinggiActionPerformed

    private void inputTinggiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputTinggiActionPerformed
	data_StringTinggi = this.fieldTinggi.getText();
	inputDATA( data_StringTinggi, NUM, indeksTinggi, CLANum);
	getDataDinamis( indeksTinggi, true, null, dataTinggi, CLANum, false, fieldCurrentStack.getText());
	        // TODO add your handling code here:
    }//GEN-LAST:event_inputTinggiActionPerformed

    private void fieldTinggiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldTinggiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldTinggiActionPerformed

    private void deletePemeriksaanFisikActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePemeriksaanFisikActionPerformed
	deleteText( indeksPemeriksaanFisik, dataPemeriksaanFisik, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deletePemeriksaanFisikActionPerformed

    private void inputPemeriksaanFisikActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputPemeriksaanFisikActionPerformed
	data_StringPemeriksaanFisik = this.fieldPemeriksaanFisik.getText();
	inputDATA( data_StringPemeriksaanFisik, TEXT, indeksPemeriksaanFisik, CLAText);
	getDataDinamis( indeksPemeriksaanFisik, false, null, dataPemeriksaanFisik, CLAText, false, fieldCurrentStack.getText());
	        // TODO add your handling code here:
    }//GEN-LAST:event_inputPemeriksaanFisikActionPerformed

    private void fieldPemeriksaanFisikActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldPemeriksaanFisikActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldPemeriksaanFisikActionPerformed

    private void deletePenyakitKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePenyakitKeluargaActionPerformed
	deleteText( indeksPenyakitKeluarga, dataPenyakitKeluarga, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deletePenyakitKeluargaActionPerformed

    private void inputPenyakitKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputPenyakitKeluargaActionPerformed
	data_StringPenyakitKeluarga = this.fieldPenyakitKeluarga.getText();
	inputDATA( data_StringPenyakitKeluarga, TEXT, indeksPenyakitKeluarga, CLAText);
	getDataDinamis( indeksPenyakitKeluarga, false, null, dataPenyakitKeluarga, CLAText, false, fieldCurrentStack.getText());
	        // TODO add your handling code here:
    }//GEN-LAST:event_inputPenyakitKeluargaActionPerformed

    private void fieldPenyakitKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldPenyakitKeluargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldPenyakitKeluargaActionPerformed

    private void deletePenyakitDahuluActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePenyakitDahuluActionPerformed
	deleteText( indeksPenyakitDahulu, dataPenyakitDahulu, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deletePenyakitDahuluActionPerformed

    private void inputPenyakitDahuluActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputPenyakitDahuluActionPerformed
	data_StringPenyakitDahulu = this.fieldPenyakitDahulu.getText();
	inputDATA( data_StringPenyakitDahulu, TEXT, indeksPenyakitDahulu, CLAText);
	getDataDinamis( indeksPenyakitDahulu, false, null, dataPenyakitDahulu, CLAText, false, fieldCurrentStack.getText());
	        // TODO add your handling code here:
    }//GEN-LAST:event_inputPenyakitDahuluActionPerformed

    private void fieldPenyakitDahuluActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldPenyakitDahuluActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldPenyakitDahuluActionPerformed

    private void deleteAnamnesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteAnamnesaActionPerformed

	deleteText( indeksAnamnesa, dataAnamnesa, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteAnamnesaActionPerformed

    private void inputAnamnesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputAnamnesaActionPerformed
	data_StringAnamnesa = this.fieldAnamnesa.getText();
	inputDATA( data_StringAnamnesa, TEXT, indeksAnamnesa, CLAText);
	getDataDinamis( indeksAnamnesa, false, null, dataAnamnesa, CLAText, false, fieldCurrentStack.getText());
	        // TODO add your handling code here:
    }//GEN-LAST:event_inputAnamnesaActionPerformed

    private void fieldAnamnesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldAnamnesaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldAnamnesaActionPerformed

    private void deleteKeluhanutamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKeluhanutamaActionPerformed
	deleteText( indeksKeluhanutama, dataKeluhanutama, CLAText);
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteKeluhanutamaActionPerformed

    private void inputKeluhanutamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKeluhanutamaActionPerformed
	data_StringKeluhanutama = this.fieldKeluhanutama.getText();
	inputDATA( data_StringKeluhanutama, TEXT, indeksKeluhanutama, CLAText);
	getDataDinamis( indeksKeluhanutama, false, null, dataKeluhanutama, CLAText, false, fieldCurrentStack.getText());        // TODO add your handling code here:
    }//GEN-LAST:event_inputKeluhanutamaActionPerformed

    private void fieldKeluhanutamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldKeluhanutamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldKeluhanutamaActionPerformed

    private void fieldTanggalPeriksaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldTanggalPeriksaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldTanggalPeriksaActionPerformed

    private void inputTanggalPeriksaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputTanggalPeriksaActionPerformed
	data_StringTanggalPeriksa = this.fieldTanggalPeriksa.getText();
	inputDATA( data_StringTanggalPeriksa, TEXT, indeksTanggalPeriksa, CLAText);
	getDataDinamis( indeksTanggalPeriksa, false, null, dataTanggalPeriksa, CLAText, false, fieldCurrentStack.getText());
	        // TODO add your handling code here:
    }//GEN-LAST:event_inputTanggalPeriksaActionPerformed

    private void deleteTanggalPeriksaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteTanggalPeriksaActionPerformed
        deleteText( indeksTanggalPeriksa, dataTanggalPeriksa, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteTanggalPeriksaActionPerformed

    private void getAllDinamis_currentinputAllSTATIS1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getAllDinamis_currentinputAllSTATIS1ActionPerformed
        getAllDINAMIS();        // TODO add your handling code here:
    }//GEN-LAST:event_getAllDinamis_currentinputAllSTATIS1ActionPerformed

    private void getAllDinamis_ViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getAllDinamis_ViewActionPerformed
// TanggalPeriksa
	getDataDinamis( indeksTanggalPeriksa, false, null, dataTanggalPeriksa1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Keluhanutama
	getDataDinamis( indeksKeluhanutama, false, null, dataKeluhanutama1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Anamnesa
	getDataDinamis( indeksAnamnesa, false, null, dataAnamnesa1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// PenyakitDahulu
	getDataDinamis( indeksPenyakitDahulu, false, null, dataPenyakitDahulu1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// PenyakitKeluarga
	getDataDinamis( indeksPenyakitKeluarga, false, null, dataPenyakitKeluarga1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// PemeriksaanFisik
	getDataDinamis( indeksPemeriksaanFisik, false, null, dataPemeriksaanFisik1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Tinggi
	getDataDinamis( indeksTinggi, true, null, dataTinggi1, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Beratbadan
	getDataDinamis( indeksBeratbadan, true, null, dataBeratbadan1, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Systole
	getDataDinamis( indeksSystole, true, null, dataSystole1, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Diastole
	getDataDinamis( indeksDiastole, true, null, dataDiastole1, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Nadi
	getDataDinamis( indeksNadi, true, null, dataNadi1, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Kesadaran
	getDataDinamis( indeksKesadaran, true, symbolKesadaran, dataKesadaran1, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Suhu
	getDataDinamis( indeksSuhu, true, null, dataSuhu1, CLANum, true, (String) this.ComboBoxStackView.getSelectedItem());
	// Respirasi
	getDataDinamis( indeksRespirasi, true, null, dataRespirasi1, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Lain-lain
	getDataDinamis( indeksLain, false, null, dataLain1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// LabExecuteFlag
	getDataDinamis( indeksLabExecuteFlag, true, symbolLabExecuteFlag, dataLabExecuteFlag1, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ExpertiseLab
	getDataDinamis( indeksExpertiseLab, false, null, dataExpertiseLab1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// CatatanLab
	getDataDinamis( indeksCatatanLab, false, null, dataCatatanLab1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Terapi
	getDataDinamis( indeksTerapi, false, null, dataTerapi1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Resep
	getDataDinamis( indeksResep, false, null, dataResep1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Catatanresep
	getDataDinamis( indeksCatatanresep, false, null, dataCatatanresep1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// EksekusiResep
	getDataDinamis( indeksEksekusiResep, true, symbolEksekusiResep, dataEksekusiResep1, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Repetisiresep
	getDataDinamis( indeksRepetisiresep, true, symbolRepetisiresep, dataRepetisiresep1, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Prognosa
	getDataDinamis( indeksPrognosa, true, symbolPrognosa, dataPrognosa1, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICD1
	getDataDinamis( indeksICD1, false, null, dataICD11, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICD2
	getDataDinamis( indeksICD2, false, null, dataICD12, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICD3
	getDataDinamis( indeksICD3, false, null, dataICD13, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICD4
	getDataDinamis( indeksICD4, false, null, dataICD14, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICD5
	getDataDinamis( indeksICD5, false, null, dataICD15, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICD6
	getDataDinamis( indeksICD6, false, null, dataICD16, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICD7
	getDataDinamis( indeksICD7, false, null, dataICD17, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICD8
	getDataDinamis( indeksICD8, false, null, dataICD18, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICD9
	getDataDinamis( indeksICD9, false, null, dataICD19, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICD10
	getDataDinamis( indeksICD10, false, null, dataICD20, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICDDiagnosa1
	getDataDinamis( indeksICDDiagnosa1, false, null, dataICDDiagnosa11, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICDDiagnosa2
	getDataDinamis( indeksICDDiagnosa2, false, null, dataICDDiagnosa12, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICDDiagnosa3
	getDataDinamis( indeksICDDiagnosa3, false, null, dataICDDiagnosa13, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICDDiagnosa4
	getDataDinamis( indeksICDDiagnosa4, false, null, dataICDDiagnosa14, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICDDiagnosa5
	getDataDinamis( indeksICDDiagnosa5, false, null, dataICDDiagnosa15, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICDDiagnosa6
	getDataDinamis( indeksICDDiagnosa6, false, null, dataICDDiagnosa16, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICDDiagnosa7
	getDataDinamis( indeksICDDiagnosa7, false, null, dataICDDiagnosa17, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICDDiagnosa8
	getDataDinamis( indeksICDDiagnosa8, false, null, dataICDDiagnosa18, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICDDiagnosa9
	getDataDinamis( indeksICDDiagnosa9, false, null, dataICDDiagnosa19, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// ICDDiagnosa10
	getDataDinamis( indeksICDDiagnosa10, false, null, dataICDDiagnosa20, CLANum, false, (String) this.ComboBoxStackView.getSelectedItem());
	// PoliTujuan
	getDataDinamis( indeksPoliTujuan, false, null, dataPoliTujuan1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// Rujukan
	getDataDinamis( indeksRujukan, false, null, dataRujukan1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());
	// IDPuskesmas
	getDataDinamis( indeksIDPuskesmas, false, null, dataIDPuskesmas1, CLAText, false, (String) this.ComboBoxStackView.getSelectedItem());    // TODO add your handling code here:
    }//GEN-LAST:event_getAllDinamis_ViewActionPerformed

    private void getAllSTATISActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getAllSTATISActionPerformed
        //STATIS
        getDATA( indeksAlergi, false, null, dataAlergi, CLAText);
        getDATA( indeksGolongandarah, true, symbolGolongandarah, dataGolongandarah, CLANum);
        getDATA( indeksRiwayatOperasi, false, null, dataRiwayatOperasi, CLAText);
        getDATA( indeksRawatRS, false, null, dataRawatRS, CLAText);
        getDATA( indeksPenyakitKronis, false, null, dataPenyakitKronis, CLAText);
        getDATA( indeksPenyakitBawaan, false, null, dataPenyakitBawaan, CLAText);
        getDATA( indeksFaktorResiko, false, null, dataFaktorResiko, CLAText);
        // TODO add your handling code here:
    }//GEN-LAST:event_getAllSTATISActionPerformed

    private void deleteAllSTATISActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteAllSTATISActionPerformed
        deleteAllStatis();
    }//GEN-LAST:event_deleteAllSTATISActionPerformed

    private void inputAllSTATISActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputAllSTATISActionPerformed
        inputAllSTATIS();  // TODO add your handling code here:
    }//GEN-LAST:event_inputAllSTATISActionPerformed

    private void fieldFaktorResikoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldFaktorResikoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldFaktorResikoActionPerformed

    private void fieldPenyakitBawaanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldPenyakitBawaanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldPenyakitBawaanActionPerformed

    private void fieldPenyakitKronisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldPenyakitKronisActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldPenyakitKronisActionPerformed

    private void fieldRawatRSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldRawatRSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldRawatRSActionPerformed

    private void fieldRiwayatOperasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldRiwayatOperasiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldRiwayatOperasiActionPerformed

    private void ComboBoxGolongandarahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxGolongandarahActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxGolongandarahActionPerformed

    private void fieldAlergiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldAlergiActionPerformed
        //TODO add your handling code here:
    }//GEN-LAST:event_fieldAlergiActionPerformed

    private void inputAlergiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputAlergiActionPerformed
        data_StringAlergi = this.fieldAlergi.getText();
        inputDATA( data_StringAlergi, TEXT, indeksAlergi, CLAText);
        getDATA( indeksAlergi, false, null, dataAlergi, CLAText);
    }//GEN-LAST:event_inputAlergiActionPerformed

    private void deleteAlergiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteAlergiActionPerformed
        deleteText( indeksAlergi, dataAlergi, CLAText);
    }//GEN-LAST:event_deleteAlergiActionPerformed

    private void deleteGolongandarahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteGolongandarahActionPerformed
        deleteText( indeksGolongandarah, dataGolongandarah, CLANum);
    }//GEN-LAST:event_deleteGolongandarahActionPerformed

    private void inputGolongandarahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputGolongandarahActionPerformed
        data_StringGolongandarah = (String) this.ComboBoxGolongandarah.getSelectedItem();
        String dataNUM_StringGolongandarah = Character.toString(data_StringGolongandarah.charAt(0));

        inputDATA( dataNUM_StringGolongandarah, NUM, indeksGolongandarah, CLANum);
        getDATA( indeksGolongandarah, true, symbolGolongandarah, dataGolongandarah, CLANum);
    }//GEN-LAST:event_inputGolongandarahActionPerformed

    private void inputRiwayatOperasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputRiwayatOperasiActionPerformed
        data_StringRiwayatOperasi = this.fieldRiwayatOperasi.getText();
        inputDATA( data_StringRiwayatOperasi, TEXT, indeksRiwayatOperasi, CLAText);
        getDATA( indeksRiwayatOperasi, false, null, dataRiwayatOperasi, CLAText);
    }//GEN-LAST:event_inputRiwayatOperasiActionPerformed

    private void deleteRiwayatOperasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteRiwayatOperasiActionPerformed
        deleteText( indeksRiwayatOperasi, dataRiwayatOperasi, CLAText);
    }//GEN-LAST:event_deleteRiwayatOperasiActionPerformed

    private void inputRawatRSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputRawatRSActionPerformed
        data_StringRawatRS = this.fieldRawatRS.getText();
        inputDATA( data_StringRawatRS, TEXT, indeksRawatRS, CLAText);
        getDATA( indeksRawatRS, false, null, dataRawatRS, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputRawatRSActionPerformed

    private void deleteRawatRSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteRawatRSActionPerformed
        deleteText( indeksRawatRS, dataRawatRS, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteRawatRSActionPerformed

    private void inputPenyakitKronisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputPenyakitKronisActionPerformed
        data_StringPenyakitKronis = this.fieldPenyakitKronis.getText();
        inputDATA( data_StringPenyakitKronis, TEXT, indeksPenyakitKronis, CLAText);
        getDATA( indeksPenyakitKronis, false, null, dataPenyakitKronis, CLAText);
    }//GEN-LAST:event_inputPenyakitKronisActionPerformed

    private void deletePenyakitKronisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePenyakitKronisActionPerformed
        deleteText( indeksPenyakitKronis, dataPenyakitKronis, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deletePenyakitKronisActionPerformed

    private void inputPenyakitBawaanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputPenyakitBawaanActionPerformed
        data_StringPenyakitBawaan = this.fieldPenyakitBawaan.getText();
        inputDATA( data_StringPenyakitBawaan, TEXT, indeksPenyakitBawaan, CLAText);
        getDATA( indeksPenyakitBawaan, false, null, dataPenyakitBawaan, CLAText);
    }//GEN-LAST:event_inputPenyakitBawaanActionPerformed

    private void deletePenyakitBawaanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePenyakitBawaanActionPerformed
        deleteText( indeksPenyakitBawaan, dataPenyakitBawaan, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deletePenyakitBawaanActionPerformed

    private void inputFaktorResikoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputFaktorResikoActionPerformed
        data_StringFaktorResiko = this.fieldFaktorResiko.getText();
        inputDATA( data_StringFaktorResiko, TEXT, indeksFaktorResiko, CLAText);
        getDATA( indeksFaktorResiko, false, null, dataFaktorResiko, CLAText);
    }//GEN-LAST:event_inputFaktorResikoActionPerformed

    private void deleteFaktorResikoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteFaktorResikoActionPerformed
        deleteText( indeksFaktorResiko, dataFaktorResiko, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteFaktorResikoActionPerformed

    private void btnVerifikasiPinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerifikasiPinActionPerformed
        UserPinLogin_Admin loginAdmin= new UserPinLogin_Admin();
        loginAdmin.setRoleType("admin");
        
        loginAdmin.setVisible(true);// TODO add your handling code here:
        
    }//GEN-LAST:event_btnVerifikasiPinActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        Main drv = new Main();
        new ControllerLogin(drv);
        this.dispose();
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHomeActionPerformed
        Home_Admin home = new Home_Admin();
        home.setIsConnected(isConnected);
        home.setVisible(true);
        this.dispose();// TODO add your handling code here:
    }//GEN-LAST:event_btnHomeActionPerformed

    private void fieldICDDiagnosa6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldICDDiagnosa6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldICDDiagnosa6ActionPerformed

    private void fieldICDDiagnosa7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldICDDiagnosa7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldICDDiagnosa7ActionPerformed

    private void fieldICDDiagnosa8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldICDDiagnosa8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldICDDiagnosa8ActionPerformed

    private void fieldICDDiagnosa9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldICDDiagnosa9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldICDDiagnosa9ActionPerformed

//--FUNGSI APDU-------------------------------------------------------------------------------//
    private byte[] getLCData(String byte1Str, String byte2Str) throws Exception
    {
        byte[] data_LC = new byte[2];
        byte byte1 =  Byte.parseByte(byte1Str );
        byte byte2 =  Byte.parseByte(byte2Str);
        data_LC[0] = byte1;
        data_LC[1] = byte2;
      
        return data_LC;
    }
    private boolean selectApplet(byte[] apdu)
    {
        boolean isSelected = false;
        try
        {
            javaCard.sendApdu(apdu);
            byte[] data = javaCard.getData();
            
            //this.status_Label_AdminForm.setText("okok "+Integer.toHexString(javaCard.getStatusWords()).toUpperCase());
            //this.result_Label.setText(new String(data));
            isSelected = true;
            isConnected = isSelected;
        } 
        catch (CardException | IllegalArgumentException | NullPointerException ex) 
        {
            JOptionPane.showMessageDialog(this, "Error while tried to Sslect the applet\n"+ex.getMessage()+"", "APDU sending fail", JOptionPane.ERROR_MESSAGE);
            isSelected = false;
            isConnected = isSelected;
        }        
        
        return isSelected;
    }
    
//--ITEM INPUT-------------------------------------------------------------------------------//    
    private void inputDATA(String data_String, int type, String indeks, String CLA){
        if (!isConnected)
        {
            JOptionPane.showMessageDialog(null, "Kartu Belum Terkoneksi/ Koneksi Ter-Reset.Harap Hubungkan dan Lakukan Verifikasi Ulang");
        }
   
        String data_Hex = null;
        String data_Len = null;
        
        switch(type){
            case NUM:
                data_Hex =  JavaSmartcard.getIntDataHex(data_String);
                data_Len =  JavaSmartcard.getLenHex(data_Hex,type);
                break;
            case TEXT:
                byte[] data_Byte = data_String.getBytes();
                data_Hex = JavaSmartcard.byteArrayToHexString(data_Byte);
                data_Len =  JavaSmartcard.getLenHex(data_String,type);
                break;
        }
        
        //System.out.println("datahex: %s "+data_Hex +"lendaata : "+data_Len);
        String command;
        command = CLA;
        command = command.concat("30");   
        
        command = command.concat(indeks);
        command = command.concat(data_Len);                
        command = command.concat(data_Hex); 
        
        byte[] apdu = JavaSmartcard.hexStringToByteArray(command);
        System.out.println(""+ JavaSmartcard.htos(apdu));
        try
        {
            javaCard.sendApdu(apdu);
            
            byte[] data = javaCard.getData();
            status = ""+Integer.toHexString(javaCard.getStatusWords()).toUpperCase();
            System.out.println(status);
            
            this.status_Label_AdminForm.setText(status);
            
        } 
        catch (CardException | IllegalArgumentException ex) 
        {
            JOptionPane.showMessageDialog(this, "Error while tried to send command APDU: SEND DATA\n"+ex.getMessage()+"", "APDU SEND fail", JOptionPane.ERROR_MESSAGE);
        }
    }

//--ITEM GET-------------------------------------------------------------------------------//    
    private void getDATA(String indeks, boolean symEx, String[] symbol, javax.swing.JLabel fieldData, String CLA){
        String command = "00A40400";
        command = command.concat(appletID);
        
        byte[] apdu = JavaSmartcard.hexStringToByteArray(command);
        if (!isConnected)
        {
            JOptionPane.showMessageDialog(null, "Kartu Belum Terkoneksi/ Koneksi Ter-Reset.Harap Hubungkan dan Lakukan Verifikasi Ulang");
        }
       
        command = CLA;
        command = command.concat("50");
   
        command = command.concat(indeks);
        
        apdu = JavaSmartcard.hexStringToByteArray(command);
        System.out.println(""+ JavaSmartcard.htos(apdu));
        try
        {
            javaCard.sendApdu(apdu);
            byte[] data = javaCard.getData();
            
            status = ""+Integer.toHexString(javaCard.getStatusWords()).toUpperCase();
            System.out.println(status);
            //this.status_Label.setText(""+Integer.toHexString(javaCard.getStatusWords()).toUpperCase());
            if (symEx){
            ByteBuffer dataWrapped = ByteBuffer.wrap(data);
            short indeksSymbol = dataWrapped.getShort();
            
            fieldData.setText(symbol[indeksSymbol-1]);
            }else{    
            fieldData.setText(new String(data));
            }
        } 
        catch (CardException | IllegalArgumentException ex) 
        {
            JOptionPane.showMessageDialog(this, "Error while tried to send command APDU: GETD DATA\n"+ex.getMessage()+"", "APDU GET fail", JOptionPane.ERROR_MESSAGE);
        }
    }
    //DINAMIS
    private void getDataDinamis(String indeks, boolean symEx, String[] symbol, javax.swing.JLabel fieldData, String CLA, boolean floatData, String getStack){
        String command = "00A40400";
        command = command.concat(appletID);
        
        byte[] apdu = JavaSmartcard.hexStringToByteArray(command);
        if (!isConnected)
        {
            JOptionPane.showMessageDialog(null, "Kartu Belum Terkoneksi/ Koneksi Ter-Reset.Harap Hubungkan dan Lakukan Verifikasi Ulang");
        }
        
        String data_hex = JavaSmartcard.getIntDataHex(getStack);
        
            
        command = CLA;
        command = command.concat("50");
        command = command.concat(indeks);
   
        command = command.concat("01");
        command = command.concat(data_hex);
        
        apdu = JavaSmartcard.hexStringToByteArray(command);
        System.out.println(""+ JavaSmartcard.htos(apdu));
        try
        {
            javaCard.sendApdu(apdu);
            byte[] data = javaCard.getData();
            System.out.println(JavaSmartcard.byteArrayToHexString(data));
            //this.status_Label.setText(""+Integer.toHexString(javaCard.getStatusWords()).toUpperCase());
            if (symEx){
                if(floatData){
                    ByteBuffer dataWrapped = ByteBuffer.wrap(data);
                    Short data_short = dataWrapped.getShort();
                    //Short data_shortObject = new Short(data_short);
                    
                    float data_float = data_short.floatValue();
                    System.out.println(data_float);
                    
                    String data_text = Float.toString(data_float/100);
                    
                    fieldData.setText(data_text);
                }else{
                    ByteBuffer dataWrapped = ByteBuffer.wrap(data);
                    
                    if(symbol == null){
                        short data_short = dataWrapped.getShort();
                        String val_short = Short.toString(data_short);
                        fieldData.setText(val_short);
                    }else{
                        short indeksSymbol = dataWrapped.getShort();
                        fieldData.setText(symbol[indeksSymbol-1]);
                    }
                }
            }else{    
            fieldData.setText(new String(data));
            }
        } 
        catch (CardException | IllegalArgumentException ex) 
        {
            JOptionPane.showMessageDialog(this, "Error while tried to send command APDU: GETD DATA\n"+ex.getMessage()+"", "APDU GET fail", JOptionPane.ERROR_MESSAGE);
        }
    }
//--ITEM DELETE-------------------------------------------------------------------------------//    
    private void deleteText(String indeks, javax.swing.JLabel fieldData, String CLA){
        String command = "00A40400";
        command = command.concat(appletID);
        
        byte[] apdu = JavaSmartcard.hexStringToByteArray(command);
        if (!isConnected)
        {
            JOptionPane.showMessageDialog(null, "Kartu Belum Terkoneksi/ Koneksi Ter-Reset.Harap Hubungkan dan Lakukan Verifikasi Ulang");
        }
       
        command = CLA;
        command = command.concat("40");
        command = command.concat(indeks);
        
        apdu = JavaSmartcard.hexStringToByteArray(command);
        System.out.println(""+ JavaSmartcard.htos(apdu));
        try
        {
            javaCard.sendApdu(apdu);
            
            byte[] data = javaCard.getData();
            status = ""+Integer.toHexString(javaCard.getStatusWords()).toUpperCase();
            System.out.println(status);
            
            this.status_Label_AdminForm.setText(status);
            fieldData.setText("-");
        } 
        catch (CardException | IllegalArgumentException ex) 
        {
            JOptionPane.showMessageDialog(this, "Error while tried to send command APDU: GETD DATA\n"+ex.getMessage()+"", "APDU DELETE fail", JOptionPane.ERROR_MESSAGE);
        }
    }

//--FUNGSI ALL CRUD-------------------------------------------------------------------------------//        
    //STATIS
       //STATIS
    private void getAllSTATIS(){
         //STATIS
        getDATA( indeksAlergi, false, null, dataAlergi, CLAText);
        getDATA( indeksGolongandarah, true, symbolGolongandarah, dataGolongandarah, CLANum);
        getDATA( indeksRiwayatOperasi, false, null, dataRiwayatOperasi, CLAText);
        getDATA( indeksRawatRS, false, null, dataRawatRS, CLAText);
        getDATA( indeksPenyakitKronis, false, null, dataPenyakitKronis, CLAText);
        getDATA( indeksPenyakitBawaan, false, null, dataPenyakitBawaan, CLAText);
        getDATA( indeksFaktorResiko, false, null, dataFaktorResiko, CLAText);
        // TODO add your handling code here:

    }
    private void inputAllSTATIS(){
        //STATIS
        // Alergi
        data_StringAlergi = this.fieldAlergi.getText();
        inputDATA( data_StringAlergi, TEXT, indeksAlergi, CLAText);
        getDATA( indeksAlergi, false, null, dataAlergi, CLAText);
        // Golongandarah
        data_StringGolongandarah = (String) this.ComboBoxGolongandarah.getSelectedItem();
        String dataNUM_StringGolongandarah = Character.toString(data_StringGolongandarah.charAt(0));
        inputDATA( dataNUM_StringGolongandarah, NUM, indeksGolongandarah, CLANum);
        getDATA( indeksGolongandarah, true, symbolGolongandarah, dataGolongandarah, CLANum);
        // RiwayatOperasi
        data_StringRiwayatOperasi = this.fieldRiwayatOperasi.getText();
        inputDATA( data_StringRiwayatOperasi, TEXT, indeksRiwayatOperasi, CLAText);
        getDATA( indeksRiwayatOperasi, false, null, dataRiwayatOperasi, CLAText);
        // RawatRS
        data_StringRawatRS = this.fieldRawatRS.getText();
        inputDATA( data_StringRawatRS, TEXT, indeksRawatRS, CLAText);
        getDATA( indeksRawatRS, false, null, dataRawatRS, CLAText);
        // PenyakitKronis
        data_StringPenyakitKronis = this.fieldPenyakitKronis.getText();
        inputDATA( data_StringPenyakitKronis, TEXT, indeksPenyakitKronis, CLAText);
        getDATA( indeksPenyakitKronis, false, null, dataPenyakitKronis, CLAText);
        // PenyakitBawaan
        data_StringPenyakitBawaan = this.fieldPenyakitBawaan.getText();
        inputDATA( data_StringPenyakitBawaan, TEXT, indeksPenyakitBawaan, CLAText);
        getDATA( indeksPenyakitBawaan, false, null, dataPenyakitBawaan, CLAText);
        // FaktorResiko
        data_StringFaktorResiko = this.fieldFaktorResiko.getText();
        inputDATA( data_StringFaktorResiko, TEXT, indeksFaktorResiko, CLAText);
        getDATA( indeksFaktorResiko, false, null, dataFaktorResiko, CLAText);
    }
    private void deleteAllStatis(){
        deleteText( indeksAlergi, dataAlergi, CLAText);
        deleteText( indeksGolongandarah, dataGolongandarah, CLANum);
        deleteText( indeksRiwayatOperasi, dataRiwayatOperasi, CLAText);
        deleteText( indeksRawatRS, dataRawatRS, CLAText);
        deleteText( indeksPenyakitKronis, dataPenyakitKronis, CLAText);
        deleteText( indeksPenyakitBawaan, dataPenyakitBawaan, CLAText);
        deleteText( indeksFaktorResiko, dataFaktorResiko, CLAText);
        
    }
    
    //ALL DINAMIS    
    private void getCurrentStack(){
        String command = "00A40400";
        command = command.concat(appletID);
        byte[] apdu = JavaSmartcard.hexStringToByteArray(command);
        
       if (!isConnected)
       {
            //JOptionPane.showMessageDialog(null, "Kartu Belum Terkoneksi/ Koneksi Ter-Reset.Harap Hubungkan dan Lakukan Verifikasi Ulang");
       }
        
        command = "90900000";
        
        apdu = JavaSmartcard.hexStringToByteArray(command);
        System.out.println(""+ JavaSmartcard.htos(apdu));
        try
        {
            javaCard.sendApdu(apdu);
            byte[] data = javaCard.getData();
            
            this.status_Label_AdminForm.setText(""+Integer.toHexString(javaCard.getStatusWords()).toUpperCase());
            ByteBuffer dataWrapped = ByteBuffer.wrap(data);
            short data_short = dataWrapped.getShort();
            dataStack.setText(String.valueOf(data_short));
            fieldCurrentStack.setText(String.valueOf(data_short));
        } 
        catch (CardException | IllegalArgumentException ex) 
        {
            JOptionPane.showMessageDialog(this, "Error while tried to send command APDU: GETD DATA\n"+ex.getMessage()+"", "APDU DELETE fail", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void getAllDINAMIS(){
        // Stack
        getCurrentStack();	
		
	//DINAMIS
	// TanggalPeriksa
	getDataDinamis( indeksTanggalPeriksa, false, null, dataTanggalPeriksa, CLAText, false, fieldCurrentStack.getText());
	// Keluhanutama
	getDataDinamis( indeksKeluhanutama, false, null, dataKeluhanutama, CLAText, false, fieldCurrentStack.getText());
	// Anamnesa
	getDataDinamis( indeksAnamnesa, false, null, dataAnamnesa, CLAText, false, fieldCurrentStack.getText());
	// PenyakitDahulu
	getDataDinamis( indeksPenyakitDahulu, false, null, dataPenyakitDahulu, CLAText, false, fieldCurrentStack.getText());
	// PenyakitKeluarga
	getDataDinamis( indeksPenyakitKeluarga, false, null, dataPenyakitKeluarga, CLAText, false, fieldCurrentStack.getText());
	// PemeriksaanFisik
	getDataDinamis( indeksPemeriksaanFisik, false, null, dataPemeriksaanFisik, CLAText, false, fieldCurrentStack.getText());
	// Tinggi
	getDataDinamis( indeksTinggi, true, null, dataTinggi, CLANum, false, fieldCurrentStack.getText());
	// Beratbadan
	getDataDinamis( indeksBeratbadan, true, null, dataBeratbadan, CLANum, false, fieldCurrentStack.getText());
	// Systole
	getDataDinamis( indeksSystole, true, null, dataSystole, CLANum, false, fieldCurrentStack.getText());
	// Diastole
	getDataDinamis( indeksDiastole, true, null, dataDiastole, CLANum, false, fieldCurrentStack.getText());
	// Nadi
	getDataDinamis( indeksNadi, true, null, dataNadi, CLANum, false, fieldCurrentStack.getText());
	// Kesadaran
	getDataDinamis( indeksKesadaran, true, symbolKesadaran, dataKesadaran, CLANum, false, fieldCurrentStack.getText());
	// Suhu
	getDataDinamis( indeksSuhu, true, null, dataSuhu, CLANum, true, fieldCurrentStack.getText());
	// Respirasi
	getDataDinamis( indeksRespirasi, true, null, dataRespirasi, CLANum, false, fieldCurrentStack.getText());
	// Lain-lain
	getDataDinamis( indeksLain, false, null, dataLain, CLAText, false, fieldCurrentStack.getText());
	// LabExecuteFlag
	getDataDinamis( indeksLabExecuteFlag, true, symbolLabExecuteFlag, dataLabExecuteFlag, CLANum, false, fieldCurrentStack.getText());
	// ExpertiseLab
	getDataDinamis( indeksExpertiseLab, false, null, dataExpertiseLab, CLAText, false, fieldCurrentStack.getText());
	// CatatanLab
	getDataDinamis( indeksCatatanLab, false, null, dataCatatanLab, CLAText, false, fieldCurrentStack.getText());
	// Terapi
	getDataDinamis( indeksTerapi, false, null, dataTerapi, CLAText, false, fieldCurrentStack.getText());
	// Resep
	getDataDinamis( indeksResep, false, null, dataResep, CLAText, false, fieldCurrentStack.getText());
	// Catatanresep
	getDataDinamis( indeksCatatanresep, false, null, dataCatatanresep, CLAText, false, fieldCurrentStack.getText());
	// EksekusiResep
	getDataDinamis( indeksEksekusiResep, true, symbolEksekusiResep, dataEksekusiResep, CLANum, false, fieldCurrentStack.getText());
	// Repetisiresep
	getDataDinamis( indeksRepetisiresep, true, symbolRepetisiresep, dataRepetisiresep, CLANum, false, fieldCurrentStack.getText());
	// Prognosa
	getDataDinamis( indeksPrognosa, true, symbolPrognosa, dataPrognosa, CLANum, false, fieldCurrentStack.getText());
	// ICD1
	getDataDinamis( indeksICD1, false, null, dataICD1, CLAText, false, fieldCurrentStack.getText());
	// ICD2
	getDataDinamis( indeksICD2, false, null, dataICD2, CLAText, false, fieldCurrentStack.getText());
	// ICD3
	getDataDinamis( indeksICD3, false, null, dataICD3, CLAText, false, fieldCurrentStack.getText());
	// ICD4
	getDataDinamis( indeksICD4, false, null, dataICD4, CLAText, false, fieldCurrentStack.getText());
	// ICD5
	getDataDinamis( indeksICD5, false, null, dataICD5, CLAText, false, fieldCurrentStack.getText());
	// ICD6
	getDataDinamis( indeksICD6, false, null, dataICD6, CLAText, false, fieldCurrentStack.getText());
	// ICD7
	getDataDinamis( indeksICD7, false, null, dataICD7, CLAText, false, fieldCurrentStack.getText());
	// ICD8
	getDataDinamis( indeksICD8, false, null, dataICD8, CLAText, false, fieldCurrentStack.getText());
	// ICD9
	getDataDinamis( indeksICD9, false, null, dataICD9, CLAText, false, fieldCurrentStack.getText());
	// ICD10
	getDataDinamis( indeksICD10, false, null, dataICD10, CLAText, false, fieldCurrentStack.getText());
	// ICDDiagnosa1
	getDataDinamis( indeksICDDiagnosa1, false, null, dataICDDiagnosa1, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa2
	getDataDinamis( indeksICDDiagnosa2, false, null, dataICDDiagnosa2, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa3
	getDataDinamis( indeksICDDiagnosa3, false, null, dataICDDiagnosa3, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa4
	getDataDinamis( indeksICDDiagnosa4, false, null, dataICDDiagnosa4, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa5
	getDataDinamis( indeksICDDiagnosa5, false, null, dataICDDiagnosa5, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa6
	getDataDinamis( indeksICDDiagnosa6, false, null, dataICDDiagnosa6, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa7
	getDataDinamis( indeksICDDiagnosa7, false, null, dataICDDiagnosa7, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa8
	getDataDinamis( indeksICDDiagnosa8, false, null, dataICDDiagnosa8, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa9
	getDataDinamis( indeksICDDiagnosa9, false, null, dataICDDiagnosa9, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa10
	getDataDinamis( indeksICDDiagnosa10, false, null, dataICDDiagnosa10, CLANum, false, fieldCurrentStack.getText());
	// PoliTujuan
	getDataDinamis( indeksPoliTujuan, false, null, dataPoliTujuan, CLAText, false, fieldCurrentStack.getText());
	// Rujukan
	getDataDinamis( indeksRujukan, false, null, dataRujukan, CLAText, false, fieldCurrentStack.getText());
	// IDPuskesmas
	getDataDinamis( indeksIDPuskesmas, false, null, dataIDPuskesmas, CLAText, false, fieldCurrentStack.getText());
    }
    private void inputAllDinamis(){
        // Stack
        getCurrentStack();	
		
	//DINAMIS
	// TanggalPeriksa
	data_StringTanggalPeriksa = this.fieldTanggalPeriksa.getText();
	inputDATA( data_StringTanggalPeriksa, TEXT, indeksTanggalPeriksa, CLAText);
	getDataDinamis( indeksTanggalPeriksa, false, null, dataTanggalPeriksa, CLAText, false, fieldCurrentStack.getText());
	// Keluhanutama
	data_StringKeluhanutama = this.fieldKeluhanutama.getText();
	inputDATA( data_StringKeluhanutama, TEXT, indeksKeluhanutama, CLAText);
	getDataDinamis( indeksKeluhanutama, false, null, dataKeluhanutama, CLAText, false, fieldCurrentStack.getText());
	// Anamnesa
	data_StringAnamnesa = this.fieldAnamnesa.getText();
	inputDATA( data_StringAnamnesa, TEXT, indeksAnamnesa, CLAText);
	getDataDinamis( indeksAnamnesa, false, null, dataAnamnesa, CLAText, false, fieldCurrentStack.getText());
	// PenyakitDahulu
	data_StringPenyakitDahulu = this.fieldPenyakitDahulu.getText();
	inputDATA( data_StringPenyakitDahulu, TEXT, indeksPenyakitDahulu, CLAText);
	getDataDinamis( indeksPenyakitDahulu, false, null, dataPenyakitDahulu, CLAText, false, fieldCurrentStack.getText());
	// PenyakitKeluarga
	data_StringPenyakitKeluarga = this.fieldPenyakitKeluarga.getText();
	inputDATA( data_StringPenyakitKeluarga, TEXT, indeksPenyakitKeluarga, CLAText);
	getDataDinamis( indeksPenyakitKeluarga, false, null, dataPenyakitKeluarga, CLAText, false, fieldCurrentStack.getText());
	// PemeriksaanFisik
	data_StringPemeriksaanFisik = this.fieldPemeriksaanFisik.getText();
	inputDATA( data_StringPemeriksaanFisik, TEXT, indeksPemeriksaanFisik, CLAText);
	getDataDinamis( indeksPemeriksaanFisik, false, null, dataPemeriksaanFisik, CLAText, false, fieldCurrentStack.getText());
	// Tinggi
	data_StringTinggi = this.fieldTinggi.getText();
	inputDATA( data_StringTinggi, NUM, indeksTinggi, CLANum);
	getDataDinamis( indeksTinggi, true, null, dataTinggi, CLANum, false, fieldCurrentStack.getText());
	// Beratbadan
	String dataNUM_StringBeratbadan = this.fieldBeratbadan.getText();
	inputDATA( dataNUM_StringBeratbadan, NUM, indeksBeratbadan, CLANum);
	getDataDinamis( indeksBeratbadan, true, null, dataBeratbadan, CLANum, false, fieldCurrentStack.getText());
	// Systole
	String dataNUM_StringSystole = this.fieldSystole.getText();
	inputDATA( dataNUM_StringSystole, NUM, indeksSystole, CLANum);
	getDataDinamis( indeksSystole, true, null, dataSystole, CLANum, false, fieldCurrentStack.getText());
	// Diastole
	String dataNUM_StringDiastole = this.fieldDiastole.getText();
	inputDATA( dataNUM_StringDiastole, NUM, indeksDiastole, CLANum);
	getDataDinamis( indeksDiastole, true, null, dataDiastole, CLANum, false, fieldCurrentStack.getText());
	// Nadi
	String dataNUM_StringNadi = this.fieldNadi.getText();
	inputDATA( dataNUM_StringNadi, NUM, indeksNadi, CLANum);
	getDataDinamis( indeksNadi, true, null, dataNadi, CLANum, false, fieldCurrentStack.getText());
	// Kesadaran
	String dataNUM_StringKesadaran = Integer.toString(ComboBox_Kesadaran.getSelectedIndex()+1);
	inputDATA( dataNUM_StringKesadaran, NUM, indeksKesadaran, CLANum);
	getDataDinamis( indeksKesadaran, true, symbolKesadaran, dataKesadaran, CLANum, false, fieldCurrentStack.getText());
	// Suhu
	String data_String;
        data_StringSuhu = (String) this.fieldSuhu.getText();
        float dataTEXT_Float = Float.parseFloat(data_StringSuhu);
        dataTEXT_Float = dataTEXT_Float*100;
        String dataNUM_StringSuhu = String.valueOf((int) dataTEXT_Float);
        
	inputDATA( dataNUM_StringSuhu, NUM, indeksSuhu, CLANum);
	getDataDinamis( indeksSuhu, true, null, dataSuhu, CLANum, true, fieldCurrentStack.getText());
	// Respirasi
	String dataNUM_StringRespirasi = this.fieldRespirasi.getText();
	inputDATA( dataNUM_StringRespirasi, NUM, indeksRespirasi, CLANum);
	getDataDinamis( indeksRespirasi, true, null, dataRespirasi, CLANum, false, fieldCurrentStack.getText());
	// Lain-lain
	data_StringLain = this.fieldLain.getText();
	inputDATA( data_StringLain, TEXT, indeksLain, CLAText);
	getDataDinamis( indeksLain, false, null, dataLain, CLAText, false, fieldCurrentStack.getText());
	// LabExecuteFlag
	String dataNUM_StringLabExecuteFlag = Integer.toString(ComboBox_LabExecuteFlag.getSelectedIndex()+1);
	inputDATA( dataNUM_StringLabExecuteFlag, NUM, indeksLabExecuteFlag, CLANum);
	getDataDinamis( indeksLabExecuteFlag, true, symbolLabExecuteFlag, dataLabExecuteFlag, CLANum, false, fieldCurrentStack.getText());
	// ExpertiseLab
	data_StringExpertiseLab = this.fieldExpertiseLab.getText();
	inputDATA( data_StringExpertiseLab, TEXT, indeksExpertiseLab, CLAText);
	getDataDinamis( indeksExpertiseLab, false, null, dataExpertiseLab, CLAText, false, fieldCurrentStack.getText());
	// CatatanLab
	data_StringCatatanLab = this.fieldCatatanLab.getText();
	inputDATA( data_StringCatatanLab, TEXT, indeksCatatanLab, CLAText);
	getDataDinamis( indeksCatatanLab, false, null, dataCatatanLab, CLAText, false, fieldCurrentStack.getText());
	// Terapi
	data_StringTerapi = this.fieldTerapi.getText();
	inputDATA( data_StringTerapi, TEXT, indeksTerapi, CLAText);
	getDataDinamis( indeksTerapi, false, null, dataTerapi, CLAText, false, fieldCurrentStack.getText());
	// Resep
	data_StringResep = this.fieldResep.getText();
	inputDATA( data_StringResep, TEXT, indeksResep, CLAText);
	getDataDinamis( indeksResep, false, null, dataResep, CLAText, false, fieldCurrentStack.getText());
	// Catatanresep
	data_StringCatatanresep = this.fieldCatatanresep.getText();
	inputDATA( data_StringCatatanresep, TEXT, indeksCatatanresep, CLAText);
	getDataDinamis( indeksCatatanresep, false, null, dataCatatanresep, CLAText, false, fieldCurrentStack.getText());
	// EksekusiResep
	String dataNUM_StringEksekusiResep = Integer.toString(ComboBox_EksekusiResep.getSelectedIndex()+1);
	inputDATA( dataNUM_StringEksekusiResep, NUM, indeksEksekusiResep, CLANum);
	getDataDinamis( indeksEksekusiResep, true, symbolEksekusiResep, dataEksekusiResep, CLANum, false, fieldCurrentStack.getText());
	// Repetisiresep
	String dataNUM_StringRepetisiresep = Integer.toString(ComboBox_Repetisiresep.getSelectedIndex()+1);
	inputDATA( dataNUM_StringRepetisiresep, NUM, indeksRepetisiresep, CLANum);
	getDataDinamis( indeksRepetisiresep, true, symbolRepetisiresep, dataRepetisiresep, CLANum, false, fieldCurrentStack.getText());
	// Prognosa
	String dataNUM_StringPrognosa = Integer.toString(ComboBox_Prognosa.getSelectedIndex()+1);
	inputDATA( dataNUM_StringPrognosa, NUM, indeksPrognosa, CLANum);
	getDataDinamis( indeksPrognosa, true, symbolPrognosa, dataPrognosa, CLANum, false, fieldCurrentStack.getText());
	// ICD1
	data_StringICD1 = this.fieldICD1.getText();
	inputDATA( data_StringICD1, TEXT, indeksICD1, CLAText);
	getDataDinamis( indeksICD1, false, null, dataICD1, CLAText, false, fieldCurrentStack.getText());
	// ICD2
	data_StringICD2 = this.fieldICD2.getText();
	inputDATA( data_StringICD2, TEXT, indeksICD2, CLAText);
	getDataDinamis( indeksICD2, false, null, dataICD2, CLAText, false, fieldCurrentStack.getText());
	// ICD3
	data_StringICD3 = this.fieldICD3.getText();
	inputDATA( data_StringICD3, TEXT, indeksICD3, CLAText);
	getDataDinamis( indeksICD3, false, null, dataICD3, CLAText, false, fieldCurrentStack.getText());
	// ICD4
	data_StringICD4 = this.fieldICD4.getText();
	inputDATA( data_StringICD4, TEXT, indeksICD4, CLAText);
	getDataDinamis( indeksICD4, false, null, dataICD4, CLAText, false, fieldCurrentStack.getText());
	// ICD5
	data_StringICD5 = this.fieldICD5.getText();
	inputDATA( data_StringICD5, TEXT, indeksICD5, CLAText);
	getDataDinamis( indeksICD5, false, null, dataICD5, CLAText, false, fieldCurrentStack.getText());
	// ICD6
	data_StringICD6 = this.fieldICD6.getText();
	inputDATA( data_StringICD6, TEXT, indeksICD6, CLAText);
	getDataDinamis( indeksICD6, false, null, dataICD6, CLAText, false, fieldCurrentStack.getText());
	// ICD7
	data_StringICD7 = this.fieldICD7.getText();
	inputDATA( data_StringICD7, TEXT, indeksICD7, CLAText);
	getDataDinamis( indeksICD7, false, null, dataICD7, CLAText, false, fieldCurrentStack.getText());
	// ICD8
	data_StringICD8 = this.fieldICD8.getText();
	inputDATA( data_StringICD8, TEXT, indeksICD8, CLAText);
	getDataDinamis( indeksICD8, false, null, dataICD8, CLAText, false, fieldCurrentStack.getText());
	// ICD9
	data_StringICD9 = this.fieldICD9.getText();
	inputDATA( data_StringICD9, TEXT, indeksICD9, CLAText);
	getDataDinamis( indeksICD9, false, null, dataICD9, CLAText, false, fieldCurrentStack.getText());
	// ICD10
	data_StringICD10 = this.fieldICD10.getText();
	inputDATA( data_StringICD10, TEXT, indeksICD10, CLAText);
	getDataDinamis( indeksICD10, false, null, dataICD10, CLAText, false, fieldCurrentStack.getText());
	// ICDDiagnosa1
	String dataNUM_StringICDDiagnosa1 = this.fieldICDDiagnosa1.getText();
	inputDATA( dataNUM_StringICDDiagnosa1, NUM, indeksICDDiagnosa1, CLANum);
	getDataDinamis( indeksICDDiagnosa1, false, null, dataICDDiagnosa1, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa2
	String dataNUM_StringICDDiagnosa2 = this.fieldICDDiagnosa2.getText();
	inputDATA( dataNUM_StringICDDiagnosa2, NUM, indeksICDDiagnosa2, CLANum);
	getDataDinamis( indeksICDDiagnosa2, false, null, dataICDDiagnosa2, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa3
	String dataNUM_StringICDDiagnosa3 = this.fieldICDDiagnosa3.getText();
	inputDATA( dataNUM_StringICDDiagnosa3, NUM, indeksICDDiagnosa3, CLANum);
	getDataDinamis( indeksICDDiagnosa3, false, null, dataICDDiagnosa3, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa4
	String dataNUM_StringICDDiagnosa4 = this.fieldICDDiagnosa4.getText();
	inputDATA( dataNUM_StringICDDiagnosa4, NUM, indeksICDDiagnosa4, CLANum);
	getDataDinamis( indeksICDDiagnosa4, false, null, dataICDDiagnosa4, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa5
	String dataNUM_StringICDDiagnosa5 = this.fieldICDDiagnosa5.getText();
	inputDATA( dataNUM_StringICDDiagnosa5, NUM, indeksICDDiagnosa5, CLANum);
	getDataDinamis( indeksICDDiagnosa5, false, null, dataICDDiagnosa5, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa6
	String dataNUM_StringICDDiagnosa6 = this.fieldICDDiagnosa6.getText();
	inputDATA( dataNUM_StringICDDiagnosa6, NUM, indeksICDDiagnosa6, CLANum);
	getDataDinamis( indeksICDDiagnosa6, false, null, dataICDDiagnosa6, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa7
	String dataNUM_StringICDDiagnosa7 = this.fieldICDDiagnosa7.getText();
	inputDATA( dataNUM_StringICDDiagnosa7, NUM, indeksICDDiagnosa7, CLANum);
	getDataDinamis( indeksICDDiagnosa7, false, null, dataICDDiagnosa7, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa8
	String dataNUM_StringICDDiagnosa8 = this.fieldICDDiagnosa8.getText();
	inputDATA( dataNUM_StringICDDiagnosa8, NUM, indeksICDDiagnosa8, CLANum);
	getDataDinamis( indeksICDDiagnosa8, false, null, dataICDDiagnosa8, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa9
	String dataNUM_StringICDDiagnosa9 = this.fieldICDDiagnosa9.getText();
	inputDATA( dataNUM_StringICDDiagnosa9, NUM, indeksICDDiagnosa9, CLANum);
	getDataDinamis( indeksICDDiagnosa9, false, null, dataICDDiagnosa9, CLANum, false, fieldCurrentStack.getText());
	// ICDDiagnosa10
	String dataNUM_StringICDDiagnosa10 = this.fieldICDDiagnosa10.getText();
	inputDATA( dataNUM_StringICDDiagnosa10, NUM, indeksICDDiagnosa10, CLANum);
	getDataDinamis( indeksICDDiagnosa10, false, null, dataICDDiagnosa10, CLANum, false, fieldCurrentStack.getText());
	// PoliTujuan
	data_StringPoliTujuan = this.fieldPoliTujuan.getText();
	inputDATA( data_StringPoliTujuan, TEXT, indeksPoliTujuan, CLAText);
	getDataDinamis( indeksPoliTujuan, false, null, dataPoliTujuan, CLAText, false, fieldCurrentStack.getText());
	// Rujukan
	data_StringRujukan = this.fieldRujukan.getText();
	inputDATA( data_StringRujukan, TEXT, indeksRujukan, CLAText);
	getDataDinamis( indeksRujukan, false, null, dataRujukan, CLAText, false, fieldCurrentStack.getText());
	// IDPuskesmas
	data_StringIDPuskesmas = this.fieldIDPuskesmas.getText();
	inputDATA( data_StringIDPuskesmas, TEXT, indeksIDPuskesmas, CLAText);
	getDataDinamis( indeksIDPuskesmas, false, null, dataIDPuskesmas, CLAText, false, fieldCurrentStack.getText());

    }
    private void deleteAllDinamis(){
	deleteText( indeksTanggalPeriksa, dataTanggalPeriksa, CLAText);
	deleteText( indeksKeluhanutama, dataKeluhanutama, CLAText);
	deleteText( indeksAnamnesa, dataAnamnesa, CLAText);
	deleteText( indeksPenyakitDahulu, dataPenyakitDahulu, CLAText);
	deleteText( indeksPenyakitKeluarga, dataPenyakitKeluarga, CLAText);
	deleteText( indeksPemeriksaanFisik, dataPemeriksaanFisik, CLAText);
	deleteText( indeksTinggi, dataTinggi, CLAText);
	deleteText( indeksBeratbadan, dataBeratbadan, CLANum);
	deleteText( indeksSystole, dataSystole, CLANum);
	deleteText( indeksDiastole, dataDiastole, CLANum);
	deleteText( indeksNadi, dataNadi, CLANum);
	deleteText( indeksKesadaran, dataKesadaran, CLANum);
	deleteText( indeksSuhu, dataSuhu, CLAText);
	deleteText( indeksRespirasi, dataRespirasi, CLANum);
	deleteText( indeksLain, dataLain, CLAText);
	deleteText( indeksLabExecuteFlag, dataLabExecuteFlag, CLANum);
	deleteText( indeksExpertiseLab, dataExpertiseLab, CLAText);
	deleteText( indeksCatatanLab, dataCatatanLab, CLAText);
	deleteText( indeksTerapi, dataTerapi, CLAText);
	deleteText( indeksResep, dataResep, CLAText);
	deleteText( indeksCatatanresep, dataCatatanresep, CLAText);
	deleteText( indeksEksekusiResep, dataEksekusiResep, CLANum);
	deleteText( indeksRepetisiresep, dataRepetisiresep, CLANum);
	deleteText( indeksPrognosa, dataPrognosa, CLANum);
	deleteText( indeksICD1, dataICD1, CLAText);
	deleteText( indeksICD2, dataICD2, CLAText);
	deleteText( indeksICD3, dataICD3, CLAText);
	deleteText( indeksICD4, dataICD4, CLAText);
	deleteText( indeksICD5, dataICD5, CLAText);
	deleteText( indeksICD6, dataICD6, CLAText);
	deleteText( indeksICD7, dataICD7, CLAText);
	deleteText( indeksICD8, dataICD8, CLAText);
	deleteText( indeksICD9, dataICD9, CLAText);
	deleteText( indeksICD10, dataICD10, CLAText);
	deleteText( indeksICDDiagnosa1, dataICDDiagnosa1, CLANum);
	deleteText( indeksICDDiagnosa2, dataICDDiagnosa2, CLANum);
	deleteText( indeksICDDiagnosa3, dataICDDiagnosa3, CLANum);
	deleteText( indeksICDDiagnosa4, dataICDDiagnosa4, CLANum);
	deleteText( indeksICDDiagnosa5, dataICDDiagnosa5, CLANum);
	deleteText( indeksICDDiagnosa6, dataICDDiagnosa6, CLANum);
	deleteText( indeksICDDiagnosa7, dataICDDiagnosa7, CLANum);
	deleteText( indeksICDDiagnosa8, dataICDDiagnosa8, CLANum);
	deleteText( indeksICDDiagnosa9, dataICDDiagnosa9, CLANum);
	deleteText( indeksICDDiagnosa10, dataICDDiagnosa10, CLANum);
	deleteText( indeksPoliTujuan, dataPoliTujuan, CLAText);
	deleteText( indeksRujukan, dataRujukan, CLAText);
	deleteText( indeksIDPuskesmas, dataIDPuskesmas, CLAText);
    }
    private void registerRecordDinamis(){
        String command = "00A40400";
        command = command.concat(appletID);
        byte[] apdu = JavaSmartcard.hexStringToByteArray(command);
        
        if (!isConnected)
        {
            JOptionPane.showMessageDialog(null, "Kartu Belum Terkoneksi/ Koneksi Ter-Reset.Harap Hubungkan dan Lakukan Verifikasi Ulang");
        }
        
        command = "90100000";
        
        apdu = JavaSmartcard.hexStringToByteArray(command);
        System.out.println(""+ JavaSmartcard.htos(apdu));
        try
        {
            javaCard.sendApdu(apdu);
            byte[] data = javaCard.getData();
            
            getCurrentStack();
        } 
        catch (CardException | IllegalArgumentException ex) 
        {
            JOptionPane.showMessageDialog(this, "Error while tried to send command APDU: GETD DATA\n"+ex.getMessage()+"", "APDU DELETE fail", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public boolean getIsConnected(){
        return this.isConnected;
    }
    
    public void setIsConnected(boolean statConnection){
        this.isConnected = statConnection;
    }

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboBoxGolongandarah;
    private javax.swing.JComboBox<String> ComboBoxStackView;
    private javax.swing.JComboBox<String> ComboBox_EksekusiResep;
    private javax.swing.JComboBox<String> ComboBox_Kesadaran;
    private javax.swing.JComboBox<String> ComboBox_LabExecuteFlag;
    private javax.swing.JComboBox<String> ComboBox_Prognosa;
    private javax.swing.JComboBox<String> ComboBox_Repetisiresep;
    private javax.swing.JButton GetStackDinamis;
    private javax.swing.JPanel PanelReaderCard;
    private javax.swing.JPanel RekamMedisDinamis;
    private javax.swing.JPanel RekamMedisDinamis1;
    private javax.swing.JPanel RekamMedisStatis;
    private javax.swing.JLabel administrator;
    private javax.swing.JLabel administrator1;
    private javax.swing.JButton btnHome;
    private javax.swing.JButton btnLogOut;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnVerifikasiPin;
    private javax.swing.JLabel dataAlergi;
    private javax.swing.JLabel dataAnamnesa;
    private javax.swing.JLabel dataAnamnesa1;
    private javax.swing.JLabel dataBeratbadan;
    private javax.swing.JLabel dataBeratbadan1;
    private javax.swing.JLabel dataCatatanLab;
    private javax.swing.JLabel dataCatatanLab1;
    private javax.swing.JLabel dataCatatanresep;
    private javax.swing.JLabel dataCatatanresep1;
    private javax.swing.JLabel dataDiastole;
    private javax.swing.JLabel dataDiastole1;
    private javax.swing.JLabel dataEksekusiResep;
    private javax.swing.JLabel dataEksekusiResep1;
    private javax.swing.JLabel dataExpertiseLab;
    private javax.swing.JLabel dataExpertiseLab1;
    private javax.swing.JLabel dataFaktorResiko;
    private javax.swing.JLabel dataGolongandarah;
    private javax.swing.JLabel dataICD1;
    private javax.swing.JLabel dataICD10;
    private javax.swing.JLabel dataICD11;
    private javax.swing.JLabel dataICD12;
    private javax.swing.JLabel dataICD13;
    private javax.swing.JLabel dataICD14;
    private javax.swing.JLabel dataICD15;
    private javax.swing.JLabel dataICD16;
    private javax.swing.JLabel dataICD17;
    private javax.swing.JLabel dataICD18;
    private javax.swing.JLabel dataICD19;
    private javax.swing.JLabel dataICD2;
    private javax.swing.JLabel dataICD20;
    private javax.swing.JLabel dataICD3;
    private javax.swing.JLabel dataICD4;
    private javax.swing.JLabel dataICD5;
    private javax.swing.JLabel dataICD6;
    private javax.swing.JLabel dataICD7;
    private javax.swing.JLabel dataICD8;
    private javax.swing.JLabel dataICD9;
    private javax.swing.JLabel dataICDDiagnosa1;
    private javax.swing.JLabel dataICDDiagnosa10;
    private javax.swing.JLabel dataICDDiagnosa11;
    private javax.swing.JLabel dataICDDiagnosa12;
    private javax.swing.JLabel dataICDDiagnosa13;
    private javax.swing.JLabel dataICDDiagnosa14;
    private javax.swing.JLabel dataICDDiagnosa15;
    private javax.swing.JLabel dataICDDiagnosa16;
    private javax.swing.JLabel dataICDDiagnosa17;
    private javax.swing.JLabel dataICDDiagnosa18;
    private javax.swing.JLabel dataICDDiagnosa19;
    private javax.swing.JLabel dataICDDiagnosa2;
    private javax.swing.JLabel dataICDDiagnosa20;
    private javax.swing.JLabel dataICDDiagnosa3;
    private javax.swing.JLabel dataICDDiagnosa4;
    private javax.swing.JLabel dataICDDiagnosa5;
    private javax.swing.JLabel dataICDDiagnosa6;
    private javax.swing.JLabel dataICDDiagnosa7;
    private javax.swing.JLabel dataICDDiagnosa8;
    private javax.swing.JLabel dataICDDiagnosa9;
    private javax.swing.JLabel dataIDPuskesmas;
    private javax.swing.JLabel dataIDPuskesmas1;
    private javax.swing.JLabel dataKeluhanutama;
    private javax.swing.JLabel dataKeluhanutama1;
    private javax.swing.JLabel dataKesadaran;
    private javax.swing.JLabel dataKesadaran1;
    private javax.swing.JLabel dataLabExecuteFlag;
    private javax.swing.JLabel dataLabExecuteFlag1;
    private javax.swing.JLabel dataLain;
    private javax.swing.JLabel dataLain1;
    private javax.swing.JLabel dataNadi;
    private javax.swing.JLabel dataNadi1;
    private javax.swing.JLabel dataPemeriksaanFisik;
    private javax.swing.JLabel dataPemeriksaanFisik1;
    private javax.swing.JLabel dataPenyakitBawaan;
    private javax.swing.JLabel dataPenyakitDahulu;
    private javax.swing.JLabel dataPenyakitDahulu1;
    private javax.swing.JLabel dataPenyakitKeluarga;
    private javax.swing.JLabel dataPenyakitKeluarga1;
    private javax.swing.JLabel dataPenyakitKronis;
    private javax.swing.JLabel dataPoliTujuan;
    private javax.swing.JLabel dataPoliTujuan1;
    private javax.swing.JLabel dataPrognosa;
    private javax.swing.JLabel dataPrognosa1;
    private javax.swing.JLabel dataRawatRS;
    private javax.swing.JLabel dataRepetisiresep;
    private javax.swing.JLabel dataRepetisiresep1;
    private javax.swing.JLabel dataResep;
    private javax.swing.JLabel dataResep1;
    private javax.swing.JLabel dataRespirasi;
    private javax.swing.JLabel dataRespirasi1;
    private javax.swing.JLabel dataRiwayatOperasi;
    private javax.swing.JLabel dataRujukan;
    private javax.swing.JLabel dataRujukan1;
    private javax.swing.JLabel dataStack;
    private javax.swing.JLabel dataStack1;
    private javax.swing.JLabel dataSuhu;
    private javax.swing.JLabel dataSuhu1;
    private javax.swing.JLabel dataSystole;
    private javax.swing.JLabel dataSystole1;
    private javax.swing.JLabel dataTanggalPeriksa;
    private javax.swing.JLabel dataTanggalPeriksa1;
    private javax.swing.JLabel dataTerapi;
    private javax.swing.JLabel dataTerapi1;
    private javax.swing.JLabel dataTinggi;
    private javax.swing.JLabel dataTinggi1;
    private javax.swing.JButton deleteAlergi;
    private javax.swing.JButton deleteAllDINAMIS;
    private javax.swing.JButton deleteAllSTATIS;
    private javax.swing.JButton deleteAnamnesa;
    private javax.swing.JButton deleteBeratbadan;
    private javax.swing.JButton deleteCatatanLab;
    private javax.swing.JButton deleteCatatanresep;
    private javax.swing.JButton deleteDiastole;
    private javax.swing.JButton deleteEksekusiResep;
    private javax.swing.JButton deleteExpertiseLab;
    private javax.swing.JButton deleteFaktorResiko;
    private javax.swing.JButton deleteGolongandarah;
    private javax.swing.JButton deleteICD1;
    private javax.swing.JButton deleteICD10;
    private javax.swing.JButton deleteICD2;
    private javax.swing.JButton deleteICD3;
    private javax.swing.JButton deleteICD4;
    private javax.swing.JButton deleteICD5;
    private javax.swing.JButton deleteICD6;
    private javax.swing.JButton deleteICD7;
    private javax.swing.JButton deleteICD8;
    private javax.swing.JButton deleteICD9;
    private javax.swing.JButton deleteICDDiagnosa1;
    private javax.swing.JButton deleteICDDiagnosa10;
    private javax.swing.JButton deleteICDDiagnosa2;
    private javax.swing.JButton deleteICDDiagnosa3;
    private javax.swing.JButton deleteICDDiagnosa4;
    private javax.swing.JButton deleteICDDiagnosa5;
    private javax.swing.JButton deleteICDDiagnosa6;
    private javax.swing.JButton deleteICDDiagnosa7;
    private javax.swing.JButton deleteICDDiagnosa8;
    private javax.swing.JButton deleteICDDiagnosa9;
    private javax.swing.JButton deleteIDPuskesmas;
    private javax.swing.JButton deleteKeluhanutama;
    private javax.swing.JButton deleteKesadaran;
    private javax.swing.JButton deleteLabExecuteFlag;
    private javax.swing.JButton deleteLain;
    private javax.swing.JButton deleteNadi;
    private javax.swing.JButton deletePemeriksaanFisik;
    private javax.swing.JButton deletePenyakitBawaan;
    private javax.swing.JButton deletePenyakitDahulu;
    private javax.swing.JButton deletePenyakitKeluarga;
    private javax.swing.JButton deletePenyakitKronis;
    private javax.swing.JButton deletePoliTujuan;
    private javax.swing.JButton deletePrognosa;
    private javax.swing.JButton deleteRawatRS;
    private javax.swing.JButton deleteRepetisiresep;
    private javax.swing.JButton deleteResep;
    private javax.swing.JButton deleteRespirasi;
    private javax.swing.JButton deleteRiwayatOperasi;
    private javax.swing.JButton deleteRujukan;
    private javax.swing.JButton deleteSuhu;
    private javax.swing.JButton deleteSystole;
    private javax.swing.JButton deleteTanggalPeriksa;
    private javax.swing.JButton deleteTerapi;
    private javax.swing.JButton deleteTinggi;
    private javax.swing.JTextField fieldAlergi;
    private javax.swing.JTextField fieldAnamnesa;
    private javax.swing.JTextField fieldBeratbadan;
    private javax.swing.JTextField fieldCatatanLab;
    private javax.swing.JTextField fieldCatatanresep;
    private javax.swing.JLabel fieldCurrentStack;
    private javax.swing.JTextField fieldDiastole;
    private javax.swing.JTextField fieldExpertiseLab;
    private javax.swing.JTextField fieldFaktorResiko;
    private javax.swing.JTextField fieldICD1;
    private javax.swing.JTextField fieldICD10;
    private javax.swing.JTextField fieldICD2;
    private javax.swing.JTextField fieldICD3;
    private javax.swing.JTextField fieldICD4;
    private javax.swing.JTextField fieldICD5;
    private javax.swing.JTextField fieldICD6;
    private javax.swing.JTextField fieldICD7;
    private javax.swing.JTextField fieldICD8;
    private javax.swing.JTextField fieldICD9;
    private javax.swing.JTextField fieldICDDiagnosa1;
    private javax.swing.JTextField fieldICDDiagnosa10;
    private javax.swing.JTextField fieldICDDiagnosa2;
    private javax.swing.JTextField fieldICDDiagnosa3;
    private javax.swing.JTextField fieldICDDiagnosa4;
    private javax.swing.JTextField fieldICDDiagnosa5;
    private javax.swing.JTextField fieldICDDiagnosa6;
    private javax.swing.JTextField fieldICDDiagnosa7;
    private javax.swing.JTextField fieldICDDiagnosa8;
    private javax.swing.JTextField fieldICDDiagnosa9;
    private javax.swing.JTextField fieldIDPuskesmas;
    private javax.swing.JTextField fieldKeluhanutama;
    private javax.swing.JTextField fieldLain;
    private javax.swing.JTextField fieldNadi;
    private javax.swing.JTextField fieldPemeriksaanFisik;
    private javax.swing.JTextField fieldPenyakitBawaan;
    private javax.swing.JTextField fieldPenyakitDahulu;
    private javax.swing.JTextField fieldPenyakitKeluarga;
    private javax.swing.JTextField fieldPenyakitKronis;
    private javax.swing.JTextField fieldPoliTujuan;
    private javax.swing.JTextField fieldRawatRS;
    private javax.swing.JTextField fieldResep;
    private javax.swing.JTextField fieldRespirasi;
    private javax.swing.JTextField fieldRiwayatOperasi;
    private javax.swing.JTextField fieldRujukan;
    private javax.swing.JTextField fieldSuhu;
    private javax.swing.JTextField fieldSystole;
    private javax.swing.JTextField fieldTanggalPeriksa;
    private javax.swing.JTextField fieldTerapi;
    private javax.swing.JTextField fieldTinggi;
    private javax.swing.ButtonGroup gender;
    private javax.swing.JButton getAllDinamis_View;
    private javax.swing.JButton getAllDinamis_current;
    private javax.swing.JButton getAllSTATIS;
    private javax.swing.JButton inputAlergi;
    private javax.swing.JButton inputAllSTATIS;
    private javax.swing.JButton inputAnamnesa;
    private javax.swing.JButton inputBeratbadan;
    private javax.swing.JButton inputCatatanLab;
    private javax.swing.JButton inputCatatanresep;
    private javax.swing.JButton inputDiastole;
    private javax.swing.JButton inputEksekusiResep;
    private javax.swing.JButton inputExpertiseLab;
    private javax.swing.JButton inputFaktorResiko;
    private javax.swing.JButton inputGolongandarah;
    private javax.swing.JButton inputICD1;
    private javax.swing.JButton inputICD10;
    private javax.swing.JButton inputICD2;
    private javax.swing.JButton inputICD3;
    private javax.swing.JButton inputICD4;
    private javax.swing.JButton inputICD5;
    private javax.swing.JButton inputICD6;
    private javax.swing.JButton inputICD7;
    private javax.swing.JButton inputICD8;
    private javax.swing.JButton inputICD9;
    private javax.swing.JButton inputICDDiagnosa1;
    private javax.swing.JButton inputICDDiagnosa10;
    private javax.swing.JButton inputICDDiagnosa2;
    private javax.swing.JButton inputICDDiagnosa3;
    private javax.swing.JButton inputICDDiagnosa4;
    private javax.swing.JButton inputICDDiagnosa5;
    private javax.swing.JButton inputICDDiagnosa6;
    private javax.swing.JButton inputICDDiagnosa7;
    private javax.swing.JButton inputICDDiagnosa8;
    private javax.swing.JButton inputICDDiagnosa9;
    private javax.swing.JButton inputIDPuskesmas;
    private javax.swing.JButton inputKeluhanutama;
    private javax.swing.JButton inputKesadaran;
    private javax.swing.JButton inputLabExecuteFlag;
    private javax.swing.JButton inputLain;
    private javax.swing.JButton inputNadi;
    private javax.swing.JButton inputPemeriksaanFisik;
    private javax.swing.JButton inputPenyakitBawaan;
    private javax.swing.JButton inputPenyakitDahulu;
    private javax.swing.JButton inputPenyakitKeluarga;
    private javax.swing.JButton inputPenyakitKronis;
    private javax.swing.JButton inputPoliTujuan;
    private javax.swing.JButton inputPrognosa;
    private javax.swing.JButton inputRawatRS;
    private javax.swing.JButton inputRepetisiresep;
    private javax.swing.JButton inputResep;
    private javax.swing.JButton inputRespirasi;
    private javax.swing.JButton inputRiwayatOperasi;
    private javax.swing.JButton inputRujukan;
    private javax.swing.JButton inputSuhu;
    private javax.swing.JButton inputSystole;
    private javax.swing.JButton inputTanggalPeriksa;
    private javax.swing.JButton inputTerapi;
    private javax.swing.JButton inputTinggi;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane_DINAMIS;
    private javax.swing.JScrollPane jScrollPane_STATIS;
    private javax.swing.JScrollPane jScrollPane_ViewDinamis;
    private javax.swing.JTabbedPane jTabbedAll;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel labelAnamnesa;
    private javax.swing.JLabel labelAnamnesa1;
    private javax.swing.JLabel labelBeratbadan;
    private javax.swing.JLabel labelBeratbadan1;
    private javax.swing.JLabel labelCatatanLab;
    private javax.swing.JLabel labelCatatanLab1;
    private javax.swing.JLabel labelCatatanresep;
    private javax.swing.JLabel labelCatatanresep1;
    private javax.swing.JLabel labelCurrentStack;
    private javax.swing.JLabel labelDiastole;
    private javax.swing.JLabel labelDiastole1;
    private javax.swing.JLabel labelEksekusiResep;
    private javax.swing.JLabel labelEksekusiResep1;
    private javax.swing.JLabel labelExpertiseLab;
    private javax.swing.JLabel labelExpertiseLab1;
    private javax.swing.JLabel labelICD1;
    private javax.swing.JLabel labelICD10;
    private javax.swing.JLabel labelICD11;
    private javax.swing.JLabel labelICD12;
    private javax.swing.JLabel labelICD13;
    private javax.swing.JLabel labelICD14;
    private javax.swing.JLabel labelICD15;
    private javax.swing.JLabel labelICD16;
    private javax.swing.JLabel labelICD17;
    private javax.swing.JLabel labelICD18;
    private javax.swing.JLabel labelICD19;
    private javax.swing.JLabel labelICD2;
    private javax.swing.JLabel labelICD20;
    private javax.swing.JLabel labelICD3;
    private javax.swing.JLabel labelICD4;
    private javax.swing.JLabel labelICD5;
    private javax.swing.JLabel labelICD6;
    private javax.swing.JLabel labelICD7;
    private javax.swing.JLabel labelICD8;
    private javax.swing.JLabel labelICD9;
    private javax.swing.JLabel labelICDDiagnosa1;
    private javax.swing.JLabel labelICDDiagnosa10;
    private javax.swing.JLabel labelICDDiagnosa11;
    private javax.swing.JLabel labelICDDiagnosa12;
    private javax.swing.JLabel labelICDDiagnosa13;
    private javax.swing.JLabel labelICDDiagnosa14;
    private javax.swing.JLabel labelICDDiagnosa15;
    private javax.swing.JLabel labelICDDiagnosa16;
    private javax.swing.JLabel labelICDDiagnosa17;
    private javax.swing.JLabel labelICDDiagnosa18;
    private javax.swing.JLabel labelICDDiagnosa19;
    private javax.swing.JLabel labelICDDiagnosa2;
    private javax.swing.JLabel labelICDDiagnosa20;
    private javax.swing.JLabel labelICDDiagnosa3;
    private javax.swing.JLabel labelICDDiagnosa4;
    private javax.swing.JLabel labelICDDiagnosa5;
    private javax.swing.JLabel labelICDDiagnosa6;
    private javax.swing.JLabel labelICDDiagnosa7;
    private javax.swing.JLabel labelICDDiagnosa8;
    private javax.swing.JLabel labelICDDiagnosa9;
    private javax.swing.JLabel labelIDPuskesmas;
    private javax.swing.JLabel labelIDPuskesmas1;
    private javax.swing.JLabel labelKeluhanutama;
    private javax.swing.JLabel labelKeluhanutama1;
    private javax.swing.JLabel labelKesadaran;
    private javax.swing.JLabel labelKesadaran1;
    private javax.swing.JLabel labelLabExecuteFlag;
    private javax.swing.JLabel labelLabExecuteFlag1;
    private javax.swing.JLabel labelLain;
    private javax.swing.JLabel labelLain1;
    private javax.swing.JLabel labelNadi;
    private javax.swing.JLabel labelNadi1;
    private javax.swing.JLabel labelPemeriksaanFisik;
    private javax.swing.JLabel labelPemeriksaanFisik1;
    private javax.swing.JLabel labelPenyakitDahulu;
    private javax.swing.JLabel labelPenyakitDahulu1;
    private javax.swing.JLabel labelPenyakitKeluarga;
    private javax.swing.JLabel labelPenyakitKeluarga1;
    private javax.swing.JLabel labelPoliTujuan;
    private javax.swing.JLabel labelPoliTujuan1;
    private javax.swing.JLabel labelPrognosa;
    private javax.swing.JLabel labelPrognosa1;
    private javax.swing.JLabel labelRepetisiresep;
    private javax.swing.JLabel labelRepetisiresep1;
    private javax.swing.JLabel labelResep;
    private javax.swing.JLabel labelResep1;
    private javax.swing.JLabel labelRespirasi;
    private javax.swing.JLabel labelRespirasi1;
    private javax.swing.JLabel labelRujukan;
    private javax.swing.JLabel labelRujukan1;
    private javax.swing.JLabel labelStack;
    private javax.swing.JLabel labelStack1;
    private javax.swing.JLabel labelSuhu;
    private javax.swing.JLabel labelSuhu1;
    private javax.swing.JLabel labelSystole;
    private javax.swing.JLabel labelSystole1;
    private javax.swing.JLabel labelTanggalPeriksa;
    private javax.swing.JLabel labelTanggalPeriksa1;
    private javax.swing.JLabel labelTerapi;
    private javax.swing.JLabel labelTerapi1;
    private javax.swing.JLabel labelTinggi;
    private javax.swing.JLabel labelTinggi1;
    private javax.swing.JPanel panelAllCRUD_STATIS;
    private javax.swing.JPanel panelAllCRUD_STATIS2;
    private javax.swing.JPanel panelItemDATA1;
    private javax.swing.JPanel panelItemSTATIS;
    private javax.swing.JPanel panelMenuViewDinamis;
    private javax.swing.JPanel panelOperationTitle;
    private javax.swing.JPanel panelViewDinamis;
    private javax.swing.JButton registerlDINAMIS;
    private javax.swing.JLabel status_Label_AdminForm;
    private javax.swing.JButton updateAllDINAMIS;
    // End of variables declaration//GEN-END:variables
}
