/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Controller.ControllerLogin;
import Database.Applet;

import Model.Main;
//
//
//import Database.koneksi;

import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.Int;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.ByteBuffer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import javax.smartcardio.CardException;
import javax.smartcardio.CardTerminal;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.util.List;
import javax.smartcardio.CardException;
import javax.smartcardio.CardTerminal;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
/**
 *
 * @author ILM
 */
public class AdminDataDiriForm extends javax.swing.JFrame {
//--INDEKS DATA
    //DATA DIRI
    String indeksNoSC = "0000";
    String indeksKategoriPasien = "0001";
    String indeksNoAsuransi = "0002";
    String indeksTanggalDaftar = "0003";
    String indeksNamaPasien = "0004";
    String indeksNamaKK = "0005";
    String indeksHubKeluarga = "0006";
    String indeksAlamat = "0007";
    String indeksRT = "0008";
    String indeksRW = "0009";
    String indeksKelurahanPasien = "000A";
    String indeksKecamatanPasien = "000B";
    String indeksKotaPasien = "000C";
    String indeksPropinsiPasien = "000D";
    String indeksKodePos = "000E";
    String indeksWilayahKerja = "000F";
    String indeksTempatLahir = "0010";
    String indeksTanggalLahir = "0011";
    String indeksTeleponPasien = "0012";
    String indeksHPPasien = "0013";
    String indeksKTPPasien = "0014";
    String indeksJenisKelaminPasien = "0015";
    String indeksAgamaPasien = "0016";
    String indeksPendidikanPasien = "0017";
    String indeksPekerjaanPasien = "0018";
    String indeksKelasPerawatan = "0019";
    String indeksEmailPasien = "001A";
    String indeksStatusPerkawinanPasien = "001B";
    String indeksKewarganegaraanPasien = "001C";
    String indeksNamaKeluarga = "001D";
    String indeksHubungan = "001E";
    String indeksAlamatKeluarga = "001F";
    String indeksKelurahanKeluarga = "0020";
    String indeksKecamatanKeluarga = "0021";
    String indeksKotaKeluarga = "0022";
    String indeksPropinsiKeluarga = "0023";
    String indeksKodePosKeluarga = "0024";
    String indeksTeleponKeluarga = "0025";
    String indeksHPKeluarga = "0026";
    String indeksNamaKantor = "0027";
    String indeksAlamatKantor = "0028";
    String indeksKotaKantor = "0029";
    String indeksTeleponKantor1 = "002A";
    String indeksHPKantor1 = "002B";
    String indeksTeleponKantor2 = "002C";
    String indeksHPKantor2 = "002D";

    //STATIS
    String indeksAlergi = "0100";
    String indeksGolongandarah = "0101";
    String indeksRiwayatOperasi = "0102";
    String indeksRawatRS = "0103";
    String indeksPenyakitKronis = "0104";
    String indeksPenyakitBawaan = "0105";
    String indeksFaktorResiko = "0106";

    //DINAMIS
    String indeksStack = "0200";
    String indeksTanggalPeriksa = "0201";
    String indeksKeluhanutama = "0202";
    String indeksAnamnesa = "0203";
    String indeksPenyakitDahulu = "0204";
    String indeksPenyakitKeluarga = "0205";
    String indeksPemeriksaanFisik = "0206";
    String indeksTinggi = "0207";
    String indeksBeratbadan = "0208";
    String indeksSystole = "0209";
    String indeksDiastole = "020A";
    String indeksNadi = "020B";
    String indeksKesadaran = "020C";
    String indeksSuhu = "020D";
    String indeksRespirasi = "020E";
    String indeksLain = "020F";
    String indeksLabExecuteFlag = "0210";
    String indeksExpertiseLab = "0211";
    String indeksCatatanLab = "0212";
    String indeksTerapi = "0213";
    String indeksResep = "0214";
    String indeksCatatanresep = "0215";
    String indeksEksekusiResep = "0216";
    String indeksRepetisiresep = "0217";
    String indeksPrognosa = "0218";
    String indeksICD1 = "0219";
    String indeksICD2 = "021A";
    String indeksICD3 = "021B";
    String indeksICD4 = "021C";
    String indeksICD5 = "021D";
    String indeksICD6 = "021E";
    String indeksICD7 = "021F";
    String indeksICD8 = "0220";
    String indeksICD9 = "0221";
    String indeksICD10 = "0222";
    String indeksICDDiagnosa1 = "0223";
    String indeksICDDiagnosa2 = "0224";
    String indeksICDDiagnosa3 = "0225";
    String indeksICDDiagnosa4 = "0226";
    String indeksICDDiagnosa5 = "0227";
    String indeksICDDiagnosa6 = "0228";
    String indeksICDDiagnosa7 = "0229";
    String indeksICDDiagnosa8 = "022A";
    String indeksICDDiagnosa9 = "022B";
    String indeksICDDiagnosa10 = "022C";
    String indeksPoliTujuan = "022D";
    String indeksRujukan = "022E";
    String indeksIDPuskesmas = "022F";
//--END OF INDEKS

//--DATA
    //DATA DIRI
    // NoSC
    String data_StringNoSC;
    // KategoriPasien
    String data_StringKategoriPasien;
    // NoAsuransi
    String data_StringNoAsuransi;
    // TanggalDaftar
    String data_StringTanggalDaftar;
    // NamaPasien
    String data_StringNamaPasien;
    // NamaKK
    String data_StringNamaKK;
    // HubKeluarga
    String data_StringHubKeluarga;
    // Alamat
    String data_StringAlamat;
    // RT
    String data_StringRT;
    // RW
    String data_StringRW;
    // KelurahanPasien
    String data_StringKelurahanPasien;
    // KecamatanPasien
    String data_StringKecamatanPasien;
    // KotaPasien
    String data_StringKotaPasien;
    // PropinsiPasien
    String data_StringPropinsiPasien;
    // Kodepos
    String data_StringKodepos;
    // WilayahKerja
    String data_StringWilayahKerja;
    // TempatLahir
    String data_StringTempatLahir;
    // TanggalLahir
    String data_StringTanggalLahir;
    // TeleponPasien
    String data_StringTeleponPasien;
    // HPPasien
    String data_StringHPPasien;
    // KTPPasien
    String data_StringKTPPasien;
    // JenisKelaminPasien
    String data_StringJenisKelaminPasien;
    // AgamaPasien
    String data_StringAgamaPasien;
    // PendidikanPasien
    String data_StringPendidikanPasien;
    // PekerjaanPasien
    String data_StringPekerjaanPasien;
    // KelasPerawatan
    String data_StringKelasPerawatan;
    // EmailPasien
    String data_StringEmailPasien;
    // StatusPerkawinanPasien
    String data_StringStatusPerkawinanPasien;
    // KewarganegaraanPasien
    String data_StringKewarganegaraanPasien;
    // NamaKeluarga
    String data_StringNamaKeluarga;
    // Hubungan
    String data_StringHubungan;
    // AlamatKeluarga
    String data_StringAlamatKeluarga;
    // KelurahanKeluarga
    String data_StringKelurahanKeluarga;
    // KecamatanKeluarga
    String data_StringKecamatanKeluarga;
    // KotaKeluarga
    String data_StringKotaKeluarga;
    // PropinsiKeluarga
    String data_StringPropinsiKeluarga;
    // KodePosKeluarga
    String data_StringKodePosKeluarga;
    // TeleponKeluarga
    String data_StringTeleponKeluarga;
    // HPKeluarga
    String data_StringHPKeluarga;
    // NamaKantor
    String data_StringNamaKantor;
    // AlamatKantor
    String data_StringAlamatKantor;
    // KotaKantor
    String data_StringKotaKantor;
    // TeleponKantor1
    String data_StringTeleponKantor1;
    // HPKantor1
    String data_StringHPKantor1;
    // TeleponKantor2
    String data_StringTeleponKantor2;
    // HPKantor2
    String data_StringHPKantor2;

    //STATIS
    // Alergi
    String data_StringAlergi;
    // Golongandarah
    String data_StringGolongandarah;
    // RiwayatOperasi
    String data_StringRiwayatOperasi;
    // RawatRS
    String data_StringRawatRS;
    // PenyakitKronis
    String data_StringPenyakitKronis;
    // PenyakitBawaan
    String data_StringPenyakitBawaan;
    // FaktorResiko
    String data_StringFaktorResiko;

    //DINAMIS
    // Stack
    String data_StringStack;
    // TanggalPeriksa
    String data_StringTanggalPeriksa;
    // Keluhanutama
    String data_StringKeluhanutama;
    // Anamnesa
    String data_StringAnamnesa;
    // PenyakitDahulu
    String data_StringPenyakitDahulu;
    // PenyakitKeluarga
    String data_StringPenyakitKeluarga;
    // PemeriksaanFisik
    String data_StringPemeriksaanFisik;
    // Tinggi
    String data_StringTinggi;
    // Beratbadan
    String data_StringBeratbadan;
    // Systole
    String data_StringSystole;
    // Diastole
    String data_StringDiastole;
    // Nadi
    String data_StringNadi;
    // Kesadaran
    String data_StringKesadaran;
    // Suhu
    String data_StringSuhu;
    // Respirasi
    String data_StringRespirasi;
    // Lain-lain
    String data_StringLain;
    // LabExecuteFlag
    String data_StringLabExecuteFlag;
    // ExpertiseLab
    String data_StringExpertiseLab;
    // CatatanLab
    String data_StringCatatanLab;
    // Terapi
    String data_StringTerapi;
    // Resep
    String data_StringResep;
    // Catatanresep
    String data_StringCatatanresep;
    // EksekusiResep
    String data_StringEksekusiResep;
    // Repetisiresep
    String data_StringRepetisiresep;
    // Prognosa
    String data_StringPrognosa;
    // ICD1
    String data_StringICD1;
    // ICD2
    String data_StringICD2;
    // ICD3
    String data_StringICD3;
    // ICD4
    String data_StringICD4;
    // ICD5
    String data_StringICD5;
    // ICD6
    String data_StringICD6;
    // ICD7
    String data_StringICD7;
    // ICD8
    String data_StringICD8;
    // ICD9
    String data_StringICD9;
    // ICD10
    String data_StringICD10;
    // ICD1Diagnosa
    String data_StringICDDiagnosa1;
    // ICD2Diagnosa
    String data_StringICDDiagnosa2;
    // ICD3Diagnosa
    String data_StringICDDiagnosa3;
    // ICD4Diagnosa
    String data_StringICDDiagnosa4;
    // ICD5Diagnosa
    String data_StringICDDiagnosa5;
    // ICD6Diagnosa
    String data_StringICDDiagnosa6;
    // ICD7Diagnosa
    String data_StringICDDiagnosa7;
    // ICD8Diagnosa
    String data_StringICDDiagnosa8;
    // ICD9Diagnosa
    String data_StringICDDiagnosa9;
    // ICD10Diagnosa
    String data_StringICDDiagnosa10;
    // PoliTujuan
    String data_StringPoliTujuan;
    // Rujukan
    String data_StringRujukan;
    // IDPuskesmas
    String data_StringIDPuskesmas;

//--END OF DATA

//--SYMBOL
    //DATA DIRI
    // HubKeluarga
    String[] symbolHubKeluarga = new String[7];
    // RT
    String[] symbolRT = new String[30];
    // RW
    String[] symbolRW = new String[30];
    // KelurahanPasien
    String[] symbolKelurahanPasien = new String[30];
    // KecamatanPasien
    String[] symbolKecamatanPasien = new String[30];
    // KotaPasien
    String[] symbolKotaPasien = new String[30];
    // PropinsiPasien
    String[] symbolPropinsiPasien = new String[34];
    // WilayahKerja
    String[] symbolWilayahKerja = new String[2];
    // JenisKelaminPasien
    String[] symbolJenisKelaminPasien = new String[2];
    // AgamaPasien
    String[] symbolAgamaPasien = new String[6];
    // PendidikanPasien
    String[] symbolPendidikanPasien = new String[7];
    // PekerjaanPasien
    String[] symbolPekerjaanPasien = new String[13];
    // StatusPerkawinanPasien
    String[] symbolStatusPerkawinanPasien = new String[3];
    // KewarganegaraanPasien
    String[] symbolKewarganegaraanPasien = new String[2];
    // Hubungan
    String[] symbolHubungan = new String[7];
    // KelurahanKeluarga
    String[] symbolKelurahanKeluarga = new String[30];
    // KecamatanKeluarga
    String[] symbolKecamatanKeluarga = new String[30];
    // KotaKeluarga
    String[] symbolKotaKeluarga = new String[30];
    // PropinsiKeluarga
    String[] symbolPropinsiKeluarga = new String[34];
    // KotaKantor
    String[] symbolKotaKantor = new String[30];

    //STATIS
    // Golongandarah
    String[] symbolGolongandarah = new String[8];

    //DINAMIS
    // Kesadaran
    String[] symbolKesadaran = new String[6];
    // LabExecuteFlag
    String[] symbolLabExecuteFlag = new String[3];
    // EksekusiResep
    String[] symbolEksekusiResep = new String[5];
    // Repetisiresep
    String[] symbolRepetisiresep = new String[5];
    // Prognosa
    String[] symbolPrognosa = new String[8];
//--END OF SYMBOL        

    private Main model;
    JavaSmartcard javaCard ;
    Applet applet;
    ControllerLogin login;
     
    String appletID;
    String CLAText = "80";
    String CLANum ="90";
    String status = "";
    
    boolean isConnected;
     
    boolean symEx;
    String[] symbol;
    
    boolean floatData;
    
    final static int NUM = 0;
    final static int TEXT = 1;
    
    public AdminDataDiriForm() {
        initComponents();
        
        //setLabel();
        InisiasiData();
        javaCard = new JavaSmartcard();
        applet = new Applet();
        appletID = applet.getAppletID();
        
        
        System.out.println("Admin-Dinamis ID:"+appletID);
        //System.out.println("Admin-Dinamis con:"+isConnected); 
        this.getContentPane().setBackground(Color.white);
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        gender = new javax.swing.ButtonGroup();
        panelOperationTitle = new javax.swing.JPanel();
        btnLogOut = new javax.swing.JButton();
        btnVerifikasiPin = new javax.swing.JButton();
        btnLogout = new javax.swing.JButton();
        btnHome1 = new javax.swing.JButton();
        administrator1 = new javax.swing.JLabel();
        administrator2 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        PanelReaderCard = new javax.swing.JPanel();
        status_Label_AdminForm = new javax.swing.JLabel();
        jTabbedAll = new javax.swing.JTabbedPane();
        DataDiri = new javax.swing.JPanel();
        jScrollPane_DATA = new javax.swing.JScrollPane();
        panelItemDATA = new javax.swing.JPanel();
        labelNoSC = new javax.swing.JLabel();
        dataNoSc = new javax.swing.JLabel();
        fieldNoSC = new javax.swing.JTextField();
        inputNoSC = new javax.swing.JButton();
        deleteNoSC = new javax.swing.JButton();
        labelKategoriPasien = new javax.swing.JLabel();
        dataKategoriPasien = new javax.swing.JLabel();
        fieldKategoriPasien = new javax.swing.JTextField();
        inputKategoriPasien = new javax.swing.JButton();
        deleteKategoriPasien = new javax.swing.JButton();
        labelNoAsuransi = new javax.swing.JLabel();
        dataNoAsuransi = new javax.swing.JLabel();
        fieldNoAsuransi = new javax.swing.JTextField();
        inputNoAsuransi = new javax.swing.JButton();
        deleteNoAsuransi = new javax.swing.JButton();
        labelTanggalDaftar = new javax.swing.JLabel();
        dataTanggalDaftar = new javax.swing.JLabel();
        fieldTanggalDaftar = new javax.swing.JTextField();
        inputTanggalDaftar = new javax.swing.JButton();
        deleteTanggalDaftar = new javax.swing.JButton();
        labelNamaPasien = new javax.swing.JLabel();
        dataNamaPasien = new javax.swing.JLabel();
        fieldNamaPasien = new javax.swing.JTextField();
        inputNamaPasien = new javax.swing.JButton();
        deleteNamaPasien = new javax.swing.JButton();
        labelNamaKK = new javax.swing.JLabel();
        dataNamaKK = new javax.swing.JLabel();
        fieldNamaKK = new javax.swing.JTextField();
        inputNamaKK = new javax.swing.JButton();
        deleteNamaKK = new javax.swing.JButton();
        labelHubKeluarga = new javax.swing.JLabel();
        dataHubKeluarga = new javax.swing.JLabel();
        ComboBox_HubKeluarga = new javax.swing.JComboBox<>();
        inputHubKeluarga = new javax.swing.JButton();
        deleteHubKeluarga = new javax.swing.JButton();
        labelAlamat = new javax.swing.JLabel();
        dataAlamat = new javax.swing.JLabel();
        fieldAlamat = new javax.swing.JTextField();
        inputAlamat = new javax.swing.JButton();
        deleteAlamat = new javax.swing.JButton();
        labelRT = new javax.swing.JLabel();
        dataRT = new javax.swing.JLabel();
        inputRT = new javax.swing.JButton();
        deleteRT = new javax.swing.JButton();
        labelRW = new javax.swing.JLabel();
        dataRW = new javax.swing.JLabel();
        inputRW = new javax.swing.JButton();
        deleteRW = new javax.swing.JButton();
        labelKelurahanPasien = new javax.swing.JLabel();
        dataKelurahanPasien = new javax.swing.JLabel();
        inputKelurahanPasien = new javax.swing.JButton();
        deleteKelurahanPasien = new javax.swing.JButton();
        labelKecamatanPasien = new javax.swing.JLabel();
        dataKecamatanPasien = new javax.swing.JLabel();
        inputKecamatanPasien = new javax.swing.JButton();
        deleteKecamatanPasien = new javax.swing.JButton();
        labelKotaPasien = new javax.swing.JLabel();
        dataKotaPasien = new javax.swing.JLabel();
        inputKotaPasien = new javax.swing.JButton();
        deleteKotaPasien = new javax.swing.JButton();
        labelPropinsiPasien = new javax.swing.JLabel();
        dataPropinsiPasien = new javax.swing.JLabel();
        inputPropinsiPasien = new javax.swing.JButton();
        deletePropinsiPasien = new javax.swing.JButton();
        labelKodePos = new javax.swing.JLabel();
        dataKodePos = new javax.swing.JLabel();
        fieldKodePos = new javax.swing.JTextField();
        inputKodePos = new javax.swing.JButton();
        deleteKodePos = new javax.swing.JButton();
        labelWilayahKerja = new javax.swing.JLabel();
        dataWilayahKerja = new javax.swing.JLabel();
        inputWilayahKerja = new javax.swing.JButton();
        deleteWilayahKerja = new javax.swing.JButton();
        labelTempatLahir = new javax.swing.JLabel();
        dataTempatLahir = new javax.swing.JLabel();
        fieldTempatLahir = new javax.swing.JTextField();
        inputTempatLahir = new javax.swing.JButton();
        deleteTempatLahir = new javax.swing.JButton();
        labelTanggalLahir = new javax.swing.JLabel();
        dataTanggalLahir = new javax.swing.JLabel();
        fieldTanggalLahir = new javax.swing.JTextField();
        inputTanggalLahir = new javax.swing.JButton();
        deleteTanggalLahir = new javax.swing.JButton();
        labelTeleponPasien = new javax.swing.JLabel();
        dataTeleponPasien = new javax.swing.JLabel();
        fieldTeleponPasien = new javax.swing.JTextField();
        inputTeleponPasien = new javax.swing.JButton();
        deleteTeleponPasien = new javax.swing.JButton();
        labelHPPasien = new javax.swing.JLabel();
        dataHPPasien = new javax.swing.JLabel();
        fieldHPPasien = new javax.swing.JTextField();
        inputHPPasien = new javax.swing.JButton();
        deleteHPPasien = new javax.swing.JButton();
        labelKTPPasien = new javax.swing.JLabel();
        dataKTPPasien = new javax.swing.JLabel();
        fieldKTPPasien = new javax.swing.JTextField();
        inputKTPPasien = new javax.swing.JButton();
        deleteKTPPasien = new javax.swing.JButton();
        labelJenisKelaminPasien = new javax.swing.JLabel();
        dataJenisKelaminPasien = new javax.swing.JLabel();
        inputJenisKelaminPasien = new javax.swing.JButton();
        deleteJenisKelaminPasien = new javax.swing.JButton();
        labelAgamaPasien = new javax.swing.JLabel();
        dataAgamaPasien = new javax.swing.JLabel();
        inputAgamaPasien = new javax.swing.JButton();
        deleteAgamaPasien = new javax.swing.JButton();
        labelPendidikanPasien = new javax.swing.JLabel();
        dataPendidikanPasien = new javax.swing.JLabel();
        inputPendidikanPasien = new javax.swing.JButton();
        deletePendidikanPasien = new javax.swing.JButton();
        labelPekerjaanPasien = new javax.swing.JLabel();
        dataPekerjaanPasien = new javax.swing.JLabel();
        inputPekerjaanPasien = new javax.swing.JButton();
        deletePekerjaanPasien = new javax.swing.JButton();
        labelKelasPerawatan = new javax.swing.JLabel();
        dataKelasPerawatan = new javax.swing.JLabel();
        fieldKelasPerawatan = new javax.swing.JTextField();
        inputKelasPerawatan = new javax.swing.JButton();
        deleteKelasPerawatan = new javax.swing.JButton();
        labelEmailPasien = new javax.swing.JLabel();
        dataEmailPasien = new javax.swing.JLabel();
        fieldEmailPasien = new javax.swing.JTextField();
        inputEmailPasien = new javax.swing.JButton();
        deleteEmailPasien = new javax.swing.JButton();
        labelStatusPerkawinanPasien = new javax.swing.JLabel();
        dataStatusPerkawinanPasien = new javax.swing.JLabel();
        inputStatusPerkawinanPasien = new javax.swing.JButton();
        deleteStatusPerkawinanPasien = new javax.swing.JButton();
        labelKewarganegaraanPasien = new javax.swing.JLabel();
        dataKewarganegaraanPasien = new javax.swing.JLabel();
        inputKewarganegaraanPasien = new javax.swing.JButton();
        deleteKewarganegaraanPasien = new javax.swing.JButton();
        labelNamaKeluarga = new javax.swing.JLabel();
        dataNamaKeluarga = new javax.swing.JLabel();
        fieldNamaKeluarga = new javax.swing.JTextField();
        inputNamaKeluarga = new javax.swing.JButton();
        deleteNamaKeluarga = new javax.swing.JButton();
        labelHubungan = new javax.swing.JLabel();
        dataHubungan = new javax.swing.JLabel();
        inputHubungan = new javax.swing.JButton();
        deleteHubungan = new javax.swing.JButton();
        labelAlamatKeluarga = new javax.swing.JLabel();
        dataAlamatKeluarga = new javax.swing.JLabel();
        fieldAlamatKeluarga = new javax.swing.JTextField();
        inputAlamatKeluarga = new javax.swing.JButton();
        deleteAlamatKeluarga = new javax.swing.JButton();
        labelKelurahanKeluarga = new javax.swing.JLabel();
        dataKelurahanKeluarga = new javax.swing.JLabel();
        inputKelurahanKeluarga = new javax.swing.JButton();
        deleteKelurahanKeluarga = new javax.swing.JButton();
        labelKecamatanKeluarga = new javax.swing.JLabel();
        dataKecamatanKeluarga = new javax.swing.JLabel();
        inputKecamatanKeluarga = new javax.swing.JButton();
        deleteKecamatanKeluarga = new javax.swing.JButton();
        labelKotaKeluarga = new javax.swing.JLabel();
        dataKotaKeluarga = new javax.swing.JLabel();
        inputKotaKeluarga = new javax.swing.JButton();
        deleteKotaKeluarga = new javax.swing.JButton();
        labelPropinsiKeluarga = new javax.swing.JLabel();
        dataPropinsiKeluarga = new javax.swing.JLabel();
        inputPropinsiKeluarga = new javax.swing.JButton();
        deletePropinsiKeluarga = new javax.swing.JButton();
        labelKodePosKeluarga = new javax.swing.JLabel();
        dataKodePosKeluarga = new javax.swing.JLabel();
        fieldKodePosKeluarga = new javax.swing.JTextField();
        inputKodePosKeluarga = new javax.swing.JButton();
        deleteKodePosKeluarga = new javax.swing.JButton();
        labelTeleponKeluarga = new javax.swing.JLabel();
        dataTeleponKeluarga = new javax.swing.JLabel();
        fieldTeleponKeluarga = new javax.swing.JTextField();
        inputTeleponKeluarga = new javax.swing.JButton();
        deleteTeleponKeluarga = new javax.swing.JButton();
        labelHPKeluarga = new javax.swing.JLabel();
        dataHPKeluarga = new javax.swing.JLabel();
        fieldHPKeluarga = new javax.swing.JTextField();
        inputHPKeluarga = new javax.swing.JButton();
        deleteHPKeluarga = new javax.swing.JButton();
        labelNamaKantor = new javax.swing.JLabel();
        dataNamaKantor = new javax.swing.JLabel();
        fieldNamaKantor = new javax.swing.JTextField();
        inputNamaKantor = new javax.swing.JButton();
        deleteNamaKantor = new javax.swing.JButton();
        labelAlamatKantor = new javax.swing.JLabel();
        dataAlamatKantor = new javax.swing.JLabel();
        fieldAlamatKantor = new javax.swing.JTextField();
        inputAlamatKantor = new javax.swing.JButton();
        deleteAlamatKantor = new javax.swing.JButton();
        labelKotaKantor = new javax.swing.JLabel();
        dataKotaKantor = new javax.swing.JLabel();
        inputKotaKantor = new javax.swing.JButton();
        deleteKotaKantor = new javax.swing.JButton();
        labelTeleponKantor1 = new javax.swing.JLabel();
        dataTeleponKantor1 = new javax.swing.JLabel();
        fieldTeleponKantor1 = new javax.swing.JTextField();
        inputTeleponKantor1 = new javax.swing.JButton();
        deleteTeleponKantor1 = new javax.swing.JButton();
        labelHPKantor1 = new javax.swing.JLabel();
        dataHPKantor1 = new javax.swing.JLabel();
        fieldHPKantor1 = new javax.swing.JTextField();
        inputHPKantor1 = new javax.swing.JButton();
        deleteHPKantor1 = new javax.swing.JButton();
        ComboBox_RT = new javax.swing.JComboBox<>();
        ComboBox_RW = new javax.swing.JComboBox<>();
        ComboBox_KelurahanPasien = new javax.swing.JComboBox<>();
        ComboBox_KecamatanPasien = new javax.swing.JComboBox<>();
        ComboBox_KotaPasien = new javax.swing.JComboBox<>();
        ComboBox_PropinsiPasien = new javax.swing.JComboBox<>();
        ComboBox_WilayahKerja = new javax.swing.JComboBox<>();
        ComboBox_JenisKelaminPasien = new javax.swing.JComboBox<>();
        ComboBox_AgamaPasien = new javax.swing.JComboBox<>();
        ComboBox_PendidikanPasien = new javax.swing.JComboBox<>();
        ComboBox_PekerjaanPasien = new javax.swing.JComboBox<>();
        ComboBox_StatusPerkawinanPasien = new javax.swing.JComboBox<>();
        ComboBox_KewarganegaraanPasien = new javax.swing.JComboBox<>();
        ComboBox_Hubungan = new javax.swing.JComboBox<>();
        ComboBox_KelurahanKeluarga = new javax.swing.JComboBox<>();
        ComboBox_KecamatanKeluarga = new javax.swing.JComboBox<>();
        ComboBox_KotaKeluarga = new javax.swing.JComboBox<>();
        ComboBox_PropinsiKeluarga = new javax.swing.JComboBox<>();
        ComboBox_KotaKantor = new javax.swing.JComboBox<>();
        panelAllCRUD_DATA = new javax.swing.JPanel();
        getAllDATA = new javax.swing.JButton();
        deleteAllDATA = new javax.swing.JButton();
        inputAllSTATIS5 = new javax.swing.JButton();
        RekamMedisStatis = new javax.swing.JPanel();
        panelAllCRUD_STATIS = new javax.swing.JPanel();
        getAllSTATIS = new javax.swing.JButton();
        deleteAllSTATIS = new javax.swing.JButton();
        inputAllSTATIS = new javax.swing.JButton();
        jScrollPane_STATIS = new javax.swing.JScrollPane();
        panelItemSTATIS = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        dataFaktorResiko = new javax.swing.JLabel();
        dataPenyakitBawaan = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        dataPenyakitKronis = new javax.swing.JLabel();
        dataRawatRS = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        dataRiwayatOperasi = new javax.swing.JLabel();
        dataGolongandarah = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        dataAlergi = new javax.swing.JLabel();
        fieldFaktorResiko = new javax.swing.JTextField();
        fieldPenyakitBawaan = new javax.swing.JTextField();
        fieldPenyakitKronis = new javax.swing.JTextField();
        fieldRawatRS = new javax.swing.JTextField();
        fieldRiwayatOperasi = new javax.swing.JTextField();
        ComboBoxGolongandarah = new javax.swing.JComboBox<>();
        fieldAlergi = new javax.swing.JTextField();
        inputAlergi = new javax.swing.JButton();
        deleteAlergi = new javax.swing.JButton();
        deleteGolongandarah = new javax.swing.JButton();
        inputGolongandarah = new javax.swing.JButton();
        inputRiwayatOperasi = new javax.swing.JButton();
        deleteRiwayatOperasi = new javax.swing.JButton();
        inputRawatRS = new javax.swing.JButton();
        deleteRawatRS = new javax.swing.JButton();
        inputPenyakitKronis = new javax.swing.JButton();
        deletePenyakitKronis = new javax.swing.JButton();
        inputPenyakitBawaan = new javax.swing.JButton();
        deletePenyakitBawaan = new javax.swing.JButton();
        inputFaktorResiko = new javax.swing.JButton();
        deleteFaktorResiko = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        panelOperationTitle.setBackground(new java.awt.Color(40, 48, 90));
        panelOperationTitle.setPreferredSize(new java.awt.Dimension(1300, 100));

        btnLogOut.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/close.png"))); // NOI18N
        btnLogOut.setBorder(null);
        btnLogOut.setBorderPainted(false);
        btnLogOut.setContentAreaFilled(false);
        btnLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogOutActionPerformed(evt);
            }
        });

        btnVerifikasiPin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/logout.png"))); // NOI18N
        btnVerifikasiPin.setBorder(null);
        btnVerifikasiPin.setContentAreaFilled(false);
        btnVerifikasiPin.setFocusPainted(false);
        btnVerifikasiPin.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnVerifikasiPin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerifikasiPinActionPerformed(evt);
            }
        });

        btnLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/home.png"))); // NOI18N
        btnLogout.setBorder(null);
        btnLogout.setContentAreaFilled(false);
        btnLogout.setFocusPainted(false);
        btnLogout.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        btnHome1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/back2.png"))); // NOI18N
        btnHome1.setBorder(null);
        btnHome1.setContentAreaFilled(false);
        btnHome1.setFocusPainted(false);
        btnHome1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnHome1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHome1ActionPerformed(evt);
            }
        });

        administrator1.setFont(new java.awt.Font("Segoe UI Light", 0, 36)); // NOI18N
        administrator1.setForeground(new java.awt.Color(255, 255, 255));
        administrator1.setText("ADMINISTRATOR");

        administrator2.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        administrator2.setForeground(new java.awt.Color(255, 255, 255));
        administrator2.setText("DATA PASIEN");

        javax.swing.GroupLayout panelOperationTitleLayout = new javax.swing.GroupLayout(panelOperationTitle);
        panelOperationTitle.setLayout(panelOperationTitleLayout);
        panelOperationTitleLayout.setHorizontalGroup(
            panelOperationTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelOperationTitleLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnHome1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panelOperationTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelOperationTitleLayout.createSequentialGroup()
                        .addComponent(administrator1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnVerifikasiPin)
                        .addGap(1, 1, 1)
                        .addComponent(btnLogout)
                        .addGap(1, 1, 1)
                        .addComponent(btnLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelOperationTitleLayout.createSequentialGroup()
                        .addComponent(administrator2)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(5, 5, 5))
        );
        panelOperationTitleLayout.setVerticalGroup(
            panelOperationTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelOperationTitleLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelOperationTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnHome1, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelOperationTitleLayout.createSequentialGroup()
                        .addComponent(administrator1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(administrator2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(panelOperationTitleLayout.createSequentialGroup()
                .addGroup(panelOperationTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnVerifikasiPin, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setFocusable(false);

        PanelReaderCard.setBackground(new java.awt.Color(40, 48, 90));
        PanelReaderCard.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        status_Label_AdminForm.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
        status_Label_AdminForm.setForeground(new java.awt.Color(255, 255, 255));
        status_Label_AdminForm.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        status_Label_AdminForm.setText("---Status--");
        status_Label_AdminForm.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout PanelReaderCardLayout = new javax.swing.GroupLayout(PanelReaderCard);
        PanelReaderCard.setLayout(PanelReaderCardLayout);
        PanelReaderCardLayout.setHorizontalGroup(
            PanelReaderCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelReaderCardLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(status_Label_AdminForm, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelReaderCardLayout.setVerticalGroup(
            PanelReaderCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelReaderCardLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(status_Label_AdminForm, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        status_Label_AdminForm.getAccessibleContext().setAccessibleName("");

        jTabbedAll.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedAll.setForeground(new java.awt.Color(70, 130, 180));
        jTabbedAll.setFocusable(false);
        jTabbedAll.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jTabbedAll.setPreferredSize(new java.awt.Dimension(1100, 381));

        DataDiri.setBackground(new java.awt.Color(255, 255, 255));

        jScrollPane_DATA.setBorder(null);
        jScrollPane_DATA.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        panelItemDATA.setBackground(new java.awt.Color(255, 255, 255));

        labelNoSC.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelNoSC.setText("No. SmartCard               :");
        labelNoSC.setPreferredSize(new java.awt.Dimension(130, 15));

        dataNoSc.setText("-");

        fieldNoSC.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldNoSC.setText("--input--");
        fieldNoSC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldNoSCActionPerformed(evt);
            }
        });

        inputNoSC.setText("Input");
        inputNoSC.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputNoSC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputNoSCActionPerformed(evt);
            }
        });

        deleteNoSC.setText("Delete");
        deleteNoSC.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteNoSC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteNoSCActionPerformed(evt);
            }
        });

        labelKategoriPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKategoriPasien.setText("Kategori Pasien              :");
        labelKategoriPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKategoriPasien.setText("-");

        fieldKategoriPasien.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldKategoriPasien.setText("--input--");
        fieldKategoriPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldKategoriPasienActionPerformed(evt);
            }
        });

        inputKategoriPasien.setText("Input");
        inputKategoriPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKategoriPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKategoriPasienActionPerformed(evt);
            }
        });

        deleteKategoriPasien.setText("Delete");
        deleteKategoriPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKategoriPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKategoriPasienActionPerformed(evt);
            }
        });

        labelNoAsuransi.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelNoAsuransi.setText("No.Asuransi                   :");
        labelNoAsuransi.setPreferredSize(new java.awt.Dimension(130, 15));

        dataNoAsuransi.setText("-");

        fieldNoAsuransi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldNoAsuransi.setText("--input--");
        fieldNoAsuransi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldNoAsuransiActionPerformed(evt);
            }
        });

        inputNoAsuransi.setText("Input");
        inputNoAsuransi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputNoAsuransi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputNoAsuransiActionPerformed(evt);
            }
        });

        deleteNoAsuransi.setText("Delete");
        deleteNoAsuransi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteNoAsuransi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteNoAsuransiActionPerformed(evt);
            }
        });

        labelTanggalDaftar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelTanggalDaftar.setText("Tgl. Pendaftaran Kartu    :");
        labelTanggalDaftar.setPreferredSize(new java.awt.Dimension(130, 15));

        dataTanggalDaftar.setText("-");

        fieldTanggalDaftar.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldTanggalDaftar.setText("ttmmyy");
        fieldTanggalDaftar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldTanggalDaftarActionPerformed(evt);
            }
        });

        inputTanggalDaftar.setText("Input");
        inputTanggalDaftar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputTanggalDaftar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputTanggalDaftarActionPerformed(evt);
            }
        });

        deleteTanggalDaftar.setText("Delete");
        deleteTanggalDaftar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteTanggalDaftar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteTanggalDaftarActionPerformed(evt);
            }
        });

        labelNamaPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelNamaPasien.setText("Nama Pasien                  :");
        labelNamaPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataNamaPasien.setText("-");

        fieldNamaPasien.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldNamaPasien.setText("--input--");
        fieldNamaPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldNamaPasienActionPerformed(evt);
            }
        });

        inputNamaPasien.setText("Input");
        inputNamaPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputNamaPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputNamaPasienActionPerformed(evt);
            }
        });

        deleteNamaPasien.setText("Delete");
        deleteNamaPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteNamaPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteNamaPasienActionPerformed(evt);
            }
        });

        labelNamaKK.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelNamaKK.setText("Nama KK                       :");
        labelNamaKK.setPreferredSize(new java.awt.Dimension(130, 15));

        dataNamaKK.setText("-");

        fieldNamaKK.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldNamaKK.setText("--input--");
        fieldNamaKK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldNamaKKActionPerformed(evt);
            }
        });

        inputNamaKK.setText("Input");
        inputNamaKK.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputNamaKK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputNamaKKActionPerformed(evt);
            }
        });

        deleteNamaKK.setText("Delete");
        deleteNamaKK.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteNamaKK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteNamaKKActionPerformed(evt);
            }
        });

        labelHubKeluarga.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelHubKeluarga.setText("Hubungan Keluarga         :");
        labelHubKeluarga.setPreferredSize(new java.awt.Dimension(130, 15));

        dataHubKeluarga.setText("-");

        ComboBox_HubKeluarga.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. Orang Tua", "2. Kakek Nenek", "3. Anak", "4. Saudara Kandung", "5. Saudara Ayah", "6. Saudara Ibu", "7. Suami/Istri" }));
        ComboBox_HubKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBox_HubKeluargaActionPerformed(evt);
            }
        });

        inputHubKeluarga.setText("Input");
        inputHubKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputHubKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputHubKeluargaActionPerformed(evt);
            }
        });

        deleteHubKeluarga.setText("Delete");
        deleteHubKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteHubKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteHubKeluargaActionPerformed(evt);
            }
        });

        labelAlamat.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelAlamat.setText("Alamat                          :");
        labelAlamat.setPreferredSize(new java.awt.Dimension(130, 15));

        dataAlamat.setText("-");

        fieldAlamat.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldAlamat.setText("--input--");
        fieldAlamat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldAlamatActionPerformed(evt);
            }
        });

        inputAlamat.setText("Input");
        inputAlamat.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputAlamat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputAlamatActionPerformed(evt);
            }
        });

        deleteAlamat.setText("Delete");
        deleteAlamat.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteAlamat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteAlamatActionPerformed(evt);
            }
        });

        labelRT.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelRT.setText("RT                               :");
        labelRT.setPreferredSize(new java.awt.Dimension(130, 15));

        dataRT.setText("-");

        inputRT.setText("Input");
        inputRT.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputRT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputRTActionPerformed(evt);
            }
        });

        deleteRT.setText("Delete");
        deleteRT.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteRT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteRTActionPerformed(evt);
            }
        });

        labelRW.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelRW.setText("RW                              :");
        labelRW.setPreferredSize(new java.awt.Dimension(130, 15));

        dataRW.setText("-");

        inputRW.setText("Input");
        inputRW.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputRW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputRWActionPerformed(evt);
            }
        });

        deleteRW.setText("Delete");
        deleteRW.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteRW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteRWActionPerformed(evt);
            }
        });

        labelKelurahanPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKelurahanPasien.setText("Kelurahan / Desa            :");
        labelKelurahanPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKelurahanPasien.setText("-");

        inputKelurahanPasien.setText("Input");
        inputKelurahanPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKelurahanPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKelurahanPasienActionPerformed(evt);
            }
        });

        deleteKelurahanPasien.setText("Delete");
        deleteKelurahanPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKelurahanPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKelurahanPasienActionPerformed(evt);
            }
        });

        labelKecamatanPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKecamatanPasien.setText("Kecamatan                    :");
        labelKecamatanPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKecamatanPasien.setText("-");

        inputKecamatanPasien.setText("Input");
        inputKecamatanPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKecamatanPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKecamatanPasienActionPerformed(evt);
            }
        });

        deleteKecamatanPasien.setText("Delete");
        deleteKecamatanPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKecamatanPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKecamatanPasienActionPerformed(evt);
            }
        });

        labelKotaPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKotaPasien.setText("Kota / Kabupaten           :");
        labelKotaPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKotaPasien.setText("-");

        inputKotaPasien.setText("Input");
        inputKotaPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKotaPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKotaPasienActionPerformed(evt);
            }
        });

        deleteKotaPasien.setText("Delete");
        deleteKotaPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKotaPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKotaPasienActionPerformed(evt);
            }
        });

        labelPropinsiPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelPropinsiPasien.setText("Propinsi                         :");
        labelPropinsiPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataPropinsiPasien.setText("-");

        inputPropinsiPasien.setText("Input");
        inputPropinsiPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputPropinsiPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputPropinsiPasienActionPerformed(evt);
            }
        });

        deletePropinsiPasien.setText("Delete");
        deletePropinsiPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletePropinsiPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePropinsiPasienActionPerformed(evt);
            }
        });

        labelKodePos.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKodePos.setText("Kode Pos                      :");
        labelKodePos.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKodePos.setText("-");

        fieldKodePos.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldKodePos.setText("--input--");
        fieldKodePos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldKodePosActionPerformed(evt);
            }
        });

        inputKodePos.setText("Input");
        inputKodePos.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKodePos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKodePosActionPerformed(evt);
            }
        });

        deleteKodePos.setText("Delete");
        deleteKodePos.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKodePos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKodePosActionPerformed(evt);
            }
        });

        labelWilayahKerja.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelWilayahKerja.setText("Wilayah Kerja                 :");
        labelWilayahKerja.setPreferredSize(new java.awt.Dimension(130, 15));

        dataWilayahKerja.setText("-");

        inputWilayahKerja.setText("Input");
        inputWilayahKerja.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputWilayahKerja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputWilayahKerjaActionPerformed(evt);
            }
        });

        deleteWilayahKerja.setText("Delete");
        deleteWilayahKerja.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteWilayahKerja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteWilayahKerjaActionPerformed(evt);
            }
        });

        labelTempatLahir.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelTempatLahir.setText("Tempat Lahir                 :");
        labelTempatLahir.setPreferredSize(new java.awt.Dimension(130, 15));

        dataTempatLahir.setText("-");

        fieldTempatLahir.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldTempatLahir.setText("--input--");
        fieldTempatLahir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldTempatLahirActionPerformed(evt);
            }
        });

        inputTempatLahir.setText("Input");
        inputTempatLahir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputTempatLahir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputTempatLahirActionPerformed(evt);
            }
        });

        deleteTempatLahir.setText("Delete");
        deleteTempatLahir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteTempatLahir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteTempatLahirActionPerformed(evt);
            }
        });

        labelTanggalLahir.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelTanggalLahir.setText("Tanggal Lahir                 :");
        labelTanggalLahir.setPreferredSize(new java.awt.Dimension(130, 15));

        dataTanggalLahir.setText("-");

        fieldTanggalLahir.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldTanggalLahir.setText("ttmmyy");
        fieldTanggalLahir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldTanggalLahirActionPerformed(evt);
            }
        });

        inputTanggalLahir.setText("Input");
        inputTanggalLahir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputTanggalLahir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputTanggalLahirActionPerformed(evt);
            }
        });

        deleteTanggalLahir.setText("Delete");
        deleteTanggalLahir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteTanggalLahir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteTanggalLahirActionPerformed(evt);
            }
        });

        labelTeleponPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelTeleponPasien.setText("Telepon                        :");
        labelTeleponPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataTeleponPasien.setText("-");

        fieldTeleponPasien.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldTeleponPasien.setText("--input--");
        fieldTeleponPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldTeleponPasienActionPerformed(evt);
            }
        });

        inputTeleponPasien.setText("Input");
        inputTeleponPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputTeleponPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputTeleponPasienActionPerformed(evt);
            }
        });

        deleteTeleponPasien.setText("Delete");
        deleteTeleponPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteTeleponPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteTeleponPasienActionPerformed(evt);
            }
        });

        labelHPPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelHPPasien.setText("HP                               :");
        labelHPPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataHPPasien.setText("-");

        fieldHPPasien.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldHPPasien.setText("--input--");
        fieldHPPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldHPPasienActionPerformed(evt);
            }
        });

        inputHPPasien.setText("Input");
        inputHPPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputHPPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputHPPasienActionPerformed(evt);
            }
        });

        deleteHPPasien.setText("Delete");
        deleteHPPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteHPPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteHPPasienActionPerformed(evt);
            }
        });

        labelKTPPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKTPPasien.setText("No. KTP-NIK                  :");
        labelKTPPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKTPPasien.setText("-");

        fieldKTPPasien.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldKTPPasien.setText("xxxxxxxxxxxxxxxx");
        fieldKTPPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldKTPPasienActionPerformed(evt);
            }
        });

        inputKTPPasien.setText("Input");
        inputKTPPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKTPPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKTPPasienActionPerformed(evt);
            }
        });

        deleteKTPPasien.setText("Delete");
        deleteKTPPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKTPPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKTPPasienActionPerformed(evt);
            }
        });

        labelJenisKelaminPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelJenisKelaminPasien.setText("Jenis Kelamin                 :");
        labelJenisKelaminPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataJenisKelaminPasien.setText("-");

        inputJenisKelaminPasien.setText("Input");
        inputJenisKelaminPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputJenisKelaminPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputJenisKelaminPasienActionPerformed(evt);
            }
        });

        deleteJenisKelaminPasien.setText("Delete");
        deleteJenisKelaminPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteJenisKelaminPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteJenisKelaminPasienActionPerformed(evt);
            }
        });

        labelAgamaPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelAgamaPasien.setText("Agama                          :");
        labelAgamaPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataAgamaPasien.setText("-");

        inputAgamaPasien.setText("Input");
        inputAgamaPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputAgamaPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputAgamaPasienActionPerformed(evt);
            }
        });

        deleteAgamaPasien.setText("Delete");
        deleteAgamaPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteAgamaPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteAgamaPasienActionPerformed(evt);
            }
        });

        labelPendidikanPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelPendidikanPasien.setText("Pendidikan                     :");
        labelPendidikanPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataPendidikanPasien.setText("-");

        inputPendidikanPasien.setText("Input");
        inputPendidikanPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputPendidikanPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputPendidikanPasienActionPerformed(evt);
            }
        });

        deletePendidikanPasien.setText("Delete");
        deletePendidikanPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletePendidikanPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePendidikanPasienActionPerformed(evt);
            }
        });

        labelPekerjaanPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelPekerjaanPasien.setText("Pekerjaan                      :");
        labelPekerjaanPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataPekerjaanPasien.setText("-");

        inputPekerjaanPasien.setText("Input");
        inputPekerjaanPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputPekerjaanPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputPekerjaanPasienActionPerformed(evt);
            }
        });

        deletePekerjaanPasien.setText("Delete");
        deletePekerjaanPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletePekerjaanPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePekerjaanPasienActionPerformed(evt);
            }
        });

        labelKelasPerawatan.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKelasPerawatan.setText("Kelas Perawatan             :");
        labelKelasPerawatan.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKelasPerawatan.setText("-");

        fieldKelasPerawatan.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldKelasPerawatan.setText("--input--");

        inputKelasPerawatan.setText("Input");
        inputKelasPerawatan.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKelasPerawatan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKelasPerawatanActionPerformed(evt);
            }
        });

        deleteKelasPerawatan.setText("Delete");
        deleteKelasPerawatan.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKelasPerawatan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKelasPerawatanActionPerformed(evt);
            }
        });

        labelEmailPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelEmailPasien.setText("Alamat E-mail                 :");
        labelEmailPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataEmailPasien.setText("-");

        fieldEmailPasien.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldEmailPasien.setText("--input--");
        fieldEmailPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldEmailPasienActionPerformed(evt);
            }
        });

        inputEmailPasien.setText("Input");
        inputEmailPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputEmailPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputEmailPasienActionPerformed(evt);
            }
        });

        deleteEmailPasien.setText("Delete");
        deleteEmailPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteEmailPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteEmailPasienActionPerformed(evt);
            }
        });

        labelStatusPerkawinanPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelStatusPerkawinanPasien.setText("Status perkawinan          :");
        labelStatusPerkawinanPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataStatusPerkawinanPasien.setText("-");

        inputStatusPerkawinanPasien.setText("Input");
        inputStatusPerkawinanPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputStatusPerkawinanPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputStatusPerkawinanPasienActionPerformed(evt);
            }
        });

        deleteStatusPerkawinanPasien.setText("Delete");
        deleteStatusPerkawinanPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteStatusPerkawinanPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteStatusPerkawinanPasienActionPerformed(evt);
            }
        });

        labelKewarganegaraanPasien.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKewarganegaraanPasien.setText("Kewarganegaraan           :");
        labelKewarganegaraanPasien.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKewarganegaraanPasien.setText("-");

        inputKewarganegaraanPasien.setText("Input");
        inputKewarganegaraanPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKewarganegaraanPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKewarganegaraanPasienActionPerformed(evt);
            }
        });

        deleteKewarganegaraanPasien.setText("Delete");
        deleteKewarganegaraanPasien.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKewarganegaraanPasien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKewarganegaraanPasienActionPerformed(evt);
            }
        });

        labelNamaKeluarga.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelNamaKeluarga.setText("Nama Keluarga               :");
        labelNamaKeluarga.setPreferredSize(new java.awt.Dimension(130, 15));

        dataNamaKeluarga.setText("-");

        fieldNamaKeluarga.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldNamaKeluarga.setText("--input--");
        fieldNamaKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldNamaKeluargaActionPerformed(evt);
            }
        });

        inputNamaKeluarga.setText("Input");
        inputNamaKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputNamaKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputNamaKeluargaActionPerformed(evt);
            }
        });

        deleteNamaKeluarga.setText("Delete");
        deleteNamaKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteNamaKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteNamaKeluargaActionPerformed(evt);
            }
        });

        labelHubungan.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelHubungan.setText("Hubungan                     :");
        labelHubungan.setPreferredSize(new java.awt.Dimension(130, 15));

        dataHubungan.setText("-");

        inputHubungan.setText("Input");
        inputHubungan.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputHubungan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputHubunganActionPerformed(evt);
            }
        });

        deleteHubungan.setText("Delete");
        deleteHubungan.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteHubungan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteHubunganActionPerformed(evt);
            }
        });

        labelAlamatKeluarga.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelAlamatKeluarga.setText("Alamat                          :");
        labelAlamatKeluarga.setPreferredSize(new java.awt.Dimension(130, 15));

        dataAlamatKeluarga.setText("-");

        fieldAlamatKeluarga.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldAlamatKeluarga.setText("--input--");
        fieldAlamatKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldAlamatKeluargaActionPerformed(evt);
            }
        });

        inputAlamatKeluarga.setText("Input");
        inputAlamatKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputAlamatKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputAlamatKeluargaActionPerformed(evt);
            }
        });

        deleteAlamatKeluarga.setText("Delete");
        deleteAlamatKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteAlamatKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteAlamatKeluargaActionPerformed(evt);
            }
        });

        labelKelurahanKeluarga.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKelurahanKeluarga.setText("Kelurahan / Desa            :");
        labelKelurahanKeluarga.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKelurahanKeluarga.setText("-");

        inputKelurahanKeluarga.setText("Input");
        inputKelurahanKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKelurahanKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKelurahanKeluargaActionPerformed(evt);
            }
        });

        deleteKelurahanKeluarga.setText("Delete");
        deleteKelurahanKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKelurahanKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKelurahanKeluargaActionPerformed(evt);
            }
        });

        labelKecamatanKeluarga.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKecamatanKeluarga.setText("Kecamatan                    :");
        labelKecamatanKeluarga.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKecamatanKeluarga.setText("-");

        inputKecamatanKeluarga.setText("Input");
        inputKecamatanKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKecamatanKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKecamatanKeluargaActionPerformed(evt);
            }
        });

        deleteKecamatanKeluarga.setText("Delete");
        deleteKecamatanKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKecamatanKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKecamatanKeluargaActionPerformed(evt);
            }
        });

        labelKotaKeluarga.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKotaKeluarga.setText("Kota / Kabupaten           :");
        labelKotaKeluarga.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKotaKeluarga.setText("-");

        inputKotaKeluarga.setText("Input");
        inputKotaKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKotaKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKotaKeluargaActionPerformed(evt);
            }
        });

        deleteKotaKeluarga.setText("Delete");
        deleteKotaKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKotaKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKotaKeluargaActionPerformed(evt);
            }
        });

        labelPropinsiKeluarga.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelPropinsiKeluarga.setText("Propinsi                         :");
        labelPropinsiKeluarga.setPreferredSize(new java.awt.Dimension(130, 15));

        dataPropinsiKeluarga.setText("-");

        inputPropinsiKeluarga.setText("Input");
        inputPropinsiKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputPropinsiKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputPropinsiKeluargaActionPerformed(evt);
            }
        });

        deletePropinsiKeluarga.setText("Delete");
        deletePropinsiKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletePropinsiKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePropinsiKeluargaActionPerformed(evt);
            }
        });

        labelKodePosKeluarga.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKodePosKeluarga.setText("Kode Pos                      :");
        labelKodePosKeluarga.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKodePosKeluarga.setText("-");

        fieldKodePosKeluarga.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldKodePosKeluarga.setText("--input--");
        fieldKodePosKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldKodePosKeluargaActionPerformed(evt);
            }
        });

        inputKodePosKeluarga.setText("Input");
        inputKodePosKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKodePosKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKodePosKeluargaActionPerformed(evt);
            }
        });

        deleteKodePosKeluarga.setText("Delete");
        deleteKodePosKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKodePosKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKodePosKeluargaActionPerformed(evt);
            }
        });

        labelTeleponKeluarga.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelTeleponKeluarga.setText("Telepon                        :");
        labelTeleponKeluarga.setPreferredSize(new java.awt.Dimension(130, 15));

        dataTeleponKeluarga.setText("-");

        fieldTeleponKeluarga.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldTeleponKeluarga.setText("--input--");
        fieldTeleponKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldTeleponKeluargaActionPerformed(evt);
            }
        });

        inputTeleponKeluarga.setText("Input");
        inputTeleponKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputTeleponKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputTeleponKeluargaActionPerformed(evt);
            }
        });

        deleteTeleponKeluarga.setText("Delete");
        deleteTeleponKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteTeleponKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteTeleponKeluargaActionPerformed(evt);
            }
        });

        labelHPKeluarga.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelHPKeluarga.setText("HP                               :");
        labelHPKeluarga.setPreferredSize(new java.awt.Dimension(130, 15));

        dataHPKeluarga.setText("-");

        fieldHPKeluarga.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldHPKeluarga.setText("--input--");
        fieldHPKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldHPKeluargaActionPerformed(evt);
            }
        });

        inputHPKeluarga.setText("Input");
        inputHPKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputHPKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputHPKeluargaActionPerformed(evt);
            }
        });

        deleteHPKeluarga.setText("Delete");
        deleteHPKeluarga.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteHPKeluarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteHPKeluargaActionPerformed(evt);
            }
        });

        labelNamaKantor.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelNamaKantor.setText("Nama Kantor                 :");
        labelNamaKantor.setPreferredSize(new java.awt.Dimension(130, 15));

        dataNamaKantor.setText("-");

        fieldNamaKantor.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldNamaKantor.setText("--input--");
        fieldNamaKantor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldNamaKantorActionPerformed(evt);
            }
        });

        inputNamaKantor.setText("Input");
        inputNamaKantor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputNamaKantor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputNamaKantorActionPerformed(evt);
            }
        });

        deleteNamaKantor.setText("Delete");
        deleteNamaKantor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteNamaKantor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteNamaKantorActionPerformed(evt);
            }
        });

        labelAlamatKantor.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelAlamatKantor.setText("Alamat Kantor               :");
        labelAlamatKantor.setPreferredSize(new java.awt.Dimension(130, 15));

        dataAlamatKantor.setText("-");

        fieldAlamatKantor.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldAlamatKantor.setText("--input--");
        fieldAlamatKantor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldAlamatKantorActionPerformed(evt);
            }
        });

        inputAlamatKantor.setText("Input");
        inputAlamatKantor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputAlamatKantor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputAlamatKantorActionPerformed(evt);
            }
        });

        deleteAlamatKantor.setText("Delete");
        deleteAlamatKantor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteAlamatKantor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteAlamatKantorActionPerformed(evt);
            }
        });

        labelKotaKantor.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelKotaKantor.setText("Kota / Kabupaten          :");
        labelKotaKantor.setPreferredSize(new java.awt.Dimension(130, 15));

        dataKotaKantor.setText("-");

        inputKotaKantor.setText("Input");
        inputKotaKantor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputKotaKantor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputKotaKantorActionPerformed(evt);
            }
        });

        deleteKotaKantor.setText("Delete");
        deleteKotaKantor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteKotaKantor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteKotaKantorActionPerformed(evt);
            }
        });

        labelTeleponKantor1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelTeleponKantor1.setText("Telepon                       :");
        labelTeleponKantor1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataTeleponKantor1.setText("-");

        fieldTeleponKantor1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldTeleponKantor1.setText("--input--");
        fieldTeleponKantor1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldTeleponKantor1ActionPerformed(evt);
            }
        });

        inputTeleponKantor1.setText("Input");
        inputTeleponKantor1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputTeleponKantor1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputTeleponKantor1ActionPerformed(evt);
            }
        });

        deleteTeleponKantor1.setText("Delete");
        deleteTeleponKantor1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteTeleponKantor1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteTeleponKantor1ActionPerformed(evt);
            }
        });

        labelHPKantor1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        labelHPKantor1.setText("HP                            :");
        labelHPKantor1.setPreferredSize(new java.awt.Dimension(130, 15));

        dataHPKantor1.setText("-");

        fieldHPKantor1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldHPKantor1.setText("--input--");
        fieldHPKantor1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldHPKantor1ActionPerformed(evt);
            }
        });

        inputHPKantor1.setText("Input");
        inputHPKantor1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputHPKantor1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputHPKantor1ActionPerformed(evt);
            }
        });

        deleteHPKantor1.setText("Delete");
        deleteHPKantor1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteHPKantor1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteHPKantor1ActionPerformed(evt);
            }
        });

        ComboBox_RT.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. RT1", "2. RT2", "3. RT3", "4. RT4", "5. RT5", "6. RT6", "7. RT7", "8. RT8", "9. RT9", "10. RT10", "11. RT11", "12. RT12", "13. RT13", "14. RT14", "15. RT15", "16. RT16", "17. RT17", "18. RT18", "19. RT19", "20. RT20", "21. RT21", "22. RT22", "23. RT23", "24. RT24", "25. RT25", "26. RT26", "27. RT27", "28. RT28", "29. RT29", "30. RT30" }));

        ComboBox_RW.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. RW1", "2. RW2", "3. RW3", "4. RW4", "5. RW5", "6. RW6", "7. RW7", "8. RW8", "9. RW9", "10. RW10", "11. RW11", "12. RW12", "13. RW13", "14. RW14", "15. RW15", "16. RW16", "17. RW17", "18. RW18", "19. RW19", "20. RW20", "21. RW21", "22. RW22", "23. RW23", "24. RW24", "25. RW25", "26. RW26", "27. RW27", "28. RW28", "29. RW29", "30. RW30" }));

        ComboBox_KelurahanPasien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. KelurahanPasien1", "2. KelurahanPasien2", "3. KelurahanPasien3", "4. KelurahanPasien4", "5. KelurahanPasien5", "6. KelurahanPasien6", "7. KelurahanPasien7", "8. KelurahanPasien8", "9. KelurahanPasien9", "10. KelurahanPasien10", "11. KelurahanPasien11", "12. KelurahanPasien12", "13. KelurahanPasien13", "14. KelurahanPasien14", "15. KelurahanPasien15", "16. KelurahanPasien16", "17. KelurahanPasien17", "18. KelurahanPasien18", "19. KelurahanPasien19", "20. KelurahanPasien20", "21. KelurahanPasien21", "22. KelurahanPasien22", "23. KelurahanPasien23", "24. KelurahanPasien24", "25. KelurahanPasien25", "26. KelurahanPasien26", "27. KelurahanPasien27", "28. KelurahanPasien28", "29. KelurahanPasien29", "30. KelurahanPasien30" }));

        ComboBox_KecamatanPasien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. KecamatanPasien1", "2. KecamatanPasien2", "3. KecamatanPasien3", "4. KecamatanPasien4", "5. KecamatanPasien5", "6. KecamatanPasien6", "7. KecamatanPasien7", "8. KecamatanPasien8", "9. KecamatanPasien9", "10. KecamatanPasien10", "11. KecamatanPasien11", "12. KecamatanPasien12", "13. KecamatanPasien13", "14. KecamatanPasien14", "15. KecamatanPasien15", "16. KecamatanPasien16", "17. KecamatanPasien17", "18. KecamatanPasien18", "19. KecamatanPasien19", "20. KecamatanPasien20", "21. KecamatanPasien21", "22. KecamatanPasien22", "23. KecamatanPasien23", "24. KecamatanPasien24", "25. KecamatanPasien25", "26. KecamatanPasien26", "27. KecamatanPasien27", "28. KecamatanPasien28", "29. KecamatanPasien29", "30. KecamatanPasien30" }));

        ComboBox_KotaPasien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. KotaPasien1", "2. KotaPasien2", "3. KotaPasien3", "4. KotaPasien4", "5. KotaPasien5", "6. KotaPasien6", "7. KotaPasien7", "8. KotaPasien8", "9. KotaPasien9", "10. KotaPasien10", "11. KotaPasien11", "12. KotaPasien12", "13. KotaPasien13", "14. KotaPasien14", "15. KotaPasien15", "16. KotaPasien16", "17. KotaPasien17", "18. KotaPasien18", "19. KotaPasien19", "20. KotaPasien20", "21. KotaPasien21", "22. KotaPasien22", "23. KotaPasien23", "24. KotaPasien24", "25. KotaPasien25", "26. KotaPasien26", "27. KotaPasien27", "28. KotaPasien28", "29. KotaPasien29", "30. KotaPasien30" }));

        ComboBox_PropinsiPasien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. PropinsiPasien1", "2. PropinsiPasien2", "3. PropinsiPasien3", "4. PropinsiPasien4", "5. PropinsiPasien5", "6. PropinsiPasien6", "7. PropinsiPasien7", "8. PropinsiPasien8", "9. PropinsiPasien9", "10. PropinsiPasien10", "11. PropinsiPasien11", "12. PropinsiPasien12", "13. PropinsiPasien13", "14. PropinsiPasien14", "15. PropinsiPasien15", "16. PropinsiPasien16", "17. PropinsiPasien17", "18. PropinsiPasien18", "19. PropinsiPasien19", "20. PropinsiPasien20", "21. PropinsiPasien21", "22. PropinsiPasien22", "23. PropinsiPasien23", "24. PropinsiPasien24", "25. PropinsiPasien25", "26. PropinsiPasien26", "27. PropinsiPasien27", "28. PropinsiPasien28", "29. PropinsiPasien29", "30. PropinsiPasien30", "31. PropinsiPasien31", "32. PropinsiPasien32", "33. PropinsiPasien33", "34. PropinsiPasien34" }));

        ComboBox_WilayahKerja.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. Didalam", "2. Diluar" }));

        ComboBox_JenisKelaminPasien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. Pria", "2. Wanita" }));

        ComboBox_AgamaPasien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. Islam", "2. Kristen (Protestan)", "3. Hindu", "4. Budha", "5. Katolik", "6. Konghucu" }));

        ComboBox_PendidikanPasien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. Tidak Sekolah", "2. Belum/Tidak Tamat SD", "3. Tamat SD", "4. Tamat SMP", "5. Tamat SMA", "6. Tamat Diploma", "7. tamat S1" }));

        ComboBox_PekerjaanPasien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. PNS", "2. TNI/POLRI", "3. Pensiunan", "4. Swasta", "5. Pedagang", "6. Nelayan", "7. Petani", "8. Pekerja Lepas/Wiraswasta", "9. Ibu Rumah Tangga", "10. Pelajar", "11. Mahasiswa", "12. Dibawah Umur", "13. Tidak bekerja" }));

        ComboBox_StatusPerkawinanPasien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. Menikah", "2. Belum Menikah", "3. Janda/Duda" }));

        ComboBox_KewarganegaraanPasien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. WNI", "2. WNA" }));

        ComboBox_Hubungan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. Orang Tua", "2. Kakek Nenek", "3. Anak", "4. Saudara Kandung", "5. Saudara Ayah", "6. Saudara Ibu", "7. Suami/Istri" }));

        ComboBox_KelurahanKeluarga.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. KelurahanKeluarga1", "2. KelurahanKeluarga2", "3. KelurahanKeluarga3", "4. KelurahanKeluarga4", "5. KelurahanKeluarga5", "6. KelurahanKeluarga6", "7. KelurahanKeluarga7", "8. KelurahanKeluarga8", "9. KelurahanKeluarga9", "10. KelurahanKeluarga10", "11. KelurahanKeluarga11", "12. KelurahanKeluarga12", "13. KelurahanKeluarga13", "14. KelurahanKeluarga14", "15. KelurahanKeluarga15", "16. KelurahanKeluarga16", "17. KelurahanKeluarga17", "18. KelurahanKeluarga18", "19. KelurahanKeluarga19", "20. KelurahanKeluarga20", "21. KelurahanKeluarga21", "22. KelurahanKeluarga22", "23. KelurahanKeluarga23", "24. KelurahanKeluarga24", "25. KelurahanKeluarga25", "26. KelurahanKeluarga26", "27. KelurahanKeluarga27", "28. KelurahanKeluarga28", "29. KelurahanKeluarga29", "30. KelurahanKeluarga30" }));

        ComboBox_KecamatanKeluarga.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. KecamatanKeluarga1", "2. KecamatanKeluarga2", "3. KecamatanKeluarga3", "4. KecamatanKeluarga4", "5. KecamatanKeluarga5", "6. KecamatanKeluarga6", "7. KecamatanKeluarga7", "8. KecamatanKeluarga8", "9. KecamatanKeluarga9", "10. KecamatanKeluarga10", "11. KecamatanKeluarga11", "12. KecamatanKeluarga12", "13. KecamatanKeluarga13", "14. KecamatanKeluarga14", "15. KecamatanKeluarga15", "16. KecamatanKeluarga16", "17. KecamatanKeluarga17", "18. KecamatanKeluarga18", "19. KecamatanKeluarga19", "20. KecamatanKeluarga20", "21. KecamatanKeluarga21", "22. KecamatanKeluarga22", "23. KecamatanKeluarga23", "24. KecamatanKeluarga24", "25. KecamatanKeluarga25", "26. KecamatanKeluarga26", "27. KecamatanKeluarga27", "28. KecamatanKeluarga28", "29. KecamatanKeluarga29", "30. KecamatanKeluarga30" }));

        ComboBox_KotaKeluarga.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. KotaKeluarga1", "2. KotaKeluarga2", "3. KotaKeluarga3", "4. KotaKeluarga4", "5. KotaKeluarga5", "6. KotaKeluarga6", "7. KotaKeluarga7", "8. KotaKeluarga8", "9. KotaKeluarga9", "10. KotaKeluarga10", "11. KotaKeluarga11", "12. KotaKeluarga12", "13. KotaKeluarga13", "14. KotaKeluarga14", "15. KotaKeluarga15", "16. KotaKeluarga16", "17. KotaKeluarga17", "18. KotaKeluarga18", "19. KotaKeluarga19", "20. KotaKeluarga20", "21. KotaKeluarga21", "22. KotaKeluarga22", "23. KotaKeluarga23", "24. KotaKeluarga24", "25. KotaKeluarga25", "26. KotaKeluarga26", "27. KotaKeluarga27", "28. KotaKeluarga28", "29. KotaKeluarga29", "30. KotaKeluarga30" }));

        ComboBox_PropinsiKeluarga.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. PropinsiKeluarga1", "2. PropinsiKeluarga2", "3. PropinsiKeluarga3", "4. PropinsiKeluarga4", "5. PropinsiKeluarga5", "6. PropinsiKeluarga6", "7. PropinsiKeluarga7", "8. PropinsiKeluarga8", "9. PropinsiKeluarga9", "10. PropinsiKeluarga10", "11. PropinsiKeluarga11", "12. PropinsiKeluarga12", "13. PropinsiKeluarga13", "14. PropinsiKeluarga14", "15. PropinsiKeluarga15", "16. PropinsiKeluarga16", "17. PropinsiKeluarga17", "18. PropinsiKeluarga18", "19. PropinsiKeluarga19", "20. PropinsiKeluarga20", "21. PropinsiKeluarga21", "22. PropinsiKeluarga22", "23. PropinsiKeluarga23", "24. PropinsiKeluarga24", "25. PropinsiKeluarga25", "26. PropinsiKeluarga26", "27. PropinsiKeluarga27", "28. PropinsiKeluarga28", "29. PropinsiKeluarga29", "30. PropinsiKeluarga30", "31. PropinsiKeluarga31", "32. PropinsiKeluarga32", "33. PropinsiKeluarga33", "34. PropinsiKeluarga34" }));

        ComboBox_KotaKantor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. KotaKantor1", "2. KotaKantor2", "3. KotaKantor3", "4. KotaKantor4", "5. KotaKantor5", "6. KotaKantor6", "7. KotaKantor7", "8. KotaKantor8", "9. KotaKantor9", "10. KotaKantor10", "11. KotaKantor11", "12. KotaKantor12", "13. KotaKantor13", "14. KotaKantor14", "15. KotaKantor15", "16. KotaKantor16", "17. KotaKantor17", "18. KotaKantor18", "19. KotaKantor19", "20. KotaKantor20", "21. KotaKantor21", "22. KotaKantor22", "23. KotaKantor23", "24. KotaKantor24", "25. KotaKantor25", "26. KotaKantor26", "27. KotaKantor27", "28. KotaKantor28", "29. KotaKantor29", "30. KotaKantor30" }));

        javax.swing.GroupLayout panelItemDATALayout = new javax.swing.GroupLayout(panelItemDATA);
        panelItemDATA.setLayout(panelItemDATALayout);
        panelItemDATALayout.setHorizontalGroup(
            panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelItemDATALayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelRT, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataRT, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_RT, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputRT, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteRT, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelRW, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataRW, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_RW, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputRW, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteRW, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelKelurahanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataKelurahanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_KelurahanPasien, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputKelurahanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteKelurahanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelKecamatanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataKecamatanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_KecamatanPasien, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputKecamatanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteKecamatanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelKotaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataKotaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_KotaPasien, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputKotaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteKotaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelPropinsiPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataPropinsiPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_PropinsiPasien, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputPropinsiPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deletePropinsiPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelWilayahKerja, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataWilayahKerja, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_WilayahKerja, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputWilayahKerja, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteWilayahKerja, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelJenisKelaminPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataJenisKelaminPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_JenisKelaminPasien, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputJenisKelaminPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteJenisKelaminPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelAgamaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataAgamaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_AgamaPasien, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputAgamaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteAgamaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelPendidikanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataPendidikanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_PendidikanPasien, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputPendidikanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deletePendidikanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelPekerjaanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataPekerjaanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_PekerjaanPasien, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputPekerjaanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deletePekerjaanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelKelasPerawatan, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataKelasPerawatan, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fieldKelasPerawatan)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputKelasPerawatan, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteKelasPerawatan, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelStatusPerkawinanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataStatusPerkawinanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_StatusPerkawinanPasien, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputStatusPerkawinanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteStatusPerkawinanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelKewarganegaraanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataKewarganegaraanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_KewarganegaraanPasien, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputKewarganegaraanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteKewarganegaraanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelHubungan, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataHubungan, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_Hubungan, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputHubungan, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteHubungan, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelKelurahanKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataKelurahanKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_KelurahanKeluarga, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputKelurahanKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteKelurahanKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelKecamatanKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataKecamatanKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_KecamatanKeluarga, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputKecamatanKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteKecamatanKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelKotaKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataKotaKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_KotaKeluarga, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputKotaKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteKotaKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelPropinsiKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataPropinsiKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_PropinsiKeluarga, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputPropinsiKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deletePropinsiKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addComponent(labelKotaKantor, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dataKotaKantor, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ComboBox_KotaKantor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inputKotaKantor, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteKotaKantor, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelNoSC, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataNoSc, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldNoSC, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputNoSC, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteNoSC, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelKategoriPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataKategoriPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldKategoriPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputKategoriPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteKategoriPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelNoAsuransi, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataNoAsuransi, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldNoAsuransi, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputNoAsuransi, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteNoAsuransi, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelTanggalDaftar, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataTanggalDaftar, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldTanggalDaftar, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputTanggalDaftar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteTanggalDaftar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelNamaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataNamaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldNamaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputNamaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteNamaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelNamaKK, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataNamaKK, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldNamaKK, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputNamaKK, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteNamaKK, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelKodePos, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataKodePos, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldKodePos, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputKodePos, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteKodePos, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelTempatLahir, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataTempatLahir, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldTempatLahir, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputTempatLahir, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteTempatLahir, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelTanggalLahir, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataTanggalLahir, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldTanggalLahir, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputTanggalLahir, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteTanggalLahir, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelTeleponPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataTeleponPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldTeleponPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputTeleponPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteTeleponPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelHPPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataHPPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldHPPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputHPPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteHPPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelKTPPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataKTPPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldKTPPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputKTPPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteKTPPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelEmailPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataEmailPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldEmailPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputEmailPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteEmailPasien, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelNamaKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataNamaKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldNamaKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputNamaKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteNamaKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelAlamatKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataAlamatKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldAlamatKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputAlamatKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteAlamatKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelKodePosKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataKodePosKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldKodePosKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputKodePosKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteKodePosKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelTeleponKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataTeleponKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldTeleponKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputTeleponKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteTeleponKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelHPKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataHPKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldHPKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputHPKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteHPKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelNamaKantor, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataNamaKantor, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldNamaKantor, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputNamaKantor, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteNamaKantor, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelAlamatKantor, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataAlamatKantor, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldAlamatKantor, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputAlamatKantor, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteAlamatKantor, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelTeleponKantor1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataTeleponKantor1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldTeleponKantor1, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputTeleponKantor1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteTeleponKantor1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addComponent(labelHPKantor1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dataHPKantor1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldHPKantor1, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(inputHPKantor1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteHPKantor1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelItemDATALayout.createSequentialGroup()
                                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(panelItemDATALayout.createSequentialGroup()
                                        .addComponent(labelHubKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dataHubKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(ComboBox_HubKeluarga, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(panelItemDATALayout.createSequentialGroup()
                                        .addComponent(labelAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dataAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(fieldAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelItemDATALayout.createSequentialGroup()
                                        .addComponent(inputAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(deleteAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(panelItemDATALayout.createSequentialGroup()
                                        .addComponent(inputHubKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(deleteHubKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(101, 101, 101))
        );
        panelItemDATALayout.setVerticalGroup(
            panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelItemDATALayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelNoSC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataNoSc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldNoSC)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputNoSC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteNoSC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKategoriPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKategoriPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldKategoriPasien)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputKategoriPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteKategoriPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelNoAsuransi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataNoAsuransi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldNoAsuransi)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputNoAsuransi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteNoAsuransi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelTanggalDaftar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataTanggalDaftar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldTanggalDaftar)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputTanggalDaftar, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteTanggalDaftar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelNamaPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataNamaPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldNamaPasien)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputNamaPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteNamaPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelNamaKK, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataNamaKK, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldNamaKK)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputNamaKK, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteNamaKK, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelHubKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataHubKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputHubKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteHubKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(ComboBox_HubKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelAlamat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataAlamat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldAlamat)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputAlamat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteAlamat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelRT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataRT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputRT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_RT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteRT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelRW, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataRW, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputRW, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_RW, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteRW, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKelurahanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKelurahanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputKelurahanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_KelurahanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteKelurahanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKecamatanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKecamatanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputKecamatanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_KecamatanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteKecamatanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKotaPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKotaPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputKotaPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_KotaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteKotaPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelPropinsiPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataPropinsiPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputPropinsiPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_PropinsiPasien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deletePropinsiPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKodePos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKodePos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldKodePos)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputKodePos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteKodePos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelWilayahKerja, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataWilayahKerja, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputWilayahKerja, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_WilayahKerja, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteWilayahKerja, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelTempatLahir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataTempatLahir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldTempatLahir)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputTempatLahir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteTempatLahir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelTanggalLahir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataTanggalLahir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldTanggalLahir)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputTanggalLahir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteTanggalLahir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelTeleponPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataTeleponPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldTeleponPasien)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputTeleponPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteTeleponPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelHPPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataHPPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldHPPasien)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputHPPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteHPPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKTPPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKTPPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldKTPPasien)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputKTPPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteKTPPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelJenisKelaminPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataJenisKelaminPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputJenisKelaminPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_JenisKelaminPasien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteJenisKelaminPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelAgamaPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataAgamaPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputAgamaPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_AgamaPasien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteAgamaPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelPendidikanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataPendidikanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputPendidikanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_PendidikanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deletePendidikanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelPekerjaanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataPekerjaanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputPekerjaanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_PekerjaanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deletePekerjaanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKelasPerawatan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKelasPerawatan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputKelasPerawatan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fieldKelasPerawatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteKelasPerawatan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelEmailPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataEmailPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldEmailPasien)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputEmailPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteEmailPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelStatusPerkawinanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataStatusPerkawinanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputStatusPerkawinanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_StatusPerkawinanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteStatusPerkawinanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKewarganegaraanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKewarganegaraanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputKewarganegaraanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_KewarganegaraanPasien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteKewarganegaraanPasien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelNamaKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataNamaKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldNamaKeluarga)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputNamaKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteNamaKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelHubungan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataHubungan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputHubungan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_Hubungan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteHubungan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelAlamatKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataAlamatKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldAlamatKeluarga)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputAlamatKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteAlamatKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKelurahanKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKelurahanKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputKelurahanKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_KelurahanKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteKelurahanKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKecamatanKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKecamatanKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputKecamatanKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_KecamatanKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteKecamatanKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKotaKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKotaKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputKotaKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_KotaKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteKotaKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelPropinsiKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataPropinsiKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputPropinsiKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_PropinsiKeluarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deletePropinsiKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKodePosKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKodePosKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldKodePosKeluarga)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputKodePosKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteKodePosKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelTeleponKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataTeleponKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldTeleponKeluarga)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputTeleponKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteTeleponKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelHPKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataHPKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldHPKeluarga)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputHPKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteHPKeluarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelNamaKantor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataNamaKantor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldNamaKantor)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputNamaKantor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteNamaKantor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelAlamatKantor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataAlamatKantor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldAlamatKantor)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(inputAlamatKantor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteAlamatKantor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelKotaKantor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(dataKotaKantor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inputKotaKantor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ComboBox_KotaKantor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(deleteKotaKantor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelTeleponKantor1, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(dataTeleponKantor1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldTeleponKantor1)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(inputTeleponKantor1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(deleteTeleponKantor1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(labelHPKantor1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(dataHPKantor1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(fieldHPKantor1)
                    .addGroup(panelItemDATALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(panelItemDATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(inputHPKantor1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(deleteHPKantor1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(115, 115, 115))
        );

        jScrollPane_DATA.setViewportView(panelItemDATA);

        getAllDATA.setBackground(new java.awt.Color(255, 255, 255));
        getAllDATA.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        getAllDATA.setForeground(java.awt.SystemColor.activeCaption);
        getAllDATA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/retrieve.png"))); // NOI18N
        getAllDATA.setText("Get All Item Data Diri");
        getAllDATA.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.SystemColor.activeCaption, new java.awt.Color(255, 255, 255), java.awt.SystemColor.controlHighlight, java.awt.SystemColor.activeCaption));
        getAllDATA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getAllSTATIS1ActionPerformed(evt);
            }
        });

        deleteAllDATA.setBackground(new java.awt.Color(255, 255, 255));
        deleteAllDATA.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        deleteAllDATA.setForeground(java.awt.SystemColor.activeCaption);
        deleteAllDATA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/delete.png"))); // NOI18N
        deleteAllDATA.setText("Delete All Item Data Diri");
        deleteAllDATA.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.SystemColor.activeCaption, new java.awt.Color(255, 255, 255), java.awt.SystemColor.controlHighlight, java.awt.SystemColor.activeCaption));
        deleteAllDATA.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        deleteAllDATA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteAllSTATIS1ActionPerformed(evt);
            }
        });

        inputAllSTATIS5.setBackground(new java.awt.Color(255, 255, 255));
        inputAllSTATIS5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        inputAllSTATIS5.setForeground(java.awt.SystemColor.activeCaption);
        inputAllSTATIS5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/save.png"))); // NOI18N
        inputAllSTATIS5.setText("Input All Item Data Diri");
        inputAllSTATIS5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.SystemColor.activeCaption, new java.awt.Color(255, 255, 255), java.awt.SystemColor.controlHighlight, java.awt.SystemColor.activeCaption));
        inputAllSTATIS5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputAllSTATIS1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelAllCRUD_DATALayout = new javax.swing.GroupLayout(panelAllCRUD_DATA);
        panelAllCRUD_DATA.setLayout(panelAllCRUD_DATALayout);
        panelAllCRUD_DATALayout.setHorizontalGroup(
            panelAllCRUD_DATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAllCRUD_DATALayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(getAllDATA, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(deleteAllDATA, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(inputAllSTATIS5, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelAllCRUD_DATALayout.setVerticalGroup(
            panelAllCRUD_DATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelAllCRUD_DATALayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelAllCRUD_DATALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(getAllDATA)
                    .addComponent(deleteAllDATA)
                    .addComponent(inputAllSTATIS5))
                .addContainerGap())
        );

        javax.swing.GroupLayout DataDiriLayout = new javax.swing.GroupLayout(DataDiri);
        DataDiri.setLayout(DataDiriLayout);
        DataDiriLayout.setHorizontalGroup(
            DataDiriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DataDiriLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(DataDiriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(DataDiriLayout.createSequentialGroup()
                        .addComponent(panelAllCRUD_DATA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addComponent(jScrollPane_DATA, javax.swing.GroupLayout.DEFAULT_SIZE, 1078, Short.MAX_VALUE)))
        );
        DataDiriLayout.setVerticalGroup(
            DataDiriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DataDiriLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane_DATA, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                .addGap(28, 28, 28)
                .addComponent(panelAllCRUD_DATA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedAll.addTab("Data Diri", new javax.swing.ImageIcon(getClass().getResource("/Icon/username.png")), DataDiri); // NOI18N

        RekamMedisStatis.setBackground(new java.awt.Color(255, 255, 255));

        getAllSTATIS.setBackground(new java.awt.Color(255, 255, 255));
        getAllSTATIS.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        getAllSTATIS.setForeground(java.awt.SystemColor.activeCaption);
        getAllSTATIS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/retrieve.png"))); // NOI18N
        getAllSTATIS.setText("Get All Item MedRec Statis");
        getAllSTATIS.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.SystemColor.activeCaption, new java.awt.Color(255, 255, 255), java.awt.SystemColor.controlHighlight, java.awt.SystemColor.activeCaption));
        getAllSTATIS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getAllSTATISActionPerformed(evt);
            }
        });

        deleteAllSTATIS.setBackground(new java.awt.Color(255, 255, 255));
        deleteAllSTATIS.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        deleteAllSTATIS.setForeground(java.awt.SystemColor.activeCaption);
        deleteAllSTATIS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/delete.png"))); // NOI18N
        deleteAllSTATIS.setText("Delete All Item MedRec Statis");
        deleteAllSTATIS.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.SystemColor.activeCaption, new java.awt.Color(255, 255, 255), java.awt.SystemColor.controlHighlight, java.awt.SystemColor.activeCaption));
        deleteAllSTATIS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteAllSTATISActionPerformed(evt);
            }
        });

        inputAllSTATIS.setBackground(new java.awt.Color(255, 255, 255));
        inputAllSTATIS.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        inputAllSTATIS.setForeground(java.awt.SystemColor.activeCaption);
        inputAllSTATIS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/save.png"))); // NOI18N
        inputAllSTATIS.setText("Input All Item MedRec Statis");
        inputAllSTATIS.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.SystemColor.activeCaption, new java.awt.Color(255, 255, 255), java.awt.SystemColor.controlHighlight, java.awt.SystemColor.activeCaption));
        inputAllSTATIS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputAllSTATISActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelAllCRUD_STATISLayout = new javax.swing.GroupLayout(panelAllCRUD_STATIS);
        panelAllCRUD_STATIS.setLayout(panelAllCRUD_STATISLayout);
        panelAllCRUD_STATISLayout.setHorizontalGroup(
            panelAllCRUD_STATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAllCRUD_STATISLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(getAllSTATIS, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(deleteAllSTATIS, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(inputAllSTATIS, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(470, Short.MAX_VALUE))
        );
        panelAllCRUD_STATISLayout.setVerticalGroup(
            panelAllCRUD_STATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelAllCRUD_STATISLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelAllCRUD_STATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(getAllSTATIS)
                    .addComponent(deleteAllSTATIS)
                    .addComponent(inputAllSTATIS))
                .addContainerGap())
        );

        jScrollPane_STATIS.setBorder(null);
        jScrollPane_STATIS.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        panelItemSTATIS.setBackground(new java.awt.Color(255, 255, 255));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel13.setText("Faktor Resiko                  :");

        dataFaktorResiko.setText("-");

        dataPenyakitBawaan.setText("-");

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel10.setText("Riwayat Penyakit Bawaan :");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel11.setText("Riwayat Penyakit Kronis    :");

        dataPenyakitKronis.setText("-");

        dataRawatRS.setText("-");

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel12.setText("Riwayat Rawat RS           :");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel6.setText("Riwayat Operasi              :");

        dataRiwayatOperasi.setText("-");

        dataGolongandarah.setText("-");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel5.setText("Golongan Darah              :");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Alergi                            :");

        dataAlergi.setText("-");

        fieldFaktorResiko.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldFaktorResiko.setText("--input--");
        fieldFaktorResiko.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldFaktorResikoActionPerformed(evt);
            }
        });

        fieldPenyakitBawaan.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldPenyakitBawaan.setText("--input--");
        fieldPenyakitBawaan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldPenyakitBawaanActionPerformed(evt);
            }
        });

        fieldPenyakitKronis.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldPenyakitKronis.setText("--input--");
        fieldPenyakitKronis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldPenyakitKronisActionPerformed(evt);
            }
        });

        fieldRawatRS.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldRawatRS.setText("--input--");
        fieldRawatRS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldRawatRSActionPerformed(evt);
            }
        });

        fieldRiwayatOperasi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldRiwayatOperasi.setText("--input--");
        fieldRiwayatOperasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldRiwayatOperasiActionPerformed(evt);
            }
        });

        ComboBoxGolongandarah.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. A+", "2. A-", "3. B+", "4. B-", "5. AB+", "6. AB-", "7. O+", "8. O-" }));
        ComboBoxGolongandarah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxGolongandarahActionPerformed(evt);
            }
        });

        fieldAlergi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fieldAlergi.setText("--input--");
        fieldAlergi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldAlergiActionPerformed(evt);
            }
        });

        inputAlergi.setText("Input");
        inputAlergi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputAlergi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputAlergiActionPerformed(evt);
            }
        });

        deleteAlergi.setText("Delete");
        deleteAlergi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteAlergi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteAlergiActionPerformed(evt);
            }
        });

        deleteGolongandarah.setText("Delete");
        deleteGolongandarah.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteGolongandarah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteGolongandarahActionPerformed(evt);
            }
        });

        inputGolongandarah.setText("Input");
        inputGolongandarah.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputGolongandarah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputGolongandarahActionPerformed(evt);
            }
        });

        inputRiwayatOperasi.setText("Input");
        inputRiwayatOperasi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputRiwayatOperasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputRiwayatOperasiActionPerformed(evt);
            }
        });

        deleteRiwayatOperasi.setText("Delete");
        deleteRiwayatOperasi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteRiwayatOperasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteRiwayatOperasiActionPerformed(evt);
            }
        });

        inputRawatRS.setText("Input");
        inputRawatRS.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputRawatRS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputRawatRSActionPerformed(evt);
            }
        });

        deleteRawatRS.setText("Delete");
        deleteRawatRS.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteRawatRS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteRawatRSActionPerformed(evt);
            }
        });

        inputPenyakitKronis.setText("Input");
        inputPenyakitKronis.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputPenyakitKronis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputPenyakitKronisActionPerformed(evt);
            }
        });

        deletePenyakitKronis.setText("Delete");
        deletePenyakitKronis.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletePenyakitKronis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePenyakitKronisActionPerformed(evt);
            }
        });

        inputPenyakitBawaan.setText("Input");
        inputPenyakitBawaan.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputPenyakitBawaan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputPenyakitBawaanActionPerformed(evt);
            }
        });

        deletePenyakitBawaan.setText("Delete");
        deletePenyakitBawaan.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deletePenyakitBawaan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePenyakitBawaanActionPerformed(evt);
            }
        });

        inputFaktorResiko.setText("Input");
        inputFaktorResiko.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        inputFaktorResiko.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputFaktorResikoActionPerformed(evt);
            }
        });

        deleteFaktorResiko.setText("Delete");
        deleteFaktorResiko.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        deleteFaktorResiko.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteFaktorResikoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelItemSTATISLayout = new javax.swing.GroupLayout(panelItemSTATIS);
        panelItemSTATIS.setLayout(panelItemSTATISLayout);
        panelItemSTATISLayout.setHorizontalGroup(
            panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelItemSTATISLayout.createSequentialGroup()
                .addContainerGap(921, Short.MAX_VALUE)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(inputFaktorResiko, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(inputPenyakitBawaan, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(inputPenyakitKronis, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(inputRawatRS, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(inputAlergi, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(inputRiwayatOperasi, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(inputGolongandarah, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(deletePenyakitBawaan, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(deletePenyakitKronis, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(deleteRawatRS, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(deleteRiwayatOperasi, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(deleteGolongandarah, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(deleteAlergi, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(deleteFaktorResiko, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE))
                .addGap(50, 50, 50))
            .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelItemSTATISLayout.createSequentialGroup()
                    .addGap(2, 2, 2)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(dataGolongandarah, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
                        .addComponent(dataRiwayatOperasi, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dataRawatRS, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dataPenyakitKronis, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dataPenyakitBawaan, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dataFaktorResiko, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dataAlergi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(fieldPenyakitBawaan, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(fieldPenyakitKronis, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(fieldRawatRS, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(fieldRiwayatOperasi, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(ComboBoxGolongandarah, javax.swing.GroupLayout.Alignment.LEADING, 0, 350, Short.MAX_VALUE)
                        .addComponent(fieldAlergi, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(fieldFaktorResiko))
                    .addContainerGap(166, Short.MAX_VALUE)))
        );
        panelItemSTATISLayout.setVerticalGroup(
            panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelItemSTATISLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputAlergi)
                    .addComponent(deleteAlergi))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputGolongandarah)
                    .addComponent(deleteGolongandarah))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputRiwayatOperasi)
                    .addComponent(deleteRiwayatOperasi))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputRawatRS)
                    .addComponent(deleteRawatRS))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputPenyakitKronis)
                    .addComponent(deletePenyakitKronis))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputPenyakitBawaan)
                    .addComponent(deletePenyakitBawaan))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputFaktorResiko)
                    .addComponent(deleteFaktorResiko))
                .addContainerGap(247, Short.MAX_VALUE))
            .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelItemSTATISLayout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(fieldAlergi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dataAlergi)))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5)
                        .addComponent(dataGolongandarah)
                        .addComponent(ComboBoxGolongandarah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel6)
                        .addComponent(dataRiwayatOperasi)
                        .addComponent(fieldRiwayatOperasi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(dataRawatRS)
                        .addComponent(fieldRawatRS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel11)
                        .addComponent(dataPenyakitKronis)
                        .addComponent(fieldPenyakitKronis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel10)
                        .addComponent(dataPenyakitBawaan)
                        .addComponent(fieldPenyakitBawaan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(panelItemSTATISLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel13)
                        .addComponent(dataFaktorResiko)
                        .addComponent(fieldFaktorResiko, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        jScrollPane_STATIS.setViewportView(panelItemSTATIS);

        javax.swing.GroupLayout RekamMedisStatisLayout = new javax.swing.GroupLayout(RekamMedisStatis);
        RekamMedisStatis.setLayout(RekamMedisStatisLayout);
        RekamMedisStatisLayout.setHorizontalGroup(
            RekamMedisStatisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RekamMedisStatisLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(RekamMedisStatisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(RekamMedisStatisLayout.createSequentialGroup()
                        .addComponent(panelAllCRUD_STATIS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane_STATIS, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
        );
        RekamMedisStatisLayout.setVerticalGroup(
            RekamMedisStatisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RekamMedisStatisLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane_STATIS, javax.swing.GroupLayout.DEFAULT_SIZE, 259, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelAllCRUD_STATIS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedAll.addTab("Rekam Medis Statis", new javax.swing.ImageIcon(getClass().getResource("/Icon/list.png")), RekamMedisStatis); // NOI18N

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelReaderCard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedAll, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jTabbedAll, javax.swing.GroupLayout.PREFERRED_SIZE, 378, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PanelReaderCard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panelOperationTitle, javax.swing.GroupLayout.DEFAULT_SIZE, 1113, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelOperationTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(1113, 569));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
//--INISIASI DATA
    public void InisiasiData(){
    //--DATA DIRI
	// HubKeluarga
	symbolHubKeluarga[0] = "1. Orang Tua";
	symbolHubKeluarga[1] = "2. Kakek Nenek";
	symbolHubKeluarga[2] = "3. Anak";
	symbolHubKeluarga[3] = "4. Saudara Kandung";
	symbolHubKeluarga[4] = "5. Saudara Ayah";
	symbolHubKeluarga[5] = "6. Saudara Ibu";
	symbolHubKeluarga[6] = "7. Suami/Istri";

	// RT
	symbolRT[0] = "1. RT1";
	symbolRT[1] = "2. RT2";
	symbolRT[2] = "3. RT3";
	symbolRT[3] = "4. RT4";
	symbolRT[4] = "5. RT5";
	symbolRT[5] = "6. RT6";
	symbolRT[6] = "7. RT7";
	symbolRT[7] = "8. RT8";
	symbolRT[8] = "9. RT9";
	symbolRT[9] = "10. RT10";
	symbolRT[10] = "11. RT11";
	symbolRT[11] = "12. RT12";
	symbolRT[12] = "13. RT13";
	symbolRT[13] = "14. RT14";
	symbolRT[14] = "15. RT15";
	symbolRT[15] = "16. RT16";
	symbolRT[16] = "17. RT17";
	symbolRT[17] = "18. RT18";
	symbolRT[18] = "19. RT19";
	symbolRT[19] = "20. RT20";
	symbolRT[20] = "21. RT21";
	symbolRT[21] = "22. RT22";
	symbolRT[22] = "23. RT23";
	symbolRT[23] = "24. RT24";
	symbolRT[24] = "25. RT25";
	symbolRT[25] = "26. RT26";
	symbolRT[26] = "27. RT27";
	symbolRT[27] = "28. RT28";
	symbolRT[28] = "29. RT29";
	symbolRT[29] = "30. RT30";
	// RW
	symbolRW[0] = "1. RW1";
	symbolRW[1] = "2. RW2";
	symbolRW[2] = "3. RW3";
	symbolRW[3] = "4. RW4";
	symbolRW[4] = "5. RW5";
	symbolRW[5] = "6. RW6";
	symbolRW[6] = "7. RW7";
	symbolRW[7] = "8. RW8";
	symbolRW[8] = "9. RW9";
	symbolRW[9] = "10. RW10";
	symbolRW[10] = "11. RW11";
	symbolRW[11] = "12. RW12";
	symbolRW[12] = "13. RW13";
	symbolRW[13] = "14. RW14";
	symbolRW[14] = "15. RW15";
	symbolRW[15] = "16. RW16";
	symbolRW[16] = "17. RW17";
	symbolRW[17] = "18. RW18";
	symbolRW[18] = "19. RW19";
	symbolRW[19] = "20. RW20";
	symbolRW[20] = "21. RW21";
	symbolRW[21] = "22. RW22";
	symbolRW[22] = "23. RW23";
	symbolRW[23] = "24. RW24";
	symbolRW[24] = "25. RW25";
	symbolRW[25] = "26. RW26";
	symbolRW[26] = "27. RW27";
	symbolRW[27] = "28. RW28";
	symbolRW[28] = "29. RW29";
	symbolRW[29] = "30. RW30";
	// KelurahanPasien
	symbolKelurahanPasien[0] = "1. KelurahanPasien1";
	symbolKelurahanPasien[1] = "2. KelurahanPasien2";
	symbolKelurahanPasien[2] = "3. KelurahanPasien3";
	symbolKelurahanPasien[3] = "4. KelurahanPasien4";
	symbolKelurahanPasien[4] = "5. KelurahanPasien5";
	symbolKelurahanPasien[5] = "6. KelurahanPasien6";
	symbolKelurahanPasien[6] = "7. KelurahanPasien7";
	symbolKelurahanPasien[7] = "8. KelurahanPasien8";
	symbolKelurahanPasien[8] = "9. KelurahanPasien9";
	symbolKelurahanPasien[9] = "10. KelurahanPasien10";
	symbolKelurahanPasien[10] = "11. KelurahanPasien11";
	symbolKelurahanPasien[11] = "12. KelurahanPasien12";
	symbolKelurahanPasien[12] = "13. KelurahanPasien13";
	symbolKelurahanPasien[13] = "14. KelurahanPasien14";
	symbolKelurahanPasien[14] = "15. KelurahanPasien15";
	symbolKelurahanPasien[15] = "16. KelurahanPasien16";
	symbolKelurahanPasien[16] = "17. KelurahanPasien17";
	symbolKelurahanPasien[17] = "18. KelurahanPasien18";
	symbolKelurahanPasien[18] = "19. KelurahanPasien19";
	symbolKelurahanPasien[19] = "20. KelurahanPasien20";
	symbolKelurahanPasien[20] = "21. KelurahanPasien21";
	symbolKelurahanPasien[21] = "22. KelurahanPasien22";
	symbolKelurahanPasien[22] = "23. KelurahanPasien23";
	symbolKelurahanPasien[23] = "24. KelurahanPasien24";
	symbolKelurahanPasien[24] = "25. KelurahanPasien25";
	symbolKelurahanPasien[25] = "26. KelurahanPasien26";
	symbolKelurahanPasien[26] = "27. KelurahanPasien27";
	symbolKelurahanPasien[27] = "28. KelurahanPasien28";
	symbolKelurahanPasien[28] = "29. KelurahanPasien29";
	symbolKelurahanPasien[29] = "30. KelurahanPasien30";
	// KecamatanPasien
	symbolKecamatanPasien[0] = "1. KecamatanPasien1";
	symbolKecamatanPasien[1] = "2. KecamatanPasien2";
	symbolKecamatanPasien[2] = "3. KecamatanPasien3";
	symbolKecamatanPasien[3] = "4. KecamatanPasien4";
	symbolKecamatanPasien[4] = "5. KecamatanPasien5";
	symbolKecamatanPasien[5] = "6. KecamatanPasien6";
	symbolKecamatanPasien[6] = "7. KecamatanPasien7";
	symbolKecamatanPasien[7] = "8. KecamatanPasien8";
	symbolKecamatanPasien[8] = "9. KecamatanPasien9";
	symbolKecamatanPasien[9] = "10. KecamatanPasien10";
	symbolKecamatanPasien[10] = "11. KecamatanPasien11";
	symbolKecamatanPasien[11] = "12. KecamatanPasien12";
	symbolKecamatanPasien[12] = "13. KecamatanPasien13";
	symbolKecamatanPasien[13] = "14. KecamatanPasien14";
	symbolKecamatanPasien[14] = "15. KecamatanPasien15";
	symbolKecamatanPasien[15] = "16. KecamatanPasien16";
	symbolKecamatanPasien[16] = "17. KecamatanPasien17";
	symbolKecamatanPasien[17] = "18. KecamatanPasien18";
	symbolKecamatanPasien[18] = "19. KecamatanPasien19";
	symbolKecamatanPasien[19] = "20. KecamatanPasien20";
	symbolKecamatanPasien[20] = "21. KecamatanPasien21";
	symbolKecamatanPasien[21] = "22. KecamatanPasien22";
	symbolKecamatanPasien[22] = "23. KecamatanPasien23";
	symbolKecamatanPasien[23] = "24. KecamatanPasien24";
	symbolKecamatanPasien[24] = "25. KecamatanPasien25";
	symbolKecamatanPasien[25] = "26. KecamatanPasien26";
	symbolKecamatanPasien[26] = "27. KecamatanPasien27";
	symbolKecamatanPasien[27] = "28. KecamatanPasien28";
	symbolKecamatanPasien[28] = "29. KecamatanPasien29";
	symbolKecamatanPasien[29] = "30. KecamatanPasien30";
	// KotaPasien
	symbolKotaPasien[0] = "1. KotaPasien1";
	symbolKotaPasien[1] = "2. KotaPasien2";
	symbolKotaPasien[2] = "3. KotaPasien3";
	symbolKotaPasien[3] = "4. KotaPasien4";
	symbolKotaPasien[4] = "5. KotaPasien5";
	symbolKotaPasien[5] = "6. KotaPasien6";
	symbolKotaPasien[6] = "7. KotaPasien7";
	symbolKotaPasien[7] = "8. KotaPasien8";
	symbolKotaPasien[8] = "9. KotaPasien9";
	symbolKotaPasien[9] = "10. KotaPasien10";
	symbolKotaPasien[10] = "11. KotaPasien11";
	symbolKotaPasien[11] = "12. KotaPasien12";
	symbolKotaPasien[12] = "13. KotaPasien13";
	symbolKotaPasien[13] = "14. KotaPasien14";
	symbolKotaPasien[14] = "15. KotaPasien15";
	symbolKotaPasien[15] = "16. KotaPasien16";
	symbolKotaPasien[16] = "17. KotaPasien17";
	symbolKotaPasien[17] = "18. KotaPasien18";
	symbolKotaPasien[18] = "19. KotaPasien19";
	symbolKotaPasien[19] = "20. KotaPasien20";
	symbolKotaPasien[20] = "21. KotaPasien21";
	symbolKotaPasien[21] = "22. KotaPasien22";
	symbolKotaPasien[22] = "23. KotaPasien23";
	symbolKotaPasien[23] = "24. KotaPasien24";
	symbolKotaPasien[24] = "25. KotaPasien25";
	symbolKotaPasien[25] = "26. KotaPasien26";
	symbolKotaPasien[26] = "27. KotaPasien27";
	symbolKotaPasien[27] = "28. KotaPasien28";
	symbolKotaPasien[28] = "29. KotaPasien29";
	symbolKotaPasien[29] = "30. KotaPasien30";
	// PropinsiPasien
	symbolPropinsiPasien[0] = "1. PropinsiPasien1";
	symbolPropinsiPasien[1] = "2. PropinsiPasien2";
	symbolPropinsiPasien[2] = "3. PropinsiPasien3";
	symbolPropinsiPasien[3] = "4. PropinsiPasien4";
	symbolPropinsiPasien[4] = "5. PropinsiPasien5";
	symbolPropinsiPasien[5] = "6. PropinsiPasien6";
	symbolPropinsiPasien[6] = "7. PropinsiPasien7";
	symbolPropinsiPasien[7] = "8. PropinsiPasien8";
	symbolPropinsiPasien[8] = "9. PropinsiPasien9";
	symbolPropinsiPasien[9] = "10. PropinsiPasien10";
	symbolPropinsiPasien[10] = "11. PropinsiPasien11";
	symbolPropinsiPasien[11] = "12. PropinsiPasien12";
	symbolPropinsiPasien[12] = "13. PropinsiPasien13";
	symbolPropinsiPasien[13] = "14. PropinsiPasien14";
	symbolPropinsiPasien[14] = "15. PropinsiPasien15";
	symbolPropinsiPasien[15] = "16. PropinsiPasien16";
	symbolPropinsiPasien[16] = "17. PropinsiPasien17";
	symbolPropinsiPasien[17] = "18. PropinsiPasien18";
	symbolPropinsiPasien[18] = "19. PropinsiPasien19";
	symbolPropinsiPasien[19] = "20. PropinsiPasien20";
	symbolPropinsiPasien[20] = "21. PropinsiPasien21";
	symbolPropinsiPasien[21] = "22. PropinsiPasien22";
	symbolPropinsiPasien[22] = "23. PropinsiPasien23";
	symbolPropinsiPasien[23] = "24. PropinsiPasien24";
	symbolPropinsiPasien[24] = "25. PropinsiPasien25";
	symbolPropinsiPasien[25] = "26. PropinsiPasien26";
	symbolPropinsiPasien[26] = "27. PropinsiPasien27";
	symbolPropinsiPasien[27] = "28. PropinsiPasien28";
	symbolPropinsiPasien[28] = "29. PropinsiPasien29";
	symbolPropinsiPasien[29] = "30. PropinsiPasien30";
	symbolPropinsiPasien[30] = "31. PropinsiPasien31";
	symbolPropinsiPasien[31] = "32. PropinsiPasien32";
	symbolPropinsiPasien[32] = "33. PropinsiPasien33";
	symbolPropinsiPasien[33] = "34. PropinsiPasien34";
	// WilayahKerja
	symbolWilayahKerja[0] = "1. Didalam";
	symbolWilayahKerja[1] = "2. Diluar";
	// JenisKelaminPasien
	symbolJenisKelaminPasien[0] = "1. Pria";
	symbolJenisKelaminPasien[1] = "2. Wanita";
	// AgamaPasien
	symbolAgamaPasien[0] = "1. Islam";
	symbolAgamaPasien[1] = "2. Kristen (Protestan)";
	symbolAgamaPasien[2] = "3. Hindu";
	symbolAgamaPasien[3] = "4. Budha";
	symbolAgamaPasien[4] = "5. Katolik";
	symbolAgamaPasien[5] = "6. Konghucu";
	// PendidikanPasien
	symbolPendidikanPasien[0] = "1. Tidak Sekolah";
	symbolPendidikanPasien[1] = "2. Belum/Tidak Tamat SD";
	symbolPendidikanPasien[2] = "3. Tamat SD";
	symbolPendidikanPasien[3] = "4. Tamat SMP";
	symbolPendidikanPasien[4] = "5. Tamat SMA";
	symbolPendidikanPasien[5] = "6. Tamat Diploma";
	symbolPendidikanPasien[6] = "7. tamat S1";
	// PekerjaanPasien
	symbolPekerjaanPasien[0] = "1. PNS";
	symbolPekerjaanPasien[1] = "2. TNI/POLRI";
	symbolPekerjaanPasien[2] = "3. Pensiunan";
	symbolPekerjaanPasien[3] = "4. Swasta";
	symbolPekerjaanPasien[4] = "5. Pedagang";
	symbolPekerjaanPasien[5] = "6. Nelayan";
	symbolPekerjaanPasien[6] = "7. Petani";
	symbolPekerjaanPasien[7] = "8. Pekerja Lepas/Wiraswasta";
	symbolPekerjaanPasien[8] = "9. Ibu Rumah Tangga";
	symbolPekerjaanPasien[9] = "10. Pelajar";
	symbolPekerjaanPasien[10] = "11. Mahasiswa";
	symbolPekerjaanPasien[11] = "12. Dibawah Umur";
	symbolPekerjaanPasien[12] = "13. Tidak bekerja";
	// StatusPerkawinanPasien
	symbolStatusPerkawinanPasien[0] = "1. Menikah";
	symbolStatusPerkawinanPasien[1] = "2. Belum Menikah";
	symbolStatusPerkawinanPasien[2] = "3. Janda/Duda";
	// KewarganegaraanPasien
	symbolKewarganegaraanPasien[0] = "1. WNI";
	symbolKewarganegaraanPasien[1] = "2. WNA";
	// Hubungan
	symbolHubungan[0] = "1. Orang Tua";
	symbolHubungan[1] = "2. Kakek Nenek";
	symbolHubungan[2] = "3. Anak";
	symbolHubungan[3] = "4. Saudara Kandung";
	symbolHubungan[4] = "5. Saudara Ayah";
	symbolHubungan[5] = "6. Saudara Ibu";
	symbolHubungan[6] = "7. Suami/Istri";
	// KelurahanKeluarga
	symbolKelurahanKeluarga[0] = "1. KelurahanKeluarga1";
	symbolKelurahanKeluarga[1] = "2. KelurahanKeluarga2";
	symbolKelurahanKeluarga[2] = "3. KelurahanKeluarga3";
	symbolKelurahanKeluarga[3] = "4. KelurahanKeluarga4";
	symbolKelurahanKeluarga[4] = "5. KelurahanKeluarga5";
	symbolKelurahanKeluarga[5] = "6. KelurahanKeluarga6";
	symbolKelurahanKeluarga[6] = "7. KelurahanKeluarga7";
	symbolKelurahanKeluarga[7] = "8. KelurahanKeluarga8";
	symbolKelurahanKeluarga[8] = "9. KelurahanKeluarga9";
	symbolKelurahanKeluarga[9] = "10. KelurahanKeluarga10";
	symbolKelurahanKeluarga[10] = "11. KelurahanKeluarga11";
	symbolKelurahanKeluarga[11] = "12. KelurahanKeluarga12";
	symbolKelurahanKeluarga[12] = "13. KelurahanKeluarga13";
	symbolKelurahanKeluarga[13] = "14. KelurahanKeluarga14";
	symbolKelurahanKeluarga[14] = "15. KelurahanKeluarga15";
	symbolKelurahanKeluarga[15] = "16. KelurahanKeluarga16";
	symbolKelurahanKeluarga[16] = "17. KelurahanKeluarga17";
	symbolKelurahanKeluarga[17] = "18. KelurahanKeluarga18";
	symbolKelurahanKeluarga[18] = "19. KelurahanKeluarga19";
	symbolKelurahanKeluarga[19] = "20. KelurahanKeluarga20";
	symbolKelurahanKeluarga[20] = "21. KelurahanKeluarga21";
	symbolKelurahanKeluarga[21] = "22. KelurahanKeluarga22";
	symbolKelurahanKeluarga[22] = "23. KelurahanKeluarga23";
	symbolKelurahanKeluarga[23] = "24. KelurahanKeluarga24";
	symbolKelurahanKeluarga[24] = "25. KelurahanKeluarga25";
	symbolKelurahanKeluarga[25] = "26. KelurahanKeluarga26";
	symbolKelurahanKeluarga[26] = "27. KelurahanKeluarga27";
	symbolKelurahanKeluarga[27] = "28. KelurahanKeluarga28";
	symbolKelurahanKeluarga[28] = "29. KelurahanKeluarga29";
	symbolKelurahanKeluarga[29] = "30. KelurahanKeluarga30";
	// KecamatanKeluarga
	symbolKecamatanKeluarga[0] = "1. KecamatanKeluarga1";
	symbolKecamatanKeluarga[1] = "2. KecamatanKeluarga2";
	symbolKecamatanKeluarga[2] = "3. KecamatanKeluarga3";
	symbolKecamatanKeluarga[3] = "4. KecamatanKeluarga4";
	symbolKecamatanKeluarga[4] = "5. KecamatanKeluarga5";
	symbolKecamatanKeluarga[5] = "6. KecamatanKeluarga6";
	symbolKecamatanKeluarga[6] = "7. KecamatanKeluarga7";
	symbolKecamatanKeluarga[7] = "8. KecamatanKeluarga8";
	symbolKecamatanKeluarga[8] = "9. KecamatanKeluarga9";
	symbolKecamatanKeluarga[9] = "10. KecamatanKeluarga10";
	symbolKecamatanKeluarga[10] = "11. KecamatanKeluarga11";
	symbolKecamatanKeluarga[11] = "12. KecamatanKeluarga12";
	symbolKecamatanKeluarga[12] = "13. KecamatanKeluarga13";
	symbolKecamatanKeluarga[13] = "14. KecamatanKeluarga14";
	symbolKecamatanKeluarga[14] = "15. KecamatanKeluarga15";
	symbolKecamatanKeluarga[15] = "16. KecamatanKeluarga16";
	symbolKecamatanKeluarga[16] = "17. KecamatanKeluarga17";
	symbolKecamatanKeluarga[17] = "18. KecamatanKeluarga18";
	symbolKecamatanKeluarga[18] = "19. KecamatanKeluarga19";
	symbolKecamatanKeluarga[19] = "20. KecamatanKeluarga20";
	symbolKecamatanKeluarga[20] = "21. KecamatanKeluarga21";
	symbolKecamatanKeluarga[21] = "22. KecamatanKeluarga22";
	symbolKecamatanKeluarga[22] = "23. KecamatanKeluarga23";
	symbolKecamatanKeluarga[23] = "24. KecamatanKeluarga24";
	symbolKecamatanKeluarga[24] = "25. KecamatanKeluarga25";
	symbolKecamatanKeluarga[25] = "26. KecamatanKeluarga26";
	symbolKecamatanKeluarga[26] = "27. KecamatanKeluarga27";
	symbolKecamatanKeluarga[27] = "28. KecamatanKeluarga28";
	symbolKecamatanKeluarga[28] = "29. KecamatanKeluarga29";
	symbolKecamatanKeluarga[29] = "30. KecamatanKeluarga30";
	// KotaKeluarga
	symbolKotaKeluarga[0] = "1. KotaKeluarga1";
	symbolKotaKeluarga[1] = "2. KotaKeluarga2";
	symbolKotaKeluarga[2] = "3. KotaKeluarga3";
	symbolKotaKeluarga[3] = "4. KotaKeluarga4";
	symbolKotaKeluarga[4] = "5. KotaKeluarga5";
	symbolKotaKeluarga[5] = "6. KotaKeluarga6";
	symbolKotaKeluarga[6] = "7. KotaKeluarga7";
	symbolKotaKeluarga[7] = "8. KotaKeluarga8";
	symbolKotaKeluarga[8] = "9. KotaKeluarga9";
	symbolKotaKeluarga[9] = "10. KotaKeluarga10";
	symbolKotaKeluarga[10] = "11. KotaKeluarga11";
	symbolKotaKeluarga[11] = "12. KotaKeluarga12";
	symbolKotaKeluarga[12] = "13. KotaKeluarga13";
	symbolKotaKeluarga[13] = "14. KotaKeluarga14";
	symbolKotaKeluarga[14] = "15. KotaKeluarga15";
	symbolKotaKeluarga[15] = "16. KotaKeluarga16";
	symbolKotaKeluarga[16] = "17. KotaKeluarga17";
	symbolKotaKeluarga[17] = "18. KotaKeluarga18";
	symbolKotaKeluarga[18] = "19. KotaKeluarga19";
	symbolKotaKeluarga[19] = "20. KotaKeluarga20";
	symbolKotaKeluarga[20] = "21. KotaKeluarga21";
	symbolKotaKeluarga[21] = "22. KotaKeluarga22";
	symbolKotaKeluarga[22] = "23. KotaKeluarga23";
	symbolKotaKeluarga[23] = "24. KotaKeluarga24";
	symbolKotaKeluarga[24] = "25. KotaKeluarga25";
	symbolKotaKeluarga[25] = "26. KotaKeluarga26";
	symbolKotaKeluarga[26] = "27. KotaKeluarga27";
	symbolKotaKeluarga[27] = "28. KotaKeluarga28";
	symbolKotaKeluarga[28] = "29. KotaKeluarga29";
	symbolKotaKeluarga[29] = "30. KotaKeluarga30";
	// PropinsiKeluarga
	symbolPropinsiKeluarga[0] = "1. PropinsiKeluarga1";
	symbolPropinsiKeluarga[1] = "2. PropinsiKeluarga2";
	symbolPropinsiKeluarga[2] = "3. PropinsiKeluarga3";
	symbolPropinsiKeluarga[3] = "4. PropinsiKeluarga4";
	symbolPropinsiKeluarga[4] = "5. PropinsiKeluarga5";
	symbolPropinsiKeluarga[5] = "6. PropinsiKeluarga6";
	symbolPropinsiKeluarga[6] = "7. PropinsiKeluarga7";
	symbolPropinsiKeluarga[7] = "8. PropinsiKeluarga8";
	symbolPropinsiKeluarga[8] = "9. PropinsiKeluarga9";
	symbolPropinsiKeluarga[9] = "10. PropinsiKeluarga10";
	symbolPropinsiKeluarga[10] = "11. PropinsiKeluarga11";
	symbolPropinsiKeluarga[11] = "12. PropinsiKeluarga12";
	symbolPropinsiKeluarga[12] = "13. PropinsiKeluarga13";
	symbolPropinsiKeluarga[13] = "14. PropinsiKeluarga14";
	symbolPropinsiKeluarga[14] = "15. PropinsiKeluarga15";
	symbolPropinsiKeluarga[15] = "16. PropinsiKeluarga16";
	symbolPropinsiKeluarga[16] = "17. PropinsiKeluarga17";
	symbolPropinsiKeluarga[17] = "18. PropinsiKeluarga18";
	symbolPropinsiKeluarga[18] = "19. PropinsiKeluarga19";
	symbolPropinsiKeluarga[19] = "20. PropinsiKeluarga20";
	symbolPropinsiKeluarga[20] = "21. PropinsiKeluarga21";
	symbolPropinsiKeluarga[21] = "22. PropinsiKeluarga22";
	symbolPropinsiKeluarga[22] = "23. PropinsiKeluarga23";
	symbolPropinsiKeluarga[23] = "24. PropinsiKeluarga24";
	symbolPropinsiKeluarga[24] = "25. PropinsiKeluarga25";
	symbolPropinsiKeluarga[25] = "26. PropinsiKeluarga26";
	symbolPropinsiKeluarga[26] = "27. PropinsiKeluarga27";
	symbolPropinsiKeluarga[27] = "28. PropinsiKeluarga28";
	symbolPropinsiKeluarga[28] = "29. PropinsiKeluarga29";
	symbolPropinsiKeluarga[29] = "30. PropinsiKeluarga30";
	symbolPropinsiKeluarga[30] = "31. PropinsiKeluarga31";
	symbolPropinsiKeluarga[31] = "32. PropinsiKeluarga32";
	symbolPropinsiKeluarga[32] = "33. PropinsiKeluarga33";
	symbolPropinsiKeluarga[33] = "34. PropinsiKeluarga34";
	// KotaKantor
	symbolKotaKantor[0] = "1. KotaKantor1";
	symbolKotaKantor[1] = "2. KotaKantor2";
	symbolKotaKantor[2] = "3. KotaKantor3";
	symbolKotaKantor[3] = "4. KotaKantor4";
	symbolKotaKantor[4] = "5. KotaKantor5";
	symbolKotaKantor[5] = "6. KotaKantor6";
	symbolKotaKantor[6] = "7. KotaKantor7";
	symbolKotaKantor[7] = "8. KotaKantor8";
	symbolKotaKantor[8] = "9. KotaKantor9";
	symbolKotaKantor[9] = "10. KotaKantor10";
	symbolKotaKantor[10] = "11. KotaKantor11";
	symbolKotaKantor[11] = "12. KotaKantor12";
	symbolKotaKantor[12] = "13. KotaKantor13";
	symbolKotaKantor[13] = "14. KotaKantor14";
	symbolKotaKantor[14] = "15. KotaKantor15";
	symbolKotaKantor[15] = "16. KotaKantor16";
	symbolKotaKantor[16] = "17. KotaKantor17";
	symbolKotaKantor[17] = "18. KotaKantor18";
	symbolKotaKantor[18] = "19. KotaKantor19";
	symbolKotaKantor[19] = "20. KotaKantor20";
	symbolKotaKantor[20] = "21. KotaKantor21";
	symbolKotaKantor[21] = "22. KotaKantor22";
	symbolKotaKantor[22] = "23. KotaKantor23";
	symbolKotaKantor[23] = "24. KotaKantor24";
	symbolKotaKantor[24] = "25. KotaKantor25";
	symbolKotaKantor[25] = "26. KotaKantor26";
	symbolKotaKantor[26] = "27. KotaKantor27";
	symbolKotaKantor[27] = "28. KotaKantor28";
	symbolKotaKantor[28] = "29. KotaKantor29";
	symbolKotaKantor[29] = "30. KotaKantor30";

	//STATIS
	// Golongandarah
	symbolGolongandarah[0] = "1. Golongandarah1";
	symbolGolongandarah[1] = "2. Golongandarah2";
	symbolGolongandarah[2] = "3. Golongandarah3";
	symbolGolongandarah[3] = "4. Golongandarah4";
	symbolGolongandarah[4] = "5. Golongandarah5";
	symbolGolongandarah[5] = "6. Golongandarah6";
	symbolGolongandarah[6] = "7. Golongandarah7";
	symbolGolongandarah[7] = "8. Golongandarah8";

	//DINAMIS
	
	// Kesadaran
	symbolKesadaran[0] = "1. sama sekali tidak ada respons terhadap rangsang nyeri.";
	symbolKesadaran[1] = "2. seluruh tubuh pasien kaku, sehingga respons yang diberikan terhadap rangsang nyeri hampir tidak ada.";
	symbolKesadaran[2] = "3. tubuh pasien menekuk dengan kaku, sehingga hanya bergerak sedikit saat memperoleh rangsang nyeri.";
	symbolKesadaran[3] = "4. pasien bisa bergerak secara refleks menjauhi sumber rangsang nyeri.";
	symbolKesadaran[4] = "5. pasien bisa bergerak secara terkontrol apabila memperoleh rangsang nyeri.";
	symbolKesadaran[5] = "6. pasien dapat melakukan gerakan sesuai arahan.";
	
	// LabExecuteFlag
	symbolLabExecuteFlag[0] = "1. Dilayani penuh";
	symbolLabExecuteFlag[1] = "2. Tidak Dilayani sama sekali";
	symbolLabExecuteFlag[2] = "3. Dilayani sebagian";
	// EksekusiResep
	symbolEksekusiResep[0] = "1. Dilayani penuh";
	symbolEksekusiResep[1] = "2. Tidak Dilayani sama sekali";
	symbolEksekusiResep[2] = "3. Dilayani sebagian";
	symbolEksekusiResep[3] = "4. Dilayani, ada penggantian";
	symbolEksekusiResep[4] = "5. Dilayani sebagian dan ada penggantian";
	// Repetisiresep
	symbolRepetisiresep[0] = "1. Repetisiresep1";
	symbolRepetisiresep[1] = "2. Repetisiresep2";
	symbolRepetisiresep[2] = "3. Repetisiresep3";
	symbolRepetisiresep[3] = "4. Repetisiresep4";
	symbolRepetisiresep[4] = "5. Repetisiresep5";
	// Prognosa
	symbolPrognosa[0] = "1. Ad functionam :ad bonam";
	symbolPrognosa[1] = "2. Ad functionam :dubia ad bonam";
	symbolPrognosa[2] = "3. Ad functionam :dubia ad malam";
	symbolPrognosa[3] = "4. Ad functionam :ad malam";
	symbolPrognosa[4] = "5. Ad vitam :ad bonam";
	symbolPrognosa[5] = "6. Ad vitam :dubia ad bonam";
	symbolPrognosa[6] = "7. Ad vitam :dubia ad malam";
	symbolPrognosa[7] = "8. Ad vitam :ad malam";
    //--STATIS
        //Golongan Darah
        symbolGolongandarah[0] = "1. A+";
        symbolGolongandarah[1] = "2. A-";
        symbolGolongandarah[2] = "3. B+";
        symbolGolongandarah[3] = "4. B-";
        symbolGolongandarah[4] = "5. AB+";
        symbolGolongandarah[5] = "6. AB-";
        symbolGolongandarah[6] = "7. O+";
        symbolGolongandarah[7] = "8. O-";
    //--DINAMIS
    // Kesadaran
	symbolKesadaran[0] = "1. sama sekali tidak ada respons terhadap rangsang nyeri.";
	symbolKesadaran[1] = "2. seluruh tubuh pasien kaku, sehingga respons yang diberikan terhadap rangsang nyeri hampir tidak ada.";
	symbolKesadaran[2] = "3. tubuh pasien menekuk dengan kaku, sehingga hanya bergerak sedikit saat memperoleh rangsang nyeri.";
	symbolKesadaran[3] = "4. pasien bisa bergerak secara refleks menjauhi sumber rangsang nyeri.";
	symbolKesadaran[4] = "5. pasien bisa bergerak secara terkontrol apabila memperoleh rangsang nyeri.";
	symbolKesadaran[5] = "6. pasien dapat melakukan gerakan sesuai arahan.";
	
	// LabExecuteFlag
	symbolLabExecuteFlag[0] = "1. Dilayani penuh";
	symbolLabExecuteFlag[1] = "2. Tidak Dilayani sama sekali";
	symbolLabExecuteFlag[2] = "3. Dilayani sebagian";
	// EksekusiResep
	symbolEksekusiResep[0] = "1. Dilayani penuh";
	symbolEksekusiResep[1] = "2. Tidak Dilayani sama sekali";
	symbolEksekusiResep[2] = "3. Dilayani sebagian";
	symbolEksekusiResep[3] = "4. Dilayani, ada penggantian";
	symbolEksekusiResep[4] = "5. Dilayani sebagian dan ada penggantian";
	// Repetisiresep
	symbolRepetisiresep[0] = "1. Repetisiresep1";
	symbolRepetisiresep[1] = "2. Repetisiresep2";
	symbolRepetisiresep[2] = "3. Repetisiresep3";
	symbolRepetisiresep[3] = "4. Repetisiresep4";
	symbolRepetisiresep[4] = "5. Repetisiresep5";
	// Prognosa
	symbolPrognosa[0] = "1. Ad functionam :ad bonam";
	symbolPrognosa[1] = "2. Ad functionam :dubia ad bonam";
	symbolPrognosa[2] = "3. Ad functionam :dubia ad malam";
	symbolPrognosa[3] = "4. Ad functionam :ad malam";
	symbolPrognosa[4] = "5. Ad vitam :ad bonam";
	symbolPrognosa[5] = "6. Ad vitam :dubia ad bonam";
	symbolPrognosa[6] = "7. Ad vitam :dubia ad malam";
	symbolPrognosa[7] = "8. Ad vitam :ad malam";
    }
   
    private void btnLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogOutActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_btnLogOutActionPerformed


    private void fieldNoSCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldNoSCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldNoSCActionPerformed

    private void fieldKategoriPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldKategoriPasienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldKategoriPasienActionPerformed

    private void fieldNoAsuransiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldNoAsuransiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldNoAsuransiActionPerformed

    private void fieldTanggalDaftarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldTanggalDaftarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldTanggalDaftarActionPerformed

    private void fieldNamaPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldNamaPasienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldNamaPasienActionPerformed

    private void fieldNamaKKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldNamaKKActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldNamaKKActionPerformed

    private void fieldAlamatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldAlamatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldAlamatActionPerformed

    private void fieldKodePosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldKodePosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldKodePosActionPerformed

    private void fieldTempatLahirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldTempatLahirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldTempatLahirActionPerformed

    private void fieldTanggalLahirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldTanggalLahirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldTanggalLahirActionPerformed

    private void fieldTeleponPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldTeleponPasienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldTeleponPasienActionPerformed

    private void fieldHPPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldHPPasienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldHPPasienActionPerformed

    private void fieldKTPPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldKTPPasienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldKTPPasienActionPerformed

    private void fieldEmailPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldEmailPasienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldEmailPasienActionPerformed

    private void fieldNamaKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldNamaKeluargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldNamaKeluargaActionPerformed

    private void fieldAlamatKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldAlamatKeluargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldAlamatKeluargaActionPerformed

    private void fieldTeleponKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldTeleponKeluargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldTeleponKeluargaActionPerformed

    private void fieldHPKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldHPKeluargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldHPKeluargaActionPerformed

    private void fieldNamaKantorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldNamaKantorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldNamaKantorActionPerformed

    private void fieldAlamatKantorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldAlamatKantorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldAlamatKantorActionPerformed

    private void fieldTeleponKantor1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldTeleponKantor1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldTeleponKantor1ActionPerformed

    private void fieldHPKantor1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldHPKantor1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldHPKantor1ActionPerformed

    private void deleteHubunganActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteHubunganActionPerformed
	deleteText( indeksHubungan, dataHubungan, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteHubunganActionPerformed

    private void inputAlamatKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputAlamatKeluargaActionPerformed
	data_StringAlamatKeluarga = this.fieldAlamatKeluarga.getText();
	inputDATA( data_StringAlamatKeluarga, TEXT, indeksAlamatKeluarga, CLAText);
	getDATA( indeksAlamatKeluarga, false, null, dataAlamatKeluarga, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputAlamatKeluargaActionPerformed

    private void getAllSTATISActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getAllSTATISActionPerformed
        //STATIS
        getDATA( indeksAlergi, false, null, dataAlergi, CLAText);
        getDATA( indeksGolongandarah, true, symbolGolongandarah, dataGolongandarah, CLANum);
        getDATA( indeksRiwayatOperasi, false, null, dataRiwayatOperasi, CLAText);
        getDATA( indeksRawatRS, false, null, dataRawatRS, CLAText);
        getDATA( indeksPenyakitKronis, false, null, dataPenyakitKronis, CLAText);
        getDATA( indeksPenyakitBawaan, false, null, dataPenyakitBawaan, CLAText);
        getDATA( indeksFaktorResiko, false, null, dataFaktorResiko, CLAText);
        // TODO add your handling code here:
    }//GEN-LAST:event_getAllSTATISActionPerformed

    private void deleteAllSTATISActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteAllSTATISActionPerformed
        deleteAllStatis();
    }//GEN-LAST:event_deleteAllSTATISActionPerformed

    private void inputAllSTATISActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputAllSTATISActionPerformed
        inputAllSTATIS();  // TODO add your handling code here:
    }//GEN-LAST:event_inputAllSTATISActionPerformed

    private void fieldFaktorResikoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldFaktorResikoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldFaktorResikoActionPerformed

    private void fieldPenyakitBawaanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldPenyakitBawaanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldPenyakitBawaanActionPerformed

    private void fieldPenyakitKronisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldPenyakitKronisActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldPenyakitKronisActionPerformed

    private void fieldRawatRSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldRawatRSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldRawatRSActionPerformed

    private void fieldRiwayatOperasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldRiwayatOperasiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldRiwayatOperasiActionPerformed

    private void ComboBoxGolongandarahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxGolongandarahActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxGolongandarahActionPerformed

    private void fieldAlergiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldAlergiActionPerformed
        //TODO add your handling code here:
    }//GEN-LAST:event_fieldAlergiActionPerformed

    private void inputAlergiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputAlergiActionPerformed
        data_StringAlergi = this.fieldAlergi.getText();
        inputDATA( data_StringAlergi, TEXT, indeksAlergi, CLAText);
        getDATA( indeksAlergi, false, null, dataAlergi, CLAText);
    }//GEN-LAST:event_inputAlergiActionPerformed

    private void deleteAlergiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteAlergiActionPerformed
        deleteText( indeksAlergi, dataAlergi, CLAText);
    }//GEN-LAST:event_deleteAlergiActionPerformed

    private void deleteGolongandarahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteGolongandarahActionPerformed
        deleteText( indeksGolongandarah, dataGolongandarah, CLANum);
    }//GEN-LAST:event_deleteGolongandarahActionPerformed

    private void inputGolongandarahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputGolongandarahActionPerformed
        data_StringGolongandarah = (String) this.ComboBoxGolongandarah.getSelectedItem();
        String dataNUM_StringGolongandarah = Character.toString(data_StringGolongandarah.charAt(0));

        inputDATA( dataNUM_StringGolongandarah, NUM, indeksGolongandarah, CLANum);
        getDATA( indeksGolongandarah, true, symbolGolongandarah, dataGolongandarah, CLANum);
    }//GEN-LAST:event_inputGolongandarahActionPerformed

    private void inputRiwayatOperasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputRiwayatOperasiActionPerformed
        data_StringRiwayatOperasi = this.fieldRiwayatOperasi.getText();
        inputDATA( data_StringRiwayatOperasi, TEXT, indeksRiwayatOperasi, CLAText);
        getDATA( indeksRiwayatOperasi, false, null, dataRiwayatOperasi, CLAText);
    }//GEN-LAST:event_inputRiwayatOperasiActionPerformed

    private void deleteRiwayatOperasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteRiwayatOperasiActionPerformed
        deleteText( indeksRiwayatOperasi, dataRiwayatOperasi, CLAText);
    }//GEN-LAST:event_deleteRiwayatOperasiActionPerformed

    private void inputRawatRSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputRawatRSActionPerformed
        data_StringRawatRS = this.fieldRawatRS.getText();
        inputDATA( data_StringRawatRS, TEXT, indeksRawatRS, CLAText);
        getDATA( indeksRawatRS, false, null, dataRawatRS, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputRawatRSActionPerformed

    private void deleteRawatRSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteRawatRSActionPerformed
        deleteText( indeksRawatRS, dataRawatRS, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteRawatRSActionPerformed

    private void inputPenyakitKronisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputPenyakitKronisActionPerformed
        data_StringPenyakitKronis = this.fieldPenyakitKronis.getText();
        inputDATA( data_StringPenyakitKronis, TEXT, indeksPenyakitKronis, CLAText);
        getDATA( indeksPenyakitKronis, false, null, dataPenyakitKronis, CLAText);
    }//GEN-LAST:event_inputPenyakitKronisActionPerformed

    private void deletePenyakitKronisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePenyakitKronisActionPerformed
        deleteText( indeksPenyakitKronis, dataPenyakitKronis, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deletePenyakitKronisActionPerformed

    private void inputPenyakitBawaanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputPenyakitBawaanActionPerformed
        data_StringPenyakitBawaan = this.fieldPenyakitBawaan.getText();
        inputDATA( data_StringPenyakitBawaan, TEXT, indeksPenyakitBawaan, CLAText);
        getDATA( indeksPenyakitBawaan, false, null, dataPenyakitBawaan, CLAText);
    }//GEN-LAST:event_inputPenyakitBawaanActionPerformed

    private void deletePenyakitBawaanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePenyakitBawaanActionPerformed
        deleteText( indeksPenyakitBawaan, dataPenyakitBawaan, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deletePenyakitBawaanActionPerformed

    private void inputFaktorResikoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputFaktorResikoActionPerformed
        data_StringFaktorResiko = this.fieldFaktorResiko.getText();
        inputDATA( data_StringFaktorResiko, TEXT, indeksFaktorResiko, CLAText);
        getDATA( indeksFaktorResiko, false, null, dataFaktorResiko, CLAText);
    }//GEN-LAST:event_inputFaktorResikoActionPerformed

    private void deleteFaktorResikoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteFaktorResikoActionPerformed
        deleteText( indeksFaktorResiko, dataFaktorResiko, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteFaktorResikoActionPerformed

    private void inputAllSTATIS1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputAllSTATIS1ActionPerformed
        inputAllDATADIRI();
    }//GEN-LAST:event_inputAllSTATIS1ActionPerformed

    private void deleteAllSTATIS1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteAllSTATIS1ActionPerformed
        deleteAllDATADIRI();        // TODO add your handling code here:
    }//GEN-LAST:event_deleteAllSTATIS1ActionPerformed

    private void getAllSTATIS1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getAllSTATIS1ActionPerformed
        getAllDATADIRI();// TODO add your handling code here:
    }//GEN-LAST:event_getAllSTATIS1ActionPerformed

    private void inputNoSCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputNoSCActionPerformed
        data_StringNoSC = this.fieldNoSC.getText();
	inputDATA( data_StringNoSC, TEXT, indeksNoSC, CLAText);
	getDATA( indeksNoSC, false, null, dataNoSc, CLAText);// TODO add your handling code here:
    }//GEN-LAST:event_inputNoSCActionPerformed

    private void deleteNoSCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteNoSCActionPerformed
        deleteText( indeksNoSC, dataNoSc, CLAText);// TODO add your handling code here:
    }//GEN-LAST:event_deleteNoSCActionPerformed

    private void inputNoAsuransiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputNoAsuransiActionPerformed
        data_StringNoAsuransi = this.fieldNoAsuransi.getText();
	inputDATA( data_StringNoAsuransi, TEXT, indeksNoAsuransi, CLAText);
	getDATA( indeksNoAsuransi, false, null, dataNoAsuransi, CLAText);// TODO add your handling code here:
    }//GEN-LAST:event_inputNoAsuransiActionPerformed

    private void deleteNoAsuransiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteNoAsuransiActionPerformed
        deleteText( indeksNoAsuransi, dataNoAsuransi, CLAText);// TODO add your handling code here:
    }//GEN-LAST:event_deleteNoAsuransiActionPerformed

    private void inputTanggalDaftarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputTanggalDaftarActionPerformed
        data_StringTanggalDaftar = this.fieldTanggalDaftar.getText();
	inputDATA( data_StringTanggalDaftar, TEXT, indeksTanggalDaftar, CLAText);
	getDATA( indeksTanggalDaftar, false, null, dataTanggalDaftar, CLAText);// TODO add your handling code here:
    }//GEN-LAST:event_inputTanggalDaftarActionPerformed

    private void deleteTanggalDaftarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteTanggalDaftarActionPerformed
        deleteText( indeksTanggalDaftar, dataTanggalDaftar, CLAText);// TODO add your handling code here:
    }//GEN-LAST:event_deleteTanggalDaftarActionPerformed

    private void inputNamaPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputNamaPasienActionPerformed
        data_StringNamaPasien = this.fieldNamaPasien.getText();
	inputDATA( data_StringNamaPasien, TEXT, indeksNamaPasien, CLAText);
	getDATA( indeksNamaPasien, false, null, dataNamaPasien, CLAText);// TODO add your handling code here:
    }//GEN-LAST:event_inputNamaPasienActionPerformed

    private void deleteNamaPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteNamaPasienActionPerformed
        deleteText( indeksNamaPasien, dataNamaPasien, CLAText);// TODO add your handling code here:
    }//GEN-LAST:event_deleteNamaPasienActionPerformed

    private void inputNamaKKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputNamaKKActionPerformed
        	// NamaKK
	data_StringNamaKK = this.fieldNamaKK.getText();
	inputDATA( data_StringNamaKK, TEXT, indeksNamaKK, CLAText);
	getDATA( indeksNamaKK, false, null, dataNamaKK, CLAText);// TODO add your handling code here:
    }//GEN-LAST:event_inputNamaKKActionPerformed

    private void deleteNamaKKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteNamaKKActionPerformed
        deleteText( indeksNamaKK, dataNamaKK, CLAText);// TODO add your handling code here:
    }//GEN-LAST:event_deleteNamaKKActionPerformed

    private void ComboBox_HubKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBox_HubKeluargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBox_HubKeluargaActionPerformed

    private void fieldKodePosKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldKodePosKeluargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldKodePosKeluargaActionPerformed

    private void deleteAlamatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteAlamatActionPerformed
       deleteText( indeksAlamat, dataAlamat, CLAText); // TODO add your handling code here:
    }//GEN-LAST:event_deleteAlamatActionPerformed

    private void inputHubKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputHubKeluargaActionPerformed
        String dataNUM_StringHubKeluarga = Integer.toString(ComboBox_HubKeluarga.getSelectedIndex()+1);
	inputDATA( dataNUM_StringHubKeluarga, NUM, indeksHubKeluarga, CLANum);
	getDATA( indeksHubKeluarga, true, symbolHubKeluarga, dataHubKeluarga, CLANum);// TODO add your handling code here:
    }//GEN-LAST:event_inputHubKeluargaActionPerformed

    private void inputAlamatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputAlamatActionPerformed
        data_StringAlamat = this.fieldAlamat.getText();
	inputDATA( data_StringAlamat, TEXT, indeksAlamat, CLAText);
	getDATA( indeksAlamat, false, null, dataAlamat, CLAText);// TODO add your handling code here:
    }//GEN-LAST:event_inputAlamatActionPerformed

    private void inputRTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputRTActionPerformed
        String dataNUM_StringRT = Integer.toString(ComboBox_RT.getSelectedIndex()+1);
	inputDATA( dataNUM_StringRT, NUM, indeksRT, CLANum);
	getDATA( indeksRT, true, symbolRT, dataRT, CLANum);
    }//GEN-LAST:event_inputRTActionPerformed

    private void inputRWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputRWActionPerformed
	String dataNUM_StringRW = Integer.toString(ComboBox_RW.getSelectedIndex()+1);
	inputDATA( dataNUM_StringRW, NUM, indeksRW, CLANum);
	getDATA( indeksRW, true, symbolRW, dataRW, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputRWActionPerformed

    private void inputKelurahanPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKelurahanPasienActionPerformed
	String dataNUM_StringKelurahanPasien = Integer.toString(ComboBox_KelurahanPasien.getSelectedIndex()+1);
	inputDATA( dataNUM_StringKelurahanPasien, NUM, indeksKelurahanPasien, CLANum);
	getDATA( indeksKelurahanPasien, true, symbolKelurahanPasien, dataKelurahanPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputKelurahanPasienActionPerformed

    private void inputKecamatanPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKecamatanPasienActionPerformed
	String dataNUM_StringKecamatanPasien = Integer.toString(ComboBox_KecamatanPasien.getSelectedIndex()+1);
	inputDATA( dataNUM_StringKecamatanPasien, NUM, indeksKecamatanPasien, CLANum);
	getDATA( indeksKecamatanPasien, true, symbolKecamatanPasien, dataKecamatanPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputKecamatanPasienActionPerformed

    private void inputKotaPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKotaPasienActionPerformed
	String dataNUM_StringKotaPasien = Integer.toString(ComboBox_KotaPasien.getSelectedIndex()+1);
	inputDATA( dataNUM_StringKotaPasien, NUM, indeksKotaPasien, CLANum);
	getDATA( indeksKotaPasien, true, symbolKotaPasien, dataKotaPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputKotaPasienActionPerformed

    private void inputPropinsiPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputPropinsiPasienActionPerformed
	String dataNUM_StringPropinsiPasien = Integer.toString(ComboBox_PropinsiPasien.getSelectedIndex()+1);
	inputDATA( dataNUM_StringPropinsiPasien, NUM, indeksPropinsiPasien, CLANum);
	getDATA( indeksPropinsiPasien, true, symbolPropinsiPasien, dataPropinsiPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputPropinsiPasienActionPerformed

    private void inputKodePosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKodePosActionPerformed
	data_StringKodepos = this.fieldKodePos.getText();
	inputDATA( data_StringKodepos, TEXT, indeksKodePos, CLAText);
	getDATA( indeksKodePos, false, null, dataKodePos, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputKodePosActionPerformed

    private void inputWilayahKerjaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputWilayahKerjaActionPerformed
        String dataNUM_StringWilayahKerja = Integer.toString(ComboBox_WilayahKerja.getSelectedIndex()+1);
	inputDATA( dataNUM_StringWilayahKerja, NUM, indeksWilayahKerja, CLANum);
	getDATA( indeksWilayahKerja, true, symbolWilayahKerja, dataWilayahKerja, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputWilayahKerjaActionPerformed

    private void inputTempatLahirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputTempatLahirActionPerformed
	data_StringTempatLahir = this.fieldTempatLahir.getText();
	inputDATA( data_StringTempatLahir, TEXT, indeksTempatLahir, CLAText);
	getDATA( indeksTempatLahir, false, null, dataTempatLahir, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputTempatLahirActionPerformed

    private void inputTanggalLahirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputTanggalLahirActionPerformed
	data_StringTanggalLahir = this.fieldTanggalLahir.getText();
	inputDATA( data_StringTanggalLahir, TEXT, indeksTanggalLahir, CLAText);
	getDATA( indeksTanggalLahir, false, null, dataTanggalLahir, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputTanggalLahirActionPerformed

    private void inputTeleponPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputTeleponPasienActionPerformed
	data_StringTeleponPasien = this.fieldTeleponPasien.getText();
	inputDATA( data_StringTeleponPasien, TEXT, indeksTeleponPasien, CLAText);
	getDATA( indeksTeleponPasien, false, null, dataTeleponPasien, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputTeleponPasienActionPerformed

    private void inputHPPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputHPPasienActionPerformed
	data_StringHPPasien = this.fieldHPPasien.getText();
	inputDATA( data_StringHPPasien, TEXT, indeksHPPasien, CLAText);
	getDATA( indeksHPPasien, false, null, dataHPPasien, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputHPPasienActionPerformed

    private void inputKTPPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKTPPasienActionPerformed
	data_StringKTPPasien = this.fieldKTPPasien.getText();
	inputDATA( data_StringKTPPasien, NUM, indeksKTPPasien, CLAText);
	getDATA( indeksKTPPasien, false, null, dataKTPPasien, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputKTPPasienActionPerformed

    private void inputJenisKelaminPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputJenisKelaminPasienActionPerformed
	String dataNUM_StringJenisKelaminPasien = Integer.toString(ComboBox_JenisKelaminPasien.getSelectedIndex()+1);
	inputDATA( dataNUM_StringJenisKelaminPasien, NUM, indeksJenisKelaminPasien, CLANum);
	getDATA( indeksJenisKelaminPasien, true, symbolJenisKelaminPasien, dataJenisKelaminPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputJenisKelaminPasienActionPerformed

    private void inputAgamaPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputAgamaPasienActionPerformed
	String dataNUM_StringAgamaPasien = Integer.toString(ComboBox_AgamaPasien.getSelectedIndex()+1);
	inputDATA( dataNUM_StringAgamaPasien, NUM, indeksAgamaPasien, CLANum);
	getDATA( indeksAgamaPasien, true, symbolAgamaPasien, dataAgamaPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputAgamaPasienActionPerformed

    private void inputPendidikanPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputPendidikanPasienActionPerformed
	String dataNUM_StringPendidikanPasien = Integer.toString(ComboBox_PendidikanPasien.getSelectedIndex()+1);
	inputDATA( dataNUM_StringPendidikanPasien, NUM, indeksPendidikanPasien, CLANum);
	getDATA( indeksPendidikanPasien, true, symbolPendidikanPasien, dataPendidikanPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputPendidikanPasienActionPerformed

    private void inputPekerjaanPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputPekerjaanPasienActionPerformed
	String dataNUM_StringPekerjaanPasien = Integer.toString(ComboBox_PekerjaanPasien.getSelectedIndex()+1);
	inputDATA( dataNUM_StringPekerjaanPasien, NUM, indeksPekerjaanPasien, CLANum);
	getDATA( indeksPekerjaanPasien, true, symbolPekerjaanPasien, dataPekerjaanPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputPekerjaanPasienActionPerformed

    private void inputKelasPerawatanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKelasPerawatanActionPerformed
	data_StringKelasPerawatan = this.fieldKelasPerawatan.getText();
	inputDATA( data_StringKelasPerawatan, TEXT, indeksKelasPerawatan, CLAText);
	getDATA( indeksKelasPerawatan, false, null, dataKelasPerawatan, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputKelasPerawatanActionPerformed

    private void inputEmailPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputEmailPasienActionPerformed
	data_StringEmailPasien = this.fieldEmailPasien.getText();
	inputDATA( data_StringEmailPasien, TEXT, indeksEmailPasien, CLAText);
	getDATA( indeksEmailPasien, false, null, dataEmailPasien, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputEmailPasienActionPerformed

    private void inputStatusPerkawinanPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputStatusPerkawinanPasienActionPerformed
	String dataNUM_StringStatusPerkawinanPasien = Integer.toString(ComboBox_StatusPerkawinanPasien.getSelectedIndex()+1);
	inputDATA( dataNUM_StringStatusPerkawinanPasien, NUM, indeksStatusPerkawinanPasien, CLANum);
	getDATA( indeksStatusPerkawinanPasien, true, symbolStatusPerkawinanPasien, dataStatusPerkawinanPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputStatusPerkawinanPasienActionPerformed

    private void inputKewarganegaraanPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKewarganegaraanPasienActionPerformed
	String dataNUM_StringKewarganegaraanPasien = Integer.toString(ComboBox_KewarganegaraanPasien.getSelectedIndex()+1);
	inputDATA( dataNUM_StringKewarganegaraanPasien, NUM, indeksKewarganegaraanPasien, CLANum);
	getDATA( indeksKewarganegaraanPasien, true, symbolKewarganegaraanPasien, dataKewarganegaraanPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputKewarganegaraanPasienActionPerformed

    private void inputNamaKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputNamaKeluargaActionPerformed
	data_StringNamaKeluarga = this.fieldNamaKeluarga.getText();
	inputDATA( data_StringNamaKeluarga, TEXT, indeksNamaKeluarga, CLAText);
	getDATA( indeksNamaKeluarga, false, null, dataNamaKeluarga, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputNamaKeluargaActionPerformed

    private void inputHubunganActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputHubunganActionPerformed
	String dataNUM_StringHubungan = Integer.toString(ComboBox_Hubungan.getSelectedIndex()+1);
	inputDATA( dataNUM_StringHubungan, NUM, indeksHubungan, CLANum);
	getDATA( indeksHubungan, true, symbolHubungan, dataHubungan, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputHubunganActionPerformed

    private void inputKelurahanKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKelurahanKeluargaActionPerformed
	String dataNUM_StringKelurahanKeluarga = Integer.toString(ComboBox_KelurahanKeluarga.getSelectedIndex()+1);
	inputDATA( dataNUM_StringKelurahanKeluarga, NUM, indeksKelurahanKeluarga, CLANum);
	getDATA( indeksKelurahanKeluarga, true, symbolKelurahanKeluarga, dataKelurahanKeluarga, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputKelurahanKeluargaActionPerformed

    private void inputKecamatanKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKecamatanKeluargaActionPerformed
	String dataNUM_StringKecamatanKeluarga = Integer.toString(ComboBox_KecamatanKeluarga.getSelectedIndex()+1);
	inputDATA( dataNUM_StringKecamatanKeluarga, NUM, indeksKecamatanKeluarga, CLANum);
	getDATA( indeksKecamatanKeluarga, true, symbolKecamatanKeluarga, dataKecamatanKeluarga, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputKecamatanKeluargaActionPerformed

    private void inputKotaKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKotaKeluargaActionPerformed
	String dataNUM_StringKotaKeluarga = Integer.toString(ComboBox_KotaKeluarga.getSelectedIndex()+1);
	inputDATA( dataNUM_StringKotaKeluarga, NUM, indeksKotaKeluarga, CLANum);
	getDATA( indeksKotaKeluarga, true, symbolKotaKeluarga, dataKotaKeluarga, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputKotaKeluargaActionPerformed

    private void inputPropinsiKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputPropinsiKeluargaActionPerformed
	String dataNUM_StringPropinsiKeluarga = Integer.toString(ComboBox_PropinsiKeluarga.getSelectedIndex()+1);
	inputDATA( dataNUM_StringPropinsiKeluarga, NUM, indeksPropinsiKeluarga, CLANum);
	getDATA( indeksPropinsiKeluarga, true, symbolPropinsiKeluarga, dataPropinsiKeluarga, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputPropinsiKeluargaActionPerformed

    private void inputKodePosKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKodePosKeluargaActionPerformed
	data_StringKodePosKeluarga = this.fieldKodePosKeluarga.getText();
	inputDATA( data_StringKodePosKeluarga, TEXT, indeksKodePosKeluarga, CLAText);
	getDATA( indeksKodePosKeluarga, false, null, dataKodePosKeluarga, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputKodePosKeluargaActionPerformed

    private void inputTeleponKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputTeleponKeluargaActionPerformed
	data_StringTeleponKeluarga = this.fieldTeleponKeluarga.getText();
	inputDATA( data_StringTeleponKeluarga, TEXT, indeksTeleponKeluarga, CLAText);
	getDATA( indeksTeleponKeluarga, false, null, dataTeleponKeluarga, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputTeleponKeluargaActionPerformed

    private void inputHPKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputHPKeluargaActionPerformed
	data_StringHPKeluarga = this.fieldHPKeluarga.getText();
	inputDATA( data_StringHPKeluarga, TEXT, indeksHPKeluarga, CLAText);
	getDATA( indeksHPKeluarga, false, null, dataHPKeluarga, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputHPKeluargaActionPerformed

    private void inputNamaKantorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputNamaKantorActionPerformed
	data_StringNamaKantor = this.fieldNamaKantor.getText();
	inputDATA( data_StringNamaKantor, TEXT, indeksNamaKantor, CLAText);
	getDATA( indeksNamaKantor, false, null, dataNamaKantor, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputNamaKantorActionPerformed

    private void inputAlamatKantorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputAlamatKantorActionPerformed
	data_StringAlamatKantor = this.fieldAlamatKantor.getText();
	inputDATA( data_StringAlamatKantor, TEXT, indeksAlamatKantor, CLAText);
	getDATA( indeksAlamatKantor, false, null, dataAlamatKantor, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputAlamatKantorActionPerformed

    private void inputKotaKantorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKotaKantorActionPerformed
	String dataNUM_StringKotaKantor = Integer.toString(ComboBox_KotaKantor.getSelectedIndex()+1);
	inputDATA( dataNUM_StringKotaKantor, NUM, indeksKotaKantor, CLANum);
	getDATA( indeksKotaKantor, true, symbolKotaKantor, dataKotaKantor, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_inputKotaKantorActionPerformed

    private void inputTeleponKantor1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputTeleponKantor1ActionPerformed
	data_StringTeleponKantor1 = this.fieldTeleponKantor1.getText();
	inputDATA( data_StringTeleponKantor1, TEXT, indeksTeleponKantor1, CLAText);
	getDATA( indeksTeleponKantor1, false, null, dataTeleponKantor1, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputTeleponKantor1ActionPerformed

    private void inputHPKantor1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputHPKantor1ActionPerformed
	data_StringHPKantor1 = this.fieldHPKantor1.getText();
	inputDATA( data_StringHPKantor1, TEXT, indeksHPKantor1, CLAText);
	getDATA( indeksHPKantor1, false, null, dataHPKantor1, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputHPKantor1ActionPerformed

    private void deleteHubKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteHubKeluargaActionPerformed
	deleteText( indeksHubKeluarga, dataHubKeluarga, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteHubKeluargaActionPerformed

    private void deleteRTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteRTActionPerformed
	deleteText( indeksRT, dataRT, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteRTActionPerformed

    private void deleteRWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteRWActionPerformed
	deleteText( indeksRW, dataRW, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteRWActionPerformed

    private void deleteKelurahanPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKelurahanPasienActionPerformed
	deleteText( indeksKelurahanPasien, dataKelurahanPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteKelurahanPasienActionPerformed

    private void deleteKecamatanPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKecamatanPasienActionPerformed
	deleteText( indeksKecamatanPasien, dataKecamatanPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteKecamatanPasienActionPerformed

    private void deleteKotaPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKotaPasienActionPerformed


	deleteText( indeksKotaPasien, dataKotaPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteKotaPasienActionPerformed

    private void deletePropinsiPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePropinsiPasienActionPerformed
	deleteText( indeksPropinsiPasien, dataPropinsiPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deletePropinsiPasienActionPerformed

    private void deleteKodePosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKodePosActionPerformed

	deleteText( indeksKodePos, dataKodePos, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteKodePosActionPerformed

    private void deleteWilayahKerjaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteWilayahKerjaActionPerformed
	deleteText( indeksWilayahKerja, dataWilayahKerja, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteWilayahKerjaActionPerformed

    private void deleteTempatLahirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteTempatLahirActionPerformed


	deleteText( indeksTempatLahir, dataTempatLahir, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteTempatLahirActionPerformed

    private void deleteTanggalLahirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteTanggalLahirActionPerformed
	deleteText( indeksTanggalLahir, dataTanggalLahir, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteTanggalLahirActionPerformed

    private void deleteTeleponPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteTeleponPasienActionPerformed

	deleteText( indeksTeleponPasien, dataTeleponPasien, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteTeleponPasienActionPerformed

    private void deleteHPPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteHPPasienActionPerformed
	deleteText( indeksHPPasien, dataHPPasien, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteHPPasienActionPerformed

    private void deleteKTPPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKTPPasienActionPerformed

	deleteText( indeksKTPPasien, dataKTPPasien, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteKTPPasienActionPerformed

    private void deleteJenisKelaminPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteJenisKelaminPasienActionPerformed
	deleteText( indeksJenisKelaminPasien, dataJenisKelaminPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteJenisKelaminPasienActionPerformed

    private void deleteAgamaPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteAgamaPasienActionPerformed
	deleteText( indeksAgamaPasien, dataAgamaPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteAgamaPasienActionPerformed

    private void deletePendidikanPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePendidikanPasienActionPerformed
	deleteText( indeksPendidikanPasien, dataPendidikanPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deletePendidikanPasienActionPerformed

    private void deletePekerjaanPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePekerjaanPasienActionPerformed
	deleteText( indeksPekerjaanPasien, dataPekerjaanPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deletePekerjaanPasienActionPerformed

    private void deleteKelasPerawatanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKelasPerawatanActionPerformed
	deleteText( indeksKelasPerawatan, dataKelasPerawatan, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteKelasPerawatanActionPerformed

    private void deleteEmailPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteEmailPasienActionPerformed
	deleteText( indeksEmailPasien, dataEmailPasien, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteEmailPasienActionPerformed

    private void deleteStatusPerkawinanPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteStatusPerkawinanPasienActionPerformed
	deleteText( indeksStatusPerkawinanPasien, dataStatusPerkawinanPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteStatusPerkawinanPasienActionPerformed

    private void deleteKewarganegaraanPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKewarganegaraanPasienActionPerformed

	deleteText( indeksKewarganegaraanPasien, dataKewarganegaraanPasien, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteKewarganegaraanPasienActionPerformed

    private void deleteNamaKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteNamaKeluargaActionPerformed
	deleteText( indeksNamaKeluarga, dataNamaKeluarga, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteNamaKeluargaActionPerformed

    private void deleteAlamatKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteAlamatKeluargaActionPerformed
	deleteText( indeksAlamatKeluarga, dataAlamatKeluarga, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteAlamatKeluargaActionPerformed

    private void deleteKelurahanKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKelurahanKeluargaActionPerformed
	deleteText( indeksKelurahanKeluarga, dataKelurahanKeluarga, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteKelurahanKeluargaActionPerformed

    private void deleteKecamatanKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKecamatanKeluargaActionPerformed

	deleteText( indeksKecamatanKeluarga, dataKecamatanKeluarga, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteKecamatanKeluargaActionPerformed

    private void deleteKotaKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKotaKeluargaActionPerformed

	deleteText( indeksKotaKeluarga, dataKotaKeluarga, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteKotaKeluargaActionPerformed

    private void deletePropinsiKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePropinsiKeluargaActionPerformed
	deleteText( indeksPropinsiKeluarga, dataPropinsiKeluarga, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deletePropinsiKeluargaActionPerformed

    private void deleteKodePosKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKodePosKeluargaActionPerformed
	deleteText( indeksKodePosKeluarga, dataKodePosKeluarga, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteKodePosKeluargaActionPerformed

    private void deleteTeleponKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteTeleponKeluargaActionPerformed
	deleteText( indeksTeleponKeluarga, dataTeleponKeluarga, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteTeleponKeluargaActionPerformed

    private void deleteHPKeluargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteHPKeluargaActionPerformed
	deleteText( indeksHPKeluarga, dataHPKeluarga, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteHPKeluargaActionPerformed

    private void deleteNamaKantorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteNamaKantorActionPerformed

	deleteText( indeksNamaKantor, dataNamaKantor, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteNamaKantorActionPerformed

    private void deleteAlamatKantorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteAlamatKantorActionPerformed
	deleteText( indeksAlamatKantor, dataAlamatKantor, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteAlamatKantorActionPerformed

    private void deleteKotaKantorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKotaKantorActionPerformed

	deleteText( indeksKotaKantor, dataKotaKantor, CLANum);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteKotaKantorActionPerformed

    private void deleteTeleponKantor1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteTeleponKantor1ActionPerformed
	deleteText( indeksTeleponKantor1, dataTeleponKantor1, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteTeleponKantor1ActionPerformed

    private void deleteHPKantor1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteHPKantor1ActionPerformed
	deleteText( indeksHPKantor1, dataHPKantor1, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteHPKantor1ActionPerformed

    private void btnVerifikasiPinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerifikasiPinActionPerformed
        new UserPinLogin_Admin().setVisible(true);// TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_btnVerifikasiPinActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        Main drv = new Main();
        new ControllerLogin(drv);// TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void inputKategoriPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputKategoriPasienActionPerformed
        data_StringKategoriPasien = this.fieldKategoriPasien.getText();
	inputDATA( data_StringKategoriPasien, TEXT, indeksKategoriPasien, CLAText);
	getDATA( indeksKategoriPasien, false, null, dataKategoriPasien, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_inputKategoriPasienActionPerformed

    private void deleteKategoriPasienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteKategoriPasienActionPerformed
        deleteText( indeksKategoriPasien, dataKategoriPasien, CLAText);        // TODO add your handling code here:
    }//GEN-LAST:event_deleteKategoriPasienActionPerformed

    private void btnHome1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHome1ActionPerformed
        Home_Admin home = new Home_Admin();
        home.setIsConnected(isConnected);
        home.setVisible(true);
        this.dispose();// TODO add your handling code here:
    }//GEN-LAST:event_btnHome1ActionPerformed

//--FUNGSI APDU-------------------------------------------------------------------------------//
    private byte[] getLCData(String byte1Str, String byte2Str) throws Exception
    {
        byte[] data_LC = new byte[2];
        byte byte1 =  Byte.parseByte(byte1Str );
        byte byte2 =  Byte.parseByte(byte2Str);
        data_LC[0] = byte1;
        data_LC[1] = byte2;
      
        return data_LC;
    }
    private boolean selectApplet(byte[] apdu)
    {
        boolean isSelected = false;
        try
        {
            javaCard.sendApdu(apdu);
            byte[] data = javaCard.getData();
            
            //this.status_Label_AdminForm.setText("okok "+Integer.toHexString(javaCard.getStatusWords()).toUpperCase());
            //this.result_Label.setText(new String(data));
            isSelected = true;
            isConnected = isSelected;
        } 
        catch (CardException | IllegalArgumentException | NullPointerException ex) 
        {
            JOptionPane.showMessageDialog(this, "Error while tried to Sslect the applet\n"+ex.getMessage()+"", "APDU sending fail", JOptionPane.ERROR_MESSAGE);
            isSelected = false;
            isConnected = isSelected;
        }        
        
        return isSelected;
    }
    
//--ITEM INPUT-------------------------------------------------------------------------------//    
    private void inputDATA(String data_String, int type, String indeks, String CLA){
//        String command = "00A40400";
//        command = command.concat(appletID);
//        
//        byte[] apdu = JavaSmartcard.hexStringToByteArray(command);
//        if (!selectApplet(apdu))
//        {
//            return;
//        }
   
        String data_Hex = null;
        String data_Len = null;
        
        switch(type){
            case NUM:
                data_Hex =  JavaSmartcard.getIntDataHex(data_String);
                data_Len =  JavaSmartcard.getLenHex(data_Hex,type);
                break;
            case TEXT:
                byte[] data_Byte = data_String.getBytes();
                data_Hex = JavaSmartcard.byteArrayToHexString(data_Byte);
                data_Len =  JavaSmartcard.getLenHex(data_String,type);
                break;
        }
        
        //System.out.println("datahex: %s "+data_Hex +"lendaata : "+data_Len);
        String command;
        command = CLA;
        command = command.concat("30");   
        
        command = command.concat(indeks);
        command = command.concat(data_Len);                
        command = command.concat(data_Hex); 
        
        byte[] apdu = JavaSmartcard.hexStringToByteArray(command);
        System.out.println(""+ JavaSmartcard.htos(apdu));
        try
        {
            javaCard.sendApdu(apdu);
            
            byte[] data = javaCard.getData();
            status = ""+Integer.toHexString(javaCard.getStatusWords()).toUpperCase();
            System.out.println(status);
            
            this.status_Label_AdminForm.setText(status);
            
        } 
        catch (CardException | IllegalArgumentException ex) 
        {
            JOptionPane.showMessageDialog(this, "Error while tried to send command APDU: SEND DATA\n"+ex.getMessage()+"", "APDU SEND fail", JOptionPane.ERROR_MESSAGE);
        }
    }

//--ITEM GET-------------------------------------------------------------------------------//    
    private void getDATA(String indeks, boolean symEx, String[] symbol, javax.swing.JLabel fieldData, String CLA){
        String command = "00A40400";
        command = command.concat(appletID);
        
        byte[] apdu = JavaSmartcard.hexStringToByteArray(command);
        if (!isConnected)
        {
            JOptionPane.showMessageDialog(null, "Kartu Belum Terkoneksi/ Koneksi Ter-Reset.Harap Hubungkan dan Lakukan Verifikasi Ulang");
        }
       
        command = CLA;
        command = command.concat("50");
   
        command = command.concat(indeks);
        
        apdu = JavaSmartcard.hexStringToByteArray(command);
        System.out.println(""+ JavaSmartcard.htos(apdu));
        try
        {
            javaCard.sendApdu(apdu);
            byte[] data = javaCard.getData();
            
            status = ""+Integer.toHexString(javaCard.getStatusWords()).toUpperCase();
            System.out.println(status);
            //this.status_Label.setText(""+Integer.toHexString(javaCard.getStatusWords()).toUpperCase());
            if (symEx){
            ByteBuffer dataWrapped = ByteBuffer.wrap(data);
            short indeksSymbol = dataWrapped.getShort();
            
            fieldData.setText(symbol[indeksSymbol-1]);
            }else{    
            fieldData.setText(new String(data));
            }
        } 
        catch (CardException | IllegalArgumentException ex) 
        {
            JOptionPane.showMessageDialog(this, "Error while tried to send command APDU: GETD DATA\n"+ex.getMessage()+"", "APDU GET fail", JOptionPane.ERROR_MESSAGE);
        }
    }
    //DINAMIS
    private void getDataDinamis(String indeks, boolean symEx, String[] symbol, javax.swing.JLabel fieldData, String CLA, boolean floatData, String getStack){
        String command = "00A40400";
        command = command.concat(appletID);
        
        byte[] apdu = JavaSmartcard.hexStringToByteArray(command);
        if (!isConnected)
        {
            JOptionPane.showMessageDialog(null, "Kartu Belum Terkoneksi/ Koneksi Ter-Reset.Harap Hubungkan dan Lakukan Verifikasi Ulang");
        }
        
        String data_hex = JavaSmartcard.getIntDataHex(getStack);
        
            
        command = CLA;
        command = command.concat("50");
        command = command.concat(indeks);
   
        command = command.concat("01");
        command = command.concat(data_hex);
        
        apdu = JavaSmartcard.hexStringToByteArray(command);
        System.out.println(""+ JavaSmartcard.htos(apdu));
        try
        {
            javaCard.sendApdu(apdu);
            byte[] data = javaCard.getData();
            
            //this.status_Label.setText(""+Integer.toHexString(javaCard.getStatusWords()).toUpperCase());
            if (symEx){
                if(floatData){
                    ByteBuffer dataWrapped = ByteBuffer.wrap(data);
                    Short data_short = dataWrapped.getShort();
                    //Short data_shortObject = new Short(data_short);
                    
                    float data_float = data_short.floatValue();
                    System.out.println(data_float);
                    
                    String data_text = Float.toString(data_float/100);
                    
                    fieldData.setText(data_text);
                }else{
                    ByteBuffer dataWrapped = ByteBuffer.wrap(data);
                    short indeksSymbol = dataWrapped.getShort();
            
                    fieldData.setText(symbol[indeksSymbol-1]);
                }
            }else{    
            fieldData.setText(new String(data));
            }
        } 
        catch (CardException | IllegalArgumentException ex) 
        {
            JOptionPane.showMessageDialog(this, "Error while tried to send command APDU: GETD DATA\n"+ex.getMessage()+"", "APDU GET fail", JOptionPane.ERROR_MESSAGE);
        }
    }
//--ITEM DELETE-------------------------------------------------------------------------------//    
    private void deleteText(String indeks, javax.swing.JLabel fieldData, String CLA){
        String command = "00A40400";
        command = command.concat(appletID);
        
        byte[] apdu = JavaSmartcard.hexStringToByteArray(command);
        if (!isConnected)
        {
            JOptionPane.showMessageDialog(null, "Kartu Belum Terkoneksi/ Koneksi Ter-Reset.Harap Hubungkan dan Lakukan Verifikasi Ulang");
        }
       
        command = CLA;
        command = command.concat("40");
        command = command.concat(indeks);
        
        apdu = JavaSmartcard.hexStringToByteArray(command);
        System.out.println(""+ JavaSmartcard.htos(apdu));
        try
        {
            javaCard.sendApdu(apdu);
            
            byte[] data = javaCard.getData();
            status = ""+Integer.toHexString(javaCard.getStatusWords()).toUpperCase();
            System.out.println(status);
            
            this.status_Label_AdminForm.setText(status);
            fieldData.setText("-");
        } 
        catch (CardException | IllegalArgumentException ex) 
        {
            JOptionPane.showMessageDialog(this, "Error while tried to send command APDU: GETD DATA\n"+ex.getMessage()+"", "APDU DELETE fail", JOptionPane.ERROR_MESSAGE);
        }
    }

//--FUNGSI ALL CRUD-------------------------------------------------------------------------------//        
    //DATADIRI
    private void getAllDATADIRI(){
       getDATA( indeksNoSC, false, null, dataNoSc, CLAText);
	getDATA( indeksKategoriPasien, false, null, dataKategoriPasien, CLAText);
	getDATA( indeksNoAsuransi, false, null, dataNoAsuransi, CLAText);
	getDATA( indeksTanggalDaftar, false, null, dataTanggalDaftar, CLAText);
	getDATA( indeksNamaPasien, false, null, dataNamaPasien, CLAText);
	getDATA( indeksNamaKK, false, null, dataNamaKK, CLAText);
	getDATA( indeksHubKeluarga, true, symbolHubKeluarga, dataHubKeluarga, CLANum);
	getDATA( indeksAlamat, false, null, dataAlamat, CLAText);
	getDATA( indeksRT, true, symbolRT, dataRT, CLANum);
	getDATA( indeksRW, true, symbolRW, dataRW, CLANum);
	getDATA( indeksKelurahanPasien, true, symbolKelurahanPasien, dataKelurahanPasien, CLANum);
	getDATA( indeksKecamatanPasien, true, symbolKecamatanPasien, dataKecamatanPasien, CLANum);
	getDATA( indeksKotaPasien, true, symbolKotaPasien, dataKotaPasien, CLANum);
	getDATA( indeksPropinsiPasien, true, symbolPropinsiPasien, dataPropinsiPasien, CLANum);
	getDATA( indeksKodePos, false, null, dataKodePos, CLAText);
	getDATA( indeksWilayahKerja, true, symbolWilayahKerja, dataWilayahKerja, CLANum);
	getDATA( indeksTempatLahir, false, null, dataTempatLahir, CLAText);
	getDATA( indeksTanggalLahir, false, null, dataTanggalLahir, CLAText);
	getDATA( indeksTeleponPasien, false, null, dataTeleponPasien, CLAText);
	getDATA( indeksHPPasien, false, null, dataHPPasien, CLAText);
	getDATA( indeksKTPPasien, false, null, dataKTPPasien, CLAText);
	getDATA( indeksJenisKelaminPasien, true, symbolJenisKelaminPasien, dataJenisKelaminPasien, CLANum);
	getDATA( indeksAgamaPasien, true, symbolAgamaPasien, dataAgamaPasien, CLANum);
	getDATA( indeksPendidikanPasien, true, symbolPendidikanPasien, dataPendidikanPasien, CLANum);
	getDATA( indeksPekerjaanPasien, true, symbolPekerjaanPasien, dataPekerjaanPasien, CLANum);
	getDATA( indeksKelasPerawatan, false, null, dataKelasPerawatan, CLAText);
	getDATA( indeksEmailPasien, false, null, dataEmailPasien, CLAText);
	getDATA( indeksStatusPerkawinanPasien, true, symbolStatusPerkawinanPasien, dataStatusPerkawinanPasien, CLANum);
	getDATA( indeksKewarganegaraanPasien, true, symbolKewarganegaraanPasien, dataKewarganegaraanPasien, CLANum);
	getDATA( indeksNamaKeluarga, false, null, dataNamaKeluarga, CLAText);
	getDATA( indeksHubungan, true, symbolHubungan, dataHubungan, CLANum);
	getDATA( indeksAlamatKeluarga, false, null, dataAlamatKeluarga, CLAText);
	getDATA( indeksKelurahanKeluarga, true, symbolKelurahanKeluarga, dataKelurahanKeluarga, CLANum);
	getDATA( indeksKecamatanKeluarga, true, symbolKecamatanKeluarga, dataKecamatanKeluarga, CLANum);
	getDATA( indeksKotaKeluarga, true, symbolKotaKeluarga, dataKotaKeluarga, CLANum);
	getDATA( indeksPropinsiKeluarga, true, symbolPropinsiKeluarga, dataPropinsiKeluarga, CLANum);
	getDATA( indeksKodePosKeluarga, false, null, dataKodePosKeluarga, CLAText);
	getDATA( indeksTeleponKeluarga, false, null, dataTeleponKeluarga, CLAText);
	getDATA( indeksHPKeluarga, false, null, dataHPKeluarga, CLAText);
	getDATA( indeksNamaKantor, false, null, dataNamaKantor, CLAText);
	getDATA( indeksAlamatKantor, false, null, dataAlamatKantor, CLAText);
	getDATA( indeksKotaKantor, true, symbolKotaKantor, dataKotaKantor, CLANum);
	getDATA( indeksTeleponKantor1, false, null, dataTeleponKantor1, CLAText);
	getDATA( indeksHPKantor1, false, null, dataHPKantor1, CLAText);
 
    }
    private void inputAllDATADIRI(){
        // NoSC
	data_StringNoSC = this.fieldNoSC.getText();
	inputDATA( data_StringNoSC, TEXT, indeksNoSC, CLAText);
	getDATA( indeksNoSC, false, null, dataNoSc, CLAText);
	// KategoriPasien
	data_StringKategoriPasien = this.fieldKategoriPasien.getText();
	inputDATA( data_StringKategoriPasien, TEXT, indeksKategoriPasien, CLAText);
	getDATA( indeksKategoriPasien, false, null, dataKategoriPasien, CLAText);
	// NoAsuransi
	data_StringNoAsuransi = this.fieldNoAsuransi.getText();
	inputDATA( data_StringNoAsuransi, TEXT, indeksNoAsuransi, CLAText);
	getDATA( indeksNoAsuransi, false, null, dataNoAsuransi, CLAText);
	// TanggalDaftar
	data_StringTanggalDaftar = this.fieldTanggalDaftar.getText();
	inputDATA( data_StringTanggalDaftar, TEXT, indeksTanggalDaftar, CLAText);
	getDATA( indeksTanggalDaftar, false, null, dataTanggalDaftar, CLAText);
	// NamaPasien
	data_StringNamaPasien = this.fieldNamaPasien.getText();
	inputDATA( data_StringNamaPasien, TEXT, indeksNamaPasien, CLAText);
	getDATA( indeksNamaPasien, false, null, dataNamaPasien, CLAText);
	// NamaKK
	data_StringNamaKK = this.fieldNamaKK.getText();
	inputDATA( data_StringNamaKK, TEXT, indeksNamaKK, CLAText);
	getDATA( indeksNamaKK, false, null, dataNamaKK, CLAText);
	// HubKeluarga
	data_StringHubKeluarga = (String) this.ComboBox_HubKeluarga.getSelectedItem();
	String dataNUM_StringHubKeluarga = Character.toString(data_StringHubKeluarga.charAt(0));
	inputDATA( dataNUM_StringHubKeluarga, NUM, indeksHubKeluarga, CLANum);
	getDATA( indeksHubKeluarga, true, symbolHubKeluarga, dataHubKeluarga, CLANum);
	// Alamat
	data_StringAlamat = this.fieldAlamat.getText();
	inputDATA( data_StringAlamat, TEXT, indeksAlamat, CLAText);
	getDATA( indeksAlamat, false, null, dataAlamat, CLAText);
	// RT
	data_StringRT = (String) this.ComboBox_RT.getSelectedItem();
	String dataNUM_StringRT = Character.toString(data_StringRT.charAt(0));
	inputDATA( dataNUM_StringRT, NUM, indeksRT, CLANum);
	getDATA( indeksRT, true, symbolRT, dataRT, CLANum);
	// RW
	data_StringRW = (String) this.ComboBox_RW.getSelectedItem();
	String dataNUM_StringRW = Character.toString(data_StringRW.charAt(0));
	inputDATA( dataNUM_StringRW, NUM, indeksRW, CLANum);
	getDATA( indeksRW, true, symbolRW, dataRW, CLANum);
	// KelurahanPasien
	data_StringKelurahanPasien = (String) this.ComboBox_KelurahanPasien.getSelectedItem();
	String dataNUM_StringKelurahanPasien = Character.toString(data_StringKelurahanPasien.charAt(0));
	inputDATA( dataNUM_StringKelurahanPasien, NUM, indeksKelurahanPasien, CLANum);
	getDATA( indeksKelurahanPasien, true, symbolKelurahanPasien, dataKelurahanPasien, CLANum);
	// KecamatanPasien
	data_StringKecamatanPasien = (String) this.ComboBox_KecamatanPasien.getSelectedItem();
	String dataNUM_StringKecamatanPasien = Character.toString(data_StringKecamatanPasien.charAt(0));
	inputDATA( dataNUM_StringKecamatanPasien, NUM, indeksKecamatanPasien, CLANum);
	getDATA( indeksKecamatanPasien, true, symbolKecamatanPasien, dataKecamatanPasien, CLANum);
	// KotaPasien
	data_StringKotaPasien = (String) this.ComboBox_KotaPasien.getSelectedItem();
	String dataNUM_StringKotaPasien = Character.toString(data_StringKotaPasien.charAt(0));
	inputDATA( dataNUM_StringKotaPasien, NUM, indeksKotaPasien, CLANum);
	getDATA( indeksKotaPasien, true, symbolKotaPasien, dataKotaPasien, CLANum);
	// PropinsiPasien
	data_StringPropinsiPasien = (String) this.ComboBox_PropinsiPasien.getSelectedItem();
	String dataNUM_StringPropinsiPasien = Character.toString(data_StringPropinsiPasien.charAt(0));
	inputDATA( dataNUM_StringPropinsiPasien, NUM, indeksPropinsiPasien, CLANum);
	getDATA( indeksPropinsiPasien, true, symbolPropinsiPasien, dataPropinsiPasien, CLANum);
	// Kodepos
	data_StringKodepos = this.fieldKodePos.getText();
	inputDATA( data_StringKodepos, TEXT, indeksKodePos, CLAText);
	getDATA( indeksKodePos, false, null, dataKodePos, CLAText);
	// WilayahKerja
	data_StringWilayahKerja = (String) this.ComboBox_WilayahKerja.getSelectedItem();
	String dataNUM_StringWilayahKerja = Character.toString(data_StringWilayahKerja.charAt(0));
	inputDATA( dataNUM_StringWilayahKerja, NUM, indeksWilayahKerja, CLANum);
	getDATA( indeksWilayahKerja, true, symbolWilayahKerja, dataWilayahKerja, CLANum);
	// TempatLahir
	data_StringTempatLahir = this.fieldTempatLahir.getText();
	inputDATA( data_StringTempatLahir, TEXT, indeksTempatLahir, CLAText);
	getDATA( indeksTempatLahir, false, null, dataTempatLahir, CLAText);
	// TanggalLahir
	data_StringTanggalLahir = this.fieldTanggalLahir.getText();
	inputDATA( data_StringTanggalLahir, TEXT, indeksTanggalLahir, CLAText);
	getDATA( indeksTanggalLahir, false, null, dataTanggalLahir, CLAText);
	// TeleponPasien
	data_StringTeleponPasien = this.fieldTeleponPasien.getText();
	inputDATA( data_StringTeleponPasien, TEXT, indeksTeleponPasien, CLAText);
	getDATA( indeksTeleponPasien, false, null, dataTeleponPasien, CLAText);
	// HPPasien
	data_StringHPPasien = this.fieldHPPasien.getText();
	inputDATA( data_StringHPPasien, TEXT, indeksHPPasien, CLAText);
	getDATA( indeksHPPasien, false, null, dataHPPasien, CLAText);
	// KTPPasien
	data_StringKTPPasien = this.fieldKTPPasien.getText();
	inputDATA( data_StringKTPPasien, NUM, indeksKTPPasien, CLAText);
	getDATA( indeksKTPPasien, false, null, dataKTPPasien, CLAText);
	// JenisKelaminPasien
	data_StringJenisKelaminPasien = (String) this.ComboBox_JenisKelaminPasien.getSelectedItem();
	String dataNUM_StringJenisKelaminPasien = Character.toString(data_StringJenisKelaminPasien.charAt(0));
	inputDATA( dataNUM_StringJenisKelaminPasien, NUM, indeksJenisKelaminPasien, CLANum);
	getDATA( indeksJenisKelaminPasien, true, symbolJenisKelaminPasien, dataJenisKelaminPasien, CLANum);
	// AgamaPasien
	data_StringAgamaPasien = (String) this.ComboBox_AgamaPasien.getSelectedItem();
	String dataNUM_StringAgamaPasien = Character.toString(data_StringAgamaPasien.charAt(0));
	inputDATA( dataNUM_StringAgamaPasien, NUM, indeksAgamaPasien, CLANum);
	getDATA( indeksAgamaPasien, true, symbolAgamaPasien, dataAgamaPasien, CLANum);
	// PendidikanPasien
	data_StringPendidikanPasien = (String) this.ComboBox_PendidikanPasien.getSelectedItem();
	String dataNUM_StringPendidikanPasien = Character.toString(data_StringPendidikanPasien.charAt(0));
	inputDATA( dataNUM_StringPendidikanPasien, NUM, indeksPendidikanPasien, CLANum);
	getDATA( indeksPendidikanPasien, true, symbolPendidikanPasien, dataPendidikanPasien, CLANum);
	// PekerjaanPasien
	data_StringPekerjaanPasien = (String) this.ComboBox_PekerjaanPasien.getSelectedItem();
	String dataNUM_StringPekerjaanPasien = Character.toString(data_StringPekerjaanPasien.charAt(0));
	inputDATA( dataNUM_StringPekerjaanPasien, NUM, indeksPekerjaanPasien, CLANum);
	getDATA( indeksPekerjaanPasien, true, symbolPekerjaanPasien, dataPekerjaanPasien, CLANum);
	// KelasPerawatan
	data_StringKelasPerawatan = this.fieldKelasPerawatan.getText();
	inputDATA( data_StringKelasPerawatan, TEXT, indeksKelasPerawatan, CLAText);
	getDATA( indeksKelasPerawatan, false, null, dataKelasPerawatan, CLAText);
	// EmailPasien
	data_StringEmailPasien = this.fieldEmailPasien.getText();
	inputDATA( data_StringEmailPasien, TEXT, indeksEmailPasien, CLAText);
	getDATA( indeksEmailPasien, false, null, dataEmailPasien, CLAText);
	// StatusPerkawinanPasien
	data_StringStatusPerkawinanPasien = (String) this.ComboBox_StatusPerkawinanPasien.getSelectedItem();
	String dataNUM_StringStatusPerkawinanPasien = Character.toString(data_StringStatusPerkawinanPasien.charAt(0));
	inputDATA( dataNUM_StringStatusPerkawinanPasien, NUM, indeksStatusPerkawinanPasien, CLANum);
	getDATA( indeksStatusPerkawinanPasien, true, symbolStatusPerkawinanPasien, dataStatusPerkawinanPasien, CLANum);
	// KewarganegaraanPasien
	data_StringKewarganegaraanPasien = (String) this.ComboBox_KewarganegaraanPasien.getSelectedItem();
	String dataNUM_StringKewarganegaraanPasien = Character.toString(data_StringKewarganegaraanPasien.charAt(0));
	inputDATA( dataNUM_StringKewarganegaraanPasien, NUM, indeksKewarganegaraanPasien, CLANum);
	getDATA( indeksKewarganegaraanPasien, true, symbolKewarganegaraanPasien, dataKewarganegaraanPasien, CLANum);
	// NamaKeluarga
	data_StringNamaKeluarga = this.fieldNamaKeluarga.getText();
	inputDATA( data_StringNamaKeluarga, TEXT, indeksNamaKeluarga, CLAText);
	getDATA( indeksNamaKeluarga, false, null, dataNamaKeluarga, CLAText);
	// Hubungan
	data_StringHubungan = (String) this.ComboBox_Hubungan.getSelectedItem();
	String dataNUM_StringHubungan = Character.toString(data_StringHubungan.charAt(0));
	inputDATA( dataNUM_StringHubungan, NUM, indeksHubungan, CLANum);
	getDATA( indeksHubungan, true, symbolHubungan, dataHubungan, CLANum);
	// AlamatKeluarga
	data_StringAlamatKeluarga = this.fieldAlamatKeluarga.getText();
	inputDATA( data_StringAlamatKeluarga, TEXT, indeksAlamatKeluarga, CLAText);
	getDATA( indeksAlamatKeluarga, false, null, dataAlamatKeluarga, CLAText);
	// KelurahanKeluarga
	data_StringKelurahanKeluarga = (String) this.ComboBox_KelurahanKeluarga.getSelectedItem();
	String dataNUM_StringKelurahanKeluarga = Character.toString(data_StringKelurahanKeluarga.charAt(0));
	inputDATA( dataNUM_StringKelurahanKeluarga, NUM, indeksKelurahanKeluarga, CLANum);
	getDATA( indeksKelurahanKeluarga, true, symbolKelurahanKeluarga, dataKelurahanKeluarga, CLANum);
	// KecamatanKeluarga
	data_StringKecamatanKeluarga = (String) this.ComboBox_KecamatanKeluarga.getSelectedItem();
	String dataNUM_StringKecamatanKeluarga = Character.toString(data_StringKecamatanKeluarga.charAt(0));
	inputDATA( dataNUM_StringKecamatanKeluarga, NUM, indeksKecamatanKeluarga, CLANum);
	getDATA( indeksKecamatanKeluarga, true, symbolKecamatanKeluarga, dataKecamatanKeluarga, CLANum);
	// KotaKeluarga
	data_StringKotaKeluarga = (String) this.ComboBox_KotaKeluarga.getSelectedItem();
	String dataNUM_StringKotaKeluarga = Character.toString(data_StringKotaKeluarga.charAt(0));
	inputDATA( dataNUM_StringKotaKeluarga, NUM, indeksKotaKeluarga, CLANum);
	getDATA( indeksKotaKeluarga, true, symbolKotaKeluarga, dataKotaKeluarga, CLANum);
	// PropinsiKeluarga
	data_StringPropinsiKeluarga = (String) this.ComboBox_PropinsiKeluarga.getSelectedItem();
	String dataNUM_StringPropinsiKeluarga = Character.toString(data_StringPropinsiKeluarga.charAt(0));
	inputDATA( dataNUM_StringPropinsiKeluarga, NUM, indeksPropinsiKeluarga, CLANum);
	getDATA( indeksPropinsiKeluarga, true, symbolPropinsiKeluarga, dataPropinsiKeluarga, CLANum);
	// KodePosKeluarga
	data_StringKodePosKeluarga = this.fieldKodePosKeluarga.getText();
	inputDATA( data_StringKodePosKeluarga, TEXT, indeksKodePosKeluarga, CLAText);
	getDATA( indeksKodePosKeluarga, false, null, dataKodePosKeluarga, CLAText);
	// TeleponKeluarga
	data_StringTeleponKeluarga = this.fieldTeleponKeluarga.getText();
	inputDATA( data_StringTeleponKeluarga, TEXT, indeksTeleponKeluarga, CLAText);
	getDATA( indeksTeleponKeluarga, false, null, dataTeleponKeluarga, CLAText);
	// HPKeluarga
	data_StringHPKeluarga = this.fieldHPKeluarga.getText();
	inputDATA( data_StringHPKeluarga, TEXT, indeksHPKeluarga, CLAText);
	getDATA( indeksHPKeluarga, false, null, dataHPKeluarga, CLAText);
	// NamaKantor
	data_StringNamaKantor = this.fieldNamaKantor.getText();
	inputDATA( data_StringNamaKantor, TEXT, indeksNamaKantor, CLAText);
	getDATA( indeksNamaKantor, false, null, dataNamaKantor, CLAText);
	// AlamatKantor
	data_StringAlamatKantor = this.fieldAlamatKantor.getText();
	inputDATA( data_StringAlamatKantor, TEXT, indeksAlamatKantor, CLAText);
	getDATA( indeksAlamatKantor, false, null, dataAlamatKantor, CLAText);
	// KotaKantor
	data_StringKotaKantor = (String) this.ComboBox_KotaKantor.getSelectedItem();
	String dataNUM_StringKotaKantor = Character.toString(data_StringKotaKantor.charAt(0));
	inputDATA( dataNUM_StringKotaKantor, NUM, indeksKotaKantor, CLANum);
	getDATA( indeksKotaKantor, true, symbolKotaKantor, dataKotaKantor, CLANum);
	// TeleponKantor1
	data_StringTeleponKantor1 = this.fieldTeleponKantor1.getText();
	inputDATA( data_StringTeleponKantor1, TEXT, indeksTeleponKantor1, CLAText);
	getDATA( indeksTeleponKantor1, false, null, dataTeleponKantor1, CLAText);
	// HPKantor1
	data_StringHPKantor1 = this.fieldHPKantor1.getText();
	inputDATA( data_StringHPKantor1, TEXT, indeksHPKantor1, CLAText);
	getDATA( indeksHPKantor1, false, null, dataHPKantor1, CLAText);
    }
    private void deleteAllDATADIRI(){
        deleteText( indeksNoSC, dataNoSc, CLAText);
	deleteText( indeksKategoriPasien, dataKategoriPasien, CLAText);
	deleteText( indeksNoAsuransi, dataNoAsuransi, CLAText);
	deleteText( indeksTanggalDaftar, dataTanggalDaftar, CLAText);
	deleteText( indeksNamaPasien, dataNamaPasien, CLAText);
	deleteText( indeksNamaKK, dataNamaKK, CLAText);
	deleteText( indeksHubKeluarga, dataHubKeluarga, CLANum);
	deleteText( indeksAlamat, dataAlamat, CLAText);
	deleteText( indeksRT, dataRT, CLANum);
	deleteText( indeksRW, dataRW, CLANum);
	deleteText( indeksKelurahanPasien, dataKelurahanPasien, CLANum);
	deleteText( indeksKecamatanPasien, dataKecamatanPasien, CLANum);
	deleteText( indeksKotaPasien, dataKotaPasien, CLANum);
	deleteText( indeksPropinsiPasien, dataPropinsiPasien, CLANum);
	deleteText( indeksKodePos, dataKodePos, CLAText);
	deleteText( indeksWilayahKerja, dataWilayahKerja, CLANum);
	deleteText( indeksTempatLahir, dataTempatLahir, CLAText);
	deleteText( indeksTanggalLahir, dataTanggalLahir, CLAText);
	deleteText( indeksTeleponPasien, dataTeleponPasien, CLAText);
	deleteText( indeksHPPasien, dataHPPasien, CLAText);
	deleteText( indeksKTPPasien, dataKTPPasien, CLAText);
	deleteText( indeksJenisKelaminPasien, dataJenisKelaminPasien, CLANum);
	deleteText( indeksAgamaPasien, dataAgamaPasien, CLANum);
	deleteText( indeksPendidikanPasien, dataPendidikanPasien, CLANum);
	deleteText( indeksPekerjaanPasien, dataPekerjaanPasien, CLANum);
	deleteText( indeksKelasPerawatan, dataKelasPerawatan, CLAText);
	deleteText( indeksEmailPasien, dataEmailPasien, CLAText);
	deleteText( indeksStatusPerkawinanPasien, dataStatusPerkawinanPasien, CLANum);
	deleteText( indeksKewarganegaraanPasien, dataKewarganegaraanPasien, CLANum);
	deleteText( indeksNamaKeluarga, dataNamaKeluarga, CLAText);
	deleteText( indeksHubungan, dataHubungan, CLANum);
	deleteText( indeksAlamatKeluarga, dataAlamatKeluarga, CLAText);
	deleteText( indeksKelurahanKeluarga, dataKelurahanKeluarga, CLANum);
	deleteText( indeksKecamatanKeluarga, dataKecamatanKeluarga, CLANum);
	deleteText( indeksKotaKeluarga, dataKotaKeluarga, CLANum);
	deleteText( indeksPropinsiKeluarga, dataPropinsiKeluarga, CLANum);
	deleteText( indeksKodePosKeluarga, dataKodePosKeluarga, CLAText);
	deleteText( indeksTeleponKeluarga, dataTeleponKeluarga, CLAText);
	deleteText( indeksHPKeluarga, dataHPKeluarga, CLAText);
	deleteText( indeksNamaKantor, dataNamaKantor, CLAText);
	deleteText( indeksAlamatKantor, dataAlamatKantor, CLAText);
	deleteText( indeksKotaKantor, dataKotaKantor, CLANum);
	deleteText( indeksTeleponKantor1, dataTeleponKantor1, CLAText);
	deleteText( indeksHPKantor1, dataHPKantor1, CLAText);

        
    }
    //STATIS
    private void getAllSTATIS(){
         //STATIS
        getDATA( indeksAlergi, false, null, dataAlergi, CLAText);
        getDATA( indeksGolongandarah, true, symbolGolongandarah, dataGolongandarah, CLANum);
        getDATA( indeksRiwayatOperasi, false, null, dataRiwayatOperasi, CLAText);
        getDATA( indeksRawatRS, false, null, dataRawatRS, CLAText);
        getDATA( indeksPenyakitKronis, false, null, dataPenyakitKronis, CLAText);
        getDATA( indeksPenyakitBawaan, false, null, dataPenyakitBawaan, CLAText);
        getDATA( indeksFaktorResiko, false, null, dataFaktorResiko, CLAText);
        // TODO add your handling code here:

    }
    private void inputAllSTATIS(){
        //STATIS
        // Alergi
        data_StringAlergi = this.fieldAlergi.getText();
        inputDATA( data_StringAlergi, TEXT, indeksAlergi, CLAText);
        getDATA( indeksAlergi, false, null, dataAlergi, CLAText);
        // Golongandarah
        data_StringGolongandarah = (String) this.ComboBoxGolongandarah.getSelectedItem();
        String dataNUM_StringGolongandarah = Character.toString(data_StringGolongandarah.charAt(0));
        inputDATA( dataNUM_StringGolongandarah, NUM, indeksGolongandarah, CLANum);
        getDATA( indeksGolongandarah, true, symbolGolongandarah, dataGolongandarah, CLANum);
        // RiwayatOperasi
        data_StringRiwayatOperasi = this.fieldRiwayatOperasi.getText();
        inputDATA( data_StringRiwayatOperasi, TEXT, indeksRiwayatOperasi, CLAText);
        getDATA( indeksRiwayatOperasi, false, null, dataRiwayatOperasi, CLAText);
        // RawatRS
        data_StringRawatRS = this.fieldRawatRS.getText();
        inputDATA( data_StringRawatRS, TEXT, indeksRawatRS, CLAText);
        getDATA( indeksRawatRS, false, null, dataRawatRS, CLAText);
        // PenyakitKronis
        data_StringPenyakitKronis = this.fieldPenyakitKronis.getText();
        inputDATA( data_StringPenyakitKronis, TEXT, indeksPenyakitKronis, CLAText);
        getDATA( indeksPenyakitKronis, false, null, dataPenyakitKronis, CLAText);
        // PenyakitBawaan
        data_StringPenyakitBawaan = this.fieldPenyakitBawaan.getText();
        inputDATA( data_StringPenyakitBawaan, TEXT, indeksPenyakitBawaan, CLAText);
        getDATA( indeksPenyakitBawaan, false, null, dataPenyakitBawaan, CLAText);
        // FaktorResiko
        data_StringFaktorResiko = this.fieldFaktorResiko.getText();
        inputDATA( data_StringFaktorResiko, TEXT, indeksFaktorResiko, CLAText);
        getDATA( indeksFaktorResiko, false, null, dataFaktorResiko, CLAText);
    }
    private void deleteAllStatis(){
        deleteText( indeksAlergi, dataAlergi, CLAText);
        deleteText( indeksGolongandarah, dataGolongandarah, CLANum);
        deleteText( indeksRiwayatOperasi, dataRiwayatOperasi, CLAText);
        deleteText( indeksRawatRS, dataRawatRS, CLAText);
        deleteText( indeksPenyakitKronis, dataPenyakitKronis, CLAText);
        deleteText( indeksPenyakitBawaan, dataPenyakitBawaan, CLAText);
        deleteText( indeksFaktorResiko, dataFaktorResiko, CLAText);
        
    }
    
    public boolean getIsConnected(){
        return this.isConnected;
    }
    
    public void setIsConnected(boolean statConnection){
        this.isConnected = statConnection;
    }

    

    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboBoxGolongandarah;
    private javax.swing.JComboBox<String> ComboBox_AgamaPasien;
    private javax.swing.JComboBox<String> ComboBox_HubKeluarga;
    private javax.swing.JComboBox<String> ComboBox_Hubungan;
    private javax.swing.JComboBox<String> ComboBox_JenisKelaminPasien;
    private javax.swing.JComboBox<String> ComboBox_KecamatanKeluarga;
    private javax.swing.JComboBox<String> ComboBox_KecamatanPasien;
    private javax.swing.JComboBox<String> ComboBox_KelurahanKeluarga;
    private javax.swing.JComboBox<String> ComboBox_KelurahanPasien;
    private javax.swing.JComboBox<String> ComboBox_KewarganegaraanPasien;
    private javax.swing.JComboBox<String> ComboBox_KotaKantor;
    private javax.swing.JComboBox<String> ComboBox_KotaKeluarga;
    private javax.swing.JComboBox<String> ComboBox_KotaPasien;
    private javax.swing.JComboBox<String> ComboBox_PekerjaanPasien;
    private javax.swing.JComboBox<String> ComboBox_PendidikanPasien;
    private javax.swing.JComboBox<String> ComboBox_PropinsiKeluarga;
    private javax.swing.JComboBox<String> ComboBox_PropinsiPasien;
    private javax.swing.JComboBox<String> ComboBox_RT;
    private javax.swing.JComboBox<String> ComboBox_RW;
    private javax.swing.JComboBox<String> ComboBox_StatusPerkawinanPasien;
    private javax.swing.JComboBox<String> ComboBox_WilayahKerja;
    private javax.swing.JPanel DataDiri;
    private javax.swing.JPanel PanelReaderCard;
    private javax.swing.JPanel RekamMedisStatis;
    private javax.swing.JLabel administrator1;
    private javax.swing.JLabel administrator2;
    private javax.swing.JButton btnHome1;
    private javax.swing.JButton btnLogOut;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnVerifikasiPin;
    private javax.swing.JLabel dataAgamaPasien;
    private javax.swing.JLabel dataAlamat;
    private javax.swing.JLabel dataAlamatKantor;
    private javax.swing.JLabel dataAlamatKeluarga;
    private javax.swing.JLabel dataAlergi;
    private javax.swing.JLabel dataEmailPasien;
    private javax.swing.JLabel dataFaktorResiko;
    private javax.swing.JLabel dataGolongandarah;
    private javax.swing.JLabel dataHPKantor1;
    private javax.swing.JLabel dataHPKeluarga;
    private javax.swing.JLabel dataHPPasien;
    private javax.swing.JLabel dataHubKeluarga;
    private javax.swing.JLabel dataHubungan;
    private javax.swing.JLabel dataJenisKelaminPasien;
    private javax.swing.JLabel dataKTPPasien;
    private javax.swing.JLabel dataKategoriPasien;
    private javax.swing.JLabel dataKecamatanKeluarga;
    private javax.swing.JLabel dataKecamatanPasien;
    private javax.swing.JLabel dataKelasPerawatan;
    private javax.swing.JLabel dataKelurahanKeluarga;
    private javax.swing.JLabel dataKelurahanPasien;
    private javax.swing.JLabel dataKewarganegaraanPasien;
    private javax.swing.JLabel dataKodePos;
    private javax.swing.JLabel dataKodePosKeluarga;
    private javax.swing.JLabel dataKotaKantor;
    private javax.swing.JLabel dataKotaKeluarga;
    private javax.swing.JLabel dataKotaPasien;
    private javax.swing.JLabel dataNamaKK;
    private javax.swing.JLabel dataNamaKantor;
    private javax.swing.JLabel dataNamaKeluarga;
    private javax.swing.JLabel dataNamaPasien;
    private javax.swing.JLabel dataNoAsuransi;
    private javax.swing.JLabel dataNoSc;
    private javax.swing.JLabel dataPekerjaanPasien;
    private javax.swing.JLabel dataPendidikanPasien;
    private javax.swing.JLabel dataPenyakitBawaan;
    private javax.swing.JLabel dataPenyakitKronis;
    private javax.swing.JLabel dataPropinsiKeluarga;
    private javax.swing.JLabel dataPropinsiPasien;
    private javax.swing.JLabel dataRT;
    private javax.swing.JLabel dataRW;
    private javax.swing.JLabel dataRawatRS;
    private javax.swing.JLabel dataRiwayatOperasi;
    private javax.swing.JLabel dataStatusPerkawinanPasien;
    private javax.swing.JLabel dataTanggalDaftar;
    private javax.swing.JLabel dataTanggalLahir;
    private javax.swing.JLabel dataTeleponKantor1;
    private javax.swing.JLabel dataTeleponKeluarga;
    private javax.swing.JLabel dataTeleponPasien;
    private javax.swing.JLabel dataTempatLahir;
    private javax.swing.JLabel dataWilayahKerja;
    private javax.swing.JButton deleteAgamaPasien;
    private javax.swing.JButton deleteAlamat;
    private javax.swing.JButton deleteAlamatKantor;
    private javax.swing.JButton deleteAlamatKeluarga;
    private javax.swing.JButton deleteAlergi;
    private javax.swing.JButton deleteAllDATA;
    private javax.swing.JButton deleteAllSTATIS;
    private javax.swing.JButton deleteEmailPasien;
    private javax.swing.JButton deleteFaktorResiko;
    private javax.swing.JButton deleteGolongandarah;
    private javax.swing.JButton deleteHPKantor1;
    private javax.swing.JButton deleteHPKeluarga;
    private javax.swing.JButton deleteHPPasien;
    private javax.swing.JButton deleteHubKeluarga;
    private javax.swing.JButton deleteHubungan;
    private javax.swing.JButton deleteJenisKelaminPasien;
    private javax.swing.JButton deleteKTPPasien;
    private javax.swing.JButton deleteKategoriPasien;
    private javax.swing.JButton deleteKecamatanKeluarga;
    private javax.swing.JButton deleteKecamatanPasien;
    private javax.swing.JButton deleteKelasPerawatan;
    private javax.swing.JButton deleteKelurahanKeluarga;
    private javax.swing.JButton deleteKelurahanPasien;
    private javax.swing.JButton deleteKewarganegaraanPasien;
    private javax.swing.JButton deleteKodePos;
    private javax.swing.JButton deleteKodePosKeluarga;
    private javax.swing.JButton deleteKotaKantor;
    private javax.swing.JButton deleteKotaKeluarga;
    private javax.swing.JButton deleteKotaPasien;
    private javax.swing.JButton deleteNamaKK;
    private javax.swing.JButton deleteNamaKantor;
    private javax.swing.JButton deleteNamaKeluarga;
    private javax.swing.JButton deleteNamaPasien;
    private javax.swing.JButton deleteNoAsuransi;
    private javax.swing.JButton deleteNoSC;
    private javax.swing.JButton deletePekerjaanPasien;
    private javax.swing.JButton deletePendidikanPasien;
    private javax.swing.JButton deletePenyakitBawaan;
    private javax.swing.JButton deletePenyakitKronis;
    private javax.swing.JButton deletePropinsiKeluarga;
    private javax.swing.JButton deletePropinsiPasien;
    private javax.swing.JButton deleteRT;
    private javax.swing.JButton deleteRW;
    private javax.swing.JButton deleteRawatRS;
    private javax.swing.JButton deleteRiwayatOperasi;
    private javax.swing.JButton deleteStatusPerkawinanPasien;
    private javax.swing.JButton deleteTanggalDaftar;
    private javax.swing.JButton deleteTanggalLahir;
    private javax.swing.JButton deleteTeleponKantor1;
    private javax.swing.JButton deleteTeleponKeluarga;
    private javax.swing.JButton deleteTeleponPasien;
    private javax.swing.JButton deleteTempatLahir;
    private javax.swing.JButton deleteWilayahKerja;
    private javax.swing.JTextField fieldAlamat;
    private javax.swing.JTextField fieldAlamatKantor;
    private javax.swing.JTextField fieldAlamatKeluarga;
    private javax.swing.JTextField fieldAlergi;
    private javax.swing.JTextField fieldEmailPasien;
    private javax.swing.JTextField fieldFaktorResiko;
    private javax.swing.JTextField fieldHPKantor1;
    private javax.swing.JTextField fieldHPKeluarga;
    private javax.swing.JTextField fieldHPPasien;
    private javax.swing.JTextField fieldKTPPasien;
    private javax.swing.JTextField fieldKategoriPasien;
    private javax.swing.JTextField fieldKelasPerawatan;
    private javax.swing.JTextField fieldKodePos;
    private javax.swing.JTextField fieldKodePosKeluarga;
    private javax.swing.JTextField fieldNamaKK;
    private javax.swing.JTextField fieldNamaKantor;
    private javax.swing.JTextField fieldNamaKeluarga;
    private javax.swing.JTextField fieldNamaPasien;
    private javax.swing.JTextField fieldNoAsuransi;
    private javax.swing.JTextField fieldNoSC;
    private javax.swing.JTextField fieldPenyakitBawaan;
    private javax.swing.JTextField fieldPenyakitKronis;
    private javax.swing.JTextField fieldRawatRS;
    private javax.swing.JTextField fieldRiwayatOperasi;
    private javax.swing.JTextField fieldTanggalDaftar;
    private javax.swing.JTextField fieldTanggalLahir;
    private javax.swing.JTextField fieldTeleponKantor1;
    private javax.swing.JTextField fieldTeleponKeluarga;
    private javax.swing.JTextField fieldTeleponPasien;
    private javax.swing.JTextField fieldTempatLahir;
    private javax.swing.ButtonGroup gender;
    private javax.swing.JButton getAllDATA;
    private javax.swing.JButton getAllSTATIS;
    private javax.swing.JButton inputAgamaPasien;
    private javax.swing.JButton inputAlamat;
    private javax.swing.JButton inputAlamatKantor;
    private javax.swing.JButton inputAlamatKeluarga;
    private javax.swing.JButton inputAlergi;
    private javax.swing.JButton inputAllSTATIS;
    private javax.swing.JButton inputAllSTATIS5;
    private javax.swing.JButton inputEmailPasien;
    private javax.swing.JButton inputFaktorResiko;
    private javax.swing.JButton inputGolongandarah;
    private javax.swing.JButton inputHPKantor1;
    private javax.swing.JButton inputHPKeluarga;
    private javax.swing.JButton inputHPPasien;
    private javax.swing.JButton inputHubKeluarga;
    private javax.swing.JButton inputHubungan;
    private javax.swing.JButton inputJenisKelaminPasien;
    private javax.swing.JButton inputKTPPasien;
    private javax.swing.JButton inputKategoriPasien;
    private javax.swing.JButton inputKecamatanKeluarga;
    private javax.swing.JButton inputKecamatanPasien;
    private javax.swing.JButton inputKelasPerawatan;
    private javax.swing.JButton inputKelurahanKeluarga;
    private javax.swing.JButton inputKelurahanPasien;
    private javax.swing.JButton inputKewarganegaraanPasien;
    private javax.swing.JButton inputKodePos;
    private javax.swing.JButton inputKodePosKeluarga;
    private javax.swing.JButton inputKotaKantor;
    private javax.swing.JButton inputKotaKeluarga;
    private javax.swing.JButton inputKotaPasien;
    private javax.swing.JButton inputNamaKK;
    private javax.swing.JButton inputNamaKantor;
    private javax.swing.JButton inputNamaKeluarga;
    private javax.swing.JButton inputNamaPasien;
    private javax.swing.JButton inputNoAsuransi;
    private javax.swing.JButton inputNoSC;
    private javax.swing.JButton inputPekerjaanPasien;
    private javax.swing.JButton inputPendidikanPasien;
    private javax.swing.JButton inputPenyakitBawaan;
    private javax.swing.JButton inputPenyakitKronis;
    private javax.swing.JButton inputPropinsiKeluarga;
    private javax.swing.JButton inputPropinsiPasien;
    private javax.swing.JButton inputRT;
    private javax.swing.JButton inputRW;
    private javax.swing.JButton inputRawatRS;
    private javax.swing.JButton inputRiwayatOperasi;
    private javax.swing.JButton inputStatusPerkawinanPasien;
    private javax.swing.JButton inputTanggalDaftar;
    private javax.swing.JButton inputTanggalLahir;
    private javax.swing.JButton inputTeleponKantor1;
    private javax.swing.JButton inputTeleponKeluarga;
    private javax.swing.JButton inputTeleponPasien;
    private javax.swing.JButton inputTempatLahir;
    private javax.swing.JButton inputWilayahKerja;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane_DATA;
    private javax.swing.JScrollPane jScrollPane_STATIS;
    private javax.swing.JTabbedPane jTabbedAll;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel labelAgamaPasien;
    private javax.swing.JLabel labelAlamat;
    private javax.swing.JLabel labelAlamatKantor;
    private javax.swing.JLabel labelAlamatKeluarga;
    private javax.swing.JLabel labelEmailPasien;
    private javax.swing.JLabel labelHPKantor1;
    private javax.swing.JLabel labelHPKeluarga;
    private javax.swing.JLabel labelHPPasien;
    private javax.swing.JLabel labelHubKeluarga;
    private javax.swing.JLabel labelHubungan;
    private javax.swing.JLabel labelJenisKelaminPasien;
    private javax.swing.JLabel labelKTPPasien;
    private javax.swing.JLabel labelKategoriPasien;
    private javax.swing.JLabel labelKecamatanKeluarga;
    private javax.swing.JLabel labelKecamatanPasien;
    private javax.swing.JLabel labelKelasPerawatan;
    private javax.swing.JLabel labelKelurahanKeluarga;
    private javax.swing.JLabel labelKelurahanPasien;
    private javax.swing.JLabel labelKewarganegaraanPasien;
    private javax.swing.JLabel labelKodePos;
    private javax.swing.JLabel labelKodePosKeluarga;
    private javax.swing.JLabel labelKotaKantor;
    private javax.swing.JLabel labelKotaKeluarga;
    private javax.swing.JLabel labelKotaPasien;
    private javax.swing.JLabel labelNamaKK;
    private javax.swing.JLabel labelNamaKantor;
    private javax.swing.JLabel labelNamaKeluarga;
    private javax.swing.JLabel labelNamaPasien;
    private javax.swing.JLabel labelNoAsuransi;
    private javax.swing.JLabel labelNoSC;
    private javax.swing.JLabel labelPekerjaanPasien;
    private javax.swing.JLabel labelPendidikanPasien;
    private javax.swing.JLabel labelPropinsiKeluarga;
    private javax.swing.JLabel labelPropinsiPasien;
    private javax.swing.JLabel labelRT;
    private javax.swing.JLabel labelRW;
    private javax.swing.JLabel labelStatusPerkawinanPasien;
    private javax.swing.JLabel labelTanggalDaftar;
    private javax.swing.JLabel labelTanggalLahir;
    private javax.swing.JLabel labelTeleponKantor1;
    private javax.swing.JLabel labelTeleponKeluarga;
    private javax.swing.JLabel labelTeleponPasien;
    private javax.swing.JLabel labelTempatLahir;
    private javax.swing.JLabel labelWilayahKerja;
    private javax.swing.JPanel panelAllCRUD_DATA;
    private javax.swing.JPanel panelAllCRUD_STATIS;
    private javax.swing.JPanel panelItemDATA;
    private javax.swing.JPanel panelItemSTATIS;
    private javax.swing.JPanel panelOperationTitle;
    private javax.swing.JLabel status_Label_AdminForm;
    // End of variables declaration//GEN-END:variables
}
