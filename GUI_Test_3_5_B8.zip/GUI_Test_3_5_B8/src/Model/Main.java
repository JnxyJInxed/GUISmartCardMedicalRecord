/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;


import Database.koneksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author ILM
 */
public class Main {
    private koneksi data;
    private Connection conn;
    
    public Main(){
        this.data = new koneksi();
        data.connect();
    }
    
    
    public User login(String username,String password){
        User U=data.getUser(username, password);
        if(U!= null){
            return U; 
        }else{
            return null;
        }
    }
    
    public User cariUsername(String username) {
        User U = data.getUsername(username);
        if (U!=null){
            return U;
        }
        else {
            return null;
        }
    }
    

    public User cariUserAnswer(String username, String answer) {
        User U = data.getUserAnswer(username,answer);
        if (U!=null){
            return U;
        }
        else {
            return null;
        }}
    
    
}
