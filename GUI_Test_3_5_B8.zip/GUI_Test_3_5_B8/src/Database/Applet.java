/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import javax.swing.JOptionPane;
/**
 *
 * @author USER
 */
public class Applet {
    String appletID = "09B70000006203012101";
    public Applet(){
        
    }
    
    public String getAppletID(){
        return appletID;
    }
    
    public boolean getSWStatus(String statusLabel)
    {
        boolean isSuccess = false;
        switch (statusLabel) {
	    case "9000":
	         isSuccess = true;
	         break;
            case "6A80":
	         isSuccess = false;
                 JOptionPane.showMessageDialog(null, "Parameter data input tidak sesuai");
	         break;
            case "6A82":
                isSuccess = false;
                JOptionPane.showMessageDialog(null, "File(Item) tidak terdaftar");
            break;
            case "6A83":
                isSuccess = false;
                JOptionPane.showMessageDialog(null, "Record tidak ditemukan");
            break;
            case "6A84":
                isSuccess = false;
                JOptionPane.showMessageDialog(null, "Memory sudah terisi. Overwrite tidak diizinkan");
            break;
            case "6A87":
                isSuccess = false;
                JOptionPane.showMessageDialog(null, "Panjang data input tidak sesuai dengan parameter data");
            break;
            case "6300":
                isSuccess = false;
                JOptionPane.showMessageDialog(null, "Dibutuhkan verifikasi Pin User");
            break;
            case "6301":
                isSuccess = false;
                JOptionPane.showMessageDialog(null, "Dibutuhkan verifikasi Pin Admin");
            break;
            case "6302":
                isSuccess = false;
                JOptionPane.showMessageDialog(null, "Dibutuhkan verifikasi Pin Dokter");
            break;
            case "6303":
                isSuccess = false;
                JOptionPane.showMessageDialog(null, "Dibutuhkan verifikasi Pin Operator");
            break;
            case "63C4":
	         isSuccess = false;
                 JOptionPane.showMessageDialog(null, "Pin salah. Tersisa 4 kali kesempatan login");
	         break;
            case "63C3":
	         isSuccess = false;
                 JOptionPane.showMessageDialog(null, "Pin salah. Tersisa 3 kali kesempatan login");
	         break;
            case "63C2":
	         isSuccess = false;
                 JOptionPane.showMessageDialog(null, "Pin salah. Tersisa 2 kali kesempatan login");
	         break;
            case "63C1":
	         isSuccess = false;
                 JOptionPane.showMessageDialog(null, "Pin salah. Tersisa 1 kali kesempatan login");
	         break;
            case "63C0":
	         isSuccess = false;
                 JOptionPane.showMessageDialog(null, "Pin Salah.");
	         break;
            case "6900":
                isSuccess = false;
                JOptionPane.showMessageDialog(null, "Kartu berada dalama keadaan terkunci. Mohon lakukan reset pin dengan autoritas admin");
            break;
	    default:
                isSuccess = false;
                JOptionPane.showMessageDialog(null, "Data tidak valid");
	        break;
        }    
        
        return isSuccess;
    }
}
