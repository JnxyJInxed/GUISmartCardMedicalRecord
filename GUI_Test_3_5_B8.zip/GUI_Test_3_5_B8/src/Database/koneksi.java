/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;
import Model.User;
import View.Login;
import com.mysql.jdbc.Driver;
import java.sql.*;
import javax.swing.JOptionPane;
import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javax.swing.JOptionPane.WARNING_MESSAGE;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
/**
 *
 * @author hanif salafi
 */
public class koneksi {
    private static Connection conn;
    private String server="jdbc:mysql://localhost/account_3_0";
    private String dbUser ="root";
    private String dbPasswd="";
    Statement statement;
    Connection connection;
    private ResultSet rs;
    private PreparedStatement pst;
    private DefaultTableModel _tabel;
    
    public void connect(){
        try{
            connection = DriverManager.getConnection(server, dbUser, dbPasswd);
            statement =  connection.createStatement();
        }catch(SQLException ex){
            System.out.println("Koneksi ke SQL gagal");
        }
    }
    
 
    public User getUser(String username,String password){
        User U = null;
        try{
            String query="SELECT * FROM account WHERE username= '"+username+"' "
                    +"AND password = '"+password+"'";
            ResultSet rs=statement.executeQuery(query);
            while(rs.next()){
                U=new User(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
            }
            return U;
        }catch(SQLException ex){
            System.out.println("Login Failed"+ex);
            return null;
        }
    }
    
    public User getUsername(String username) {
        User U = null;
        try{
            String query="SELECT * FROM account WHERE username= '"+username+"'";
            ResultSet rs=statement.executeQuery(query);
            while(rs.next()){
                U=new User(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
            }
            return U;
        }catch(SQLException ex){
            System.out.println("Process Failed"+ex);
            return null;
        }
    }


    public User getUserAnswer(String username, String answer) {
        User U = null;
        try{
            String query="SELECT * FROM account WHERE username= '"+username+"' "+"AND Answer = '"+answer+"'";
            ResultSet rs=statement.executeQuery(query);
            while(rs.next()){
                U=new User(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
            }
            return U;
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Process Failed");
            return null;
        }
    }


}