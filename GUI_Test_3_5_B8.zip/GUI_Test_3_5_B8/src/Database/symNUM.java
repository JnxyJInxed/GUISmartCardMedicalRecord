/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

/**
 *
 * @author USER
 */
public class symNUM {
    public String[] symbolGolongandarah = new String[8];
    
    
    public void InisiasiSymGolongandarah(){
        symbolGolongandarah[0] = "1. A+";
        symbolGolongandarah[1] = "2. A-";
        symbolGolongandarah[2] = "3. B+";
        symbolGolongandarah[3] = "4. B-";
        symbolGolongandarah[4] = "5. AB+";
        symbolGolongandarah[5] = "6. AB-";
        symbolGolongandarah[6] = "7. O+";
        symbolGolongandarah[7] = "8. O-";
    //--DINAMIS
    }
}
